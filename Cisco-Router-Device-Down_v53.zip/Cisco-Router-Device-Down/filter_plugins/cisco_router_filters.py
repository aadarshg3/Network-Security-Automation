#!/usr/bin/env python3
"""
Custom Jinja filters for the Cisco-Router-Device-Down Ansible role.

Provides parsers for Cisco show-command output, BGP/HSRP/VRRP state
evaluation, WAN-interface identification, route-table analysis,
running-config diff, and ServiceNow message sanitization.
"""

from __future__ import absolute_import, division, print_function
__metaclass__ = type

import re
import json
import difflib
import ipaddress
import logging
from collections import Counter

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Interface abbreviation helpers
# ---------------------------------------------------------------------------

_IFACE_PREFIXES = [
    ('GigabitEthernet', 'Gi'), ('FastEthernet', 'Fa'),
    ('TenGigabitEthernet', 'Te'), ('HundredGigE', 'Hu'),
    ('FortyGigabitEthernet', 'Fo'), ('TwentyFiveGigE', 'Twe'),
    ('Serial', 'Se'), ('Loopback', 'Lo'), ('Tunnel', 'Tu'),
    ('Vlan', 'Vl'), ('BDI', 'BDI'), ('Bundle-Ether', 'BE'),
    ('Management', 'Mg'), ('Port-channel', 'Po'),
]

def _expand_iface(name):
    """Expand abbreviated interface name to full form."""
    n = name.strip()
    # v40: a name that is already in full form must be returned unchanged.
    # Without this guard 'GigabitEthernet0/0/0' matched abbr 'Gi' and came
    # back as 'GigabitEthernetgabitEthernet0/0/0' (WAN detection mismatch).
    for full, _abbr in _IFACE_PREFIXES:
        if n.lower().startswith(full.lower()):
            return full + n[len(full):]
    for full, abbr in _IFACE_PREFIXES:
        if n.lower().startswith(abbr.lower()):
            return full + n[len(abbr):]
    return n

def _abbrev_iface(name):
    """Abbreviate interface name."""
    n = name.strip()
    for full, abbr in _IFACE_PREFIXES:
        if n.lower().startswith(full.lower()):
            return abbr + n[len(full):]
    return n

def _iface_match(a, b):
    """Return True if two interface names refer to the same interface."""
    return (_expand_iface(a).lower() == _expand_iface(b).lower() or
            _abbrev_iface(a).lower() == _abbrev_iface(b).lower() or
            a.lower() == b.lower())

# ---------------------------------------------------------------------------
# 1. safe_json_parse
# ---------------------------------------------------------------------------

def safe_json_parse(value):
    """Safely parse JSON returned by device_ssh.py / ping.py.

    Guarantees the return is always a dict containing an 'outputs' dict and a
    'packet_loss' int, so downstream '.outputs.get(...)' and '.packet_loss'
    access can never raise on a skipped task, empty stdout, or malformed JSON.
    """
    def _normalize(d):
        if not isinstance(d, dict):
            d = {'success': False, 'error': 'non-object JSON', 'output': ''}
        if 'outputs' not in d or not isinstance(d.get('outputs'), dict):
            d['outputs'] = d.get('outputs') if isinstance(d.get('outputs'), dict) else {}
        if 'packet_loss' not in d:
            d['packet_loss'] = 100
        return d

    if isinstance(value, dict):
        return _normalize(dict(value))
    try:
        return _normalize(json.loads(value))
    except Exception as exc:
        preview = str(value)[:300] if value else 'empty'
        return {
            'success': False,
            'error': f'JSON parse failed: {exc} | preview: {preview}',
            'output': '',
            'outputs': {},
            'packet_loss': 100,
        }

# ---------------------------------------------------------------------------
# 2. extract_platform
# ---------------------------------------------------------------------------

def extract_platform(show_version_text):
    """
    Detect platform from show version output.
    Returns 'ios', 'ios_xe', or 'ios_xr'.
    """
    if not show_version_text:
        return 'ios'
    t = show_version_text.lower()

    if 'ios xr' in t or 'iosxr' in t or 'cisco xr' in t:
        return 'ios_xr'
    # v52 [A - fixes build 10331 mislabel]:
    # IOS-XE always declares itself as "IOS XE"/"IOS-XE" in the banner, or is a
    # 16.x/17.x release (IOS-XE only), or one of the XE-only release trains /
    # platform families below.  The image-name token "universalk9" is NOT an XE
    # signal: classic IOS 15.x(x)M images are "universalk9" too (e.g.
    # C800-UNIVERSALK9-M running 15.5(3)M2), so matching the bare substring
    # 'universal' mislabelled classic-IOS CPE as IOS-XE.  Removed that trigger
    # and replaced it with XE-only signals that cannot match classic IOS.
    if ('ios-xe' in t or 'ios xe' in t or 'ios_xe' in t
            or re.search(r'version\s+1[67]\.', t)
            or 'denali' in t or 'fuji' in t or 'everest' in t
            or 'gibraltar' in t or 'amsterdam' in t or 'bengaluru' in t
            or 'cupertino' in t or 'dublin' in t
            or 'asr1' in t or 'isr4' in t or 'csr1000' in t):
        return 'ios_xe'
    # vios_l2 is Layer-2 IOSv (switch image) - still classify as ios
    return 'ios'

# ---------------------------------------------------------------------------
# parse_interface_state
# ---------------------------------------------------------------------------

def parse_interface_state(show_ip_int_brief, interface_name):
    """Return [line_status, protocol] for the given interface."""
    if not show_ip_int_brief or not interface_name:
        return ['unknown', 'unknown']

    for line in show_ip_int_brief.splitlines():
        parts = line.split()
        if len(parts) < 4 or parts[0].lower() == 'interface':
            continue

        if not _iface_match(interface_name, parts[0]):
            continue

        protocol = parts[-1]

        if 'administratively' in line.lower():
            return ['administratively down', protocol]

        status = parts[-2]
        return [status, protocol]

    return ['unknown', 'unknown']

# ---------------------------------------------------------------------------
# parse_interface_ip_mask
# ---------------------------------------------------------------------------

def parse_interface_ip_mask(show_running, interface_name):
    """Return [ip_address, subnet_mask] for the given interface from running-config."""
    if not show_running or not interface_name:
        return ['', '']

    in_block = False
    iface_pattern = re.compile(
        r'^interface\s+' + re.escape(_expand_iface(interface_name)),
        re.IGNORECASE
    )
    iface_pattern_abbr = re.compile(
        r'^interface\s+' + re.escape(_abbrev_iface(interface_name)),
        re.IGNORECASE
    )

    for line in show_running.splitlines():
        stripped = line.strip()

        if iface_pattern.match(stripped) or iface_pattern_abbr.match(stripped):
            in_block = True
            continue

        if in_block:
            if re.match(r'^interface\s+', stripped) or stripped == '!':
                break
            m = re.search(
                r'ip address\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)',
                stripped
            )
            if m:
                return [m.group(1), m.group(2)]

    return ['', '']

# ---------------------------------------------------------------------------
# 5. parse_default_route_interface
# ---------------------------------------------------------------------------

def parse_default_route_interface(show_ip_route):
    """
    Extract exit interface from static default route (0.0.0.0/0).
    Returns empty string if route is next-hop-only.
    """
    if not show_ip_route:
        return ''
    for line in show_ip_route.splitlines():
        if '0.0.0.0' in line and re.search(r'S[*\s]', line):
            # via X.X.X.X, GigabitEthernetY/Z
            m = re.search(r'via\s+\d+\.\d+\.\d+\.\d+,\s*(\S+)', line)
            if m:
                return m.group(1)
            # directly connected via interface
            m = re.search(
                r'(?:Gi|Fa|Se|Te|Hu|Lo|Tu|Vl|Po|Be|BDI)\S+',
                line
            )
            if m and 'via' not in line:
                return m.group(0)
    return ''

# ---------------------------------------------------------------------------
# 6. parse_static_default_next_hop
# ---------------------------------------------------------------------------

def parse_static_default_next_hop(show_ip_route):
    """Extract next-hop IP from static default route."""
    if not show_ip_route:
        return ''
    for line in show_ip_route.splitlines():
        if '0.0.0.0' in line and re.search(r'S[*\s]', line):
            m = re.search(r'via\s+(\d+\.\d+\.\d+\.\d+)', line)
            if m:
                return m.group(1)
    return ''

# ---------------------------------------------------------------------------
# 7. WAN interface helpers
# ---------------------------------------------------------------------------

_WAN_DESC_KEYWORDS = re.compile(
    r'\b(wan|mpls|inet|internet|uplink|isp|transit|provider|pe|core|bb|backbone|'
    r'access|circuit|broadband|dsl|fiber|fibre|lte|4g|5g|sdwan)\b',
    re.IGNORECASE
)

def _find_wan_by_description(show_int_desc):
    """Scan 'show interfaces description' for WAN keywords."""
    if not show_int_desc:
        return ''
    for line in show_int_desc.splitlines():
        parts = line.split()
        if len(parts) < 4:
            continue
        iface = parts[0]
        # Skip loopback, vlan, port-channel (management/layer2)
        if re.match(r'^(Lo|Vl|Po|BDI)', iface, re.IGNORECASE):
            continue
        # Status must be up/up (or at least up line protocol)
        if len(parts) >= 3 and parts[1].lower() not in ('up', 'down'):
            continue
        description_part = ' '.join(parts[3:]) if len(parts) > 3 else ''
        if _WAN_DESC_KEYWORDS.search(description_part):
            return iface
    return ''

def _find_bgp_wan_interface(bgp_summary_text, show_running):
    """
    Find WAN interface by BGP neighbor on /30 or /31 subnet.
    Identifies interfaces whose IP is on the same /30 or /31 as a BGP neighbor.
    """
    if not bgp_summary_text or not show_running:
        return ''

    # Extract BGP neighbors from summary
    bgp_neighbors = []
    for line in bgp_summary_text.splitlines():
        m = re.match(r'^\s*(\d+\.\d+\.\d+\.\d+)\s+\d+\s+\d+', line)
        if m:
            bgp_neighbors.append(m.group(1))

    if not bgp_neighbors:
        return ''

    # Find all interface IPs from running config
    iface_ips = {}
    current_iface = None
    for line in show_running.splitlines():
        stripped = line.strip()
        m = re.match(r'^interface\s+(\S+)', stripped, re.IGNORECASE)
        if m:
            current_iface = m.group(1)
            continue
        if current_iface:
            m = re.search(
                r'ip address\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)',
                stripped
            )
            if m:
                iface_ips[current_iface] = (m.group(1), m.group(2))

    # Check if any BGP neighbor is on same /30 or /31 as an interface
    for iface, (ip, mask) in iface_ips.items():
        # Skip loopback
        if re.match(r'^Lo', iface, re.IGNORECASE):
            continue
        try:
            iface_net = ipaddress.IPv4Network(f'{ip}/{mask}', strict=False)
            prefix_len = iface_net.prefixlen
            if prefix_len not in (30, 31):
                continue
            for neighbor in bgp_neighbors:
                if ipaddress.IPv4Address(neighbor) in iface_net:
                    return iface
        except Exception:
            continue

    return ''

# Circuit-ID pattern. NOC confirmed WAN descriptions almost always carry a
# circuit ID shaped as 'c' followed by exactly 7 digits (e.g. c3026553 inside
# "199902687:MICHELIN:c3026553"). Prefix text varies; the c+7digits token does not.
_CIRCUIT_ID = re.compile(r'\bc\d{7}\b', re.IGNORECASE)


def _find_wan_by_circuit_id(show_int_desc):
    """Scan 'show interfaces description' for a circuit-ID token (c + 7 digits).
    Strong WAN signal - circuit IDs appear on provider-facing interfaces only.
    Loopback/VLAN/Port-channel skipped."""
    if not show_int_desc:
        return ''
    for line in show_int_desc.splitlines():
        parts = line.split()
        if len(parts) < 4:
            continue
        iface = parts[0]
        if re.match(r'^(Lo|Vl|Po|BDI|Tu|Nu)', iface, re.IGNORECASE):
            continue
        description_part = ' '.join(parts[3:])
        if _CIRCUIT_ID.search(description_part):
            return iface
    return ''


def _find_first_l3_interface(show_ip_int_brief):
    """v11 tie-breaker: NOC says the WAN is the first physical interface in
    70-80% of sites. LOW-weight signal - used only to break ties / nudge PE
    derivation, never to authorise a bounce on its own.
    Returns the first physical L3 interface that has an assigned IP, skipping
    loopback/vlan/port-channel/tunnel/null."""
    if not show_ip_int_brief:
        return ''
    for line in show_ip_int_brief.splitlines():
        parts = line.split()
        if len(parts) < 2:
            continue
        iface = parts[0]
        if not re.match(r'^(Gi|Te|Fa|Et|Hu|Fo|Twe|Two|Se)', iface, re.IGNORECASE):
            continue
        ip = parts[1]
        if re.match(r'^\d+\.\d+\.\d+\.\d+$', ip):   # has an assigned IP
            return iface
    return ''


def corroborate_wan_pe_from_static(show_ip_route):
    """
    Static-case corroboration. Match the static default next-hop to the
    connected route whose subnet contains it; that interface is the WAN and the
    next-hop is the PE. Validated against live device:
      S* 0.0.0.0/0 via 62.22.251.49
      62.22.251.48/30 is directly connected, GigabitEthernet0/0/0
      => WAN=Gi0/0/0, PE=62.22.251.49
    Returns {'wan_interface': str, 'pe_ip': str, 'matched': bool}.
    """
    nh = parse_static_default_next_hop(show_ip_route)
    if not nh:
        return {'wan_interface': '', 'pe_ip': '', 'matched': False}

    # Scan connected (C/L) routes for a subnet containing the next-hop.
    for line in (show_ip_route or '').splitlines():
        m = re.search(
            r'(\d+\.\d+\.\d+\.\d+)/(\d+)\s+is directly connected,\s+(\S+)',
            line
        )
        if not m:
            continue
        net_ip, plen, iface = m.group(1), m.group(2), m.group(3)
        if re.match(r'^(Lo|Vl|Po|BDI|Tu|Nu)', iface, re.IGNORECASE):
            continue
        try:
            net = ipaddress.IPv4Network(f'{net_ip}/{plen}', strict=False)
            if ipaddress.IPv4Address(nh) in net:
                return {'wan_interface': iface, 'pe_ip': nh, 'matched': True}
        except Exception:
            continue
    return {'wan_interface': '', 'pe_ip': nh, 'matched': False}


# ---------------------------------------------------------------------------
# 8. derive_wan_interface_with_confidence  (3-signal algorithm)
# ---------------------------------------------------------------------------

def derive_wan_interface_with_confidence(
    show_ip_route, show_running, bgp_summary_text, show_int_desc,
    show_ip_int_brief=''
):
    """
    WAN identification (4 strong signals + 1 low-weight tie-breaker).
    Signal 1: default_route - exit interface in static default route
    Signal 2: bgp_subnet   - BGP neighbor on /30 or /31 subnet
    Signal 3: description  - WAN keyword in interface description
    Signal 4: circuit_id   - circuit-ID token (c + 7 digits) in description
    Tie-break: first_l3    - first physical L3 interface (LOW weight, never alone)

    HIGH confidence (bounce gate) = at least 2 STRONG signals agree on the same
    interface. The first_l3 tie-breaker never raises confidence to high on its own.

    Returns:
      {'interface': str, 'confidence': 'high'|'medium'|'low', 'signals': {...}}
    """
    signals = {
        'default_route': {'interface': '', 'fired': False, 'reason': ''},
        'bgp_subnet':    {'interface': '', 'fired': False, 'reason': ''},
        'description':   {'interface': '', 'fired': False, 'reason': ''},
        'circuit_id':    {'interface': '', 'fired': False, 'reason': ''},
        'first_l3':      {'interface': '', 'fired': False, 'reason': ''},
    }

    # Signal 1
    dr_iface = parse_default_route_interface(show_ip_route)
    if dr_iface:
        signals['default_route'] = {
            'interface': dr_iface, 'fired': True,
            'reason': f'Static default route (0.0.0.0/0) exit interface: {dr_iface}',
        }
    else:
        nh = parse_static_default_next_hop(show_ip_route)
        if nh:
            signals['default_route']['reason'] = (
                f'Default route is next-hop-only via {nh} - no exit interface specified'
            )
        else:
            signals['default_route']['reason'] = 'No static default route (0.0.0.0/0) found in routing table'

    # Signal 2
    bgp_iface = _find_bgp_wan_interface(bgp_summary_text, show_running)
    if bgp_iface:
        signals['bgp_subnet'] = {
            'interface': bgp_iface, 'fired': True,
            'reason': f'BGP neighbor resides on /30 or /31 subnet - WAN interface: {bgp_iface}',
        }
    else:
        signals['bgp_subnet']['reason'] = (
            'No BGP neighbor found on a /30 or /31 point-to-point subnet'
        )

    # Signal 3
    desc_iface = _find_wan_by_description(show_int_desc)
    if desc_iface:
        signals['description'] = {
            'interface': desc_iface, 'fired': True,
            'reason': f'WAN/MPLS/INET/Uplink keyword in interface description - interface: {desc_iface}',
        }
    else:
        signals['description']['reason'] = (
            'No WAN/MPLS/INET/Uplink/Internet keyword found in any interface description'
        )

    # Signal 4: circuit-ID token in description (STRONG)
    cid_iface = _find_wan_by_circuit_id(show_int_desc)
    if cid_iface:
        signals['circuit_id'] = {
            'interface': cid_iface, 'fired': True,
            'reason': f'Circuit-ID token (c+7 digits) in description - interface: {cid_iface}',
        }
    else:
        signals['circuit_id']['reason'] = 'No circuit-ID token (c followed by 7 digits) found in any description'

    # Tie-breaker: first physical L3 interface (LOW weight - never bounces alone)
    first_iface = _find_first_l3_interface(show_ip_int_brief)
    if first_iface:
        signals['first_l3'] = {
            'interface': first_iface, 'fired': True,
            'reason': f'First physical L3 interface with an IP: {first_iface} (low-weight tie-breaker)',
        }
    else:
        signals['first_l3']['reason'] = 'Could not determine first physical L3 interface'

    # STRONG signals decide confidence; first_l3 only breaks ties.
    strong = ['default_route', 'bgp_subnet', 'description', 'circuit_id']
    fired_ifaces = [signals[s]['interface'] for s in strong
                    if signals[s]['fired'] and signals[s]['interface']]

    if not fired_ifaces:
        # No strong signal. Fall back to first_l3 ONLY to name a candidate,
        # but confidence stays low -> no bounce.
        if first_iface:
            return {'interface': first_iface, 'confidence': 'low', 'signals': signals}
        return {'interface': '', 'confidence': 'low', 'signals': signals}

    if len(fired_ifaces) == 1:
        # Single strong signal. If first_l3 agrees, still medium (not high) -
        # tie-breaker can corroborate but never manufacture HIGH on its own.
        return {'interface': fired_ifaces[0], 'confidence': 'medium', 'signals': signals}

    # 2+ strong signals fired - check agreement
    unique = set(_expand_iface(i).lower() for i in fired_ifaces)
    if len(unique) == 1:
        return {'interface': fired_ifaces[0], 'confidence': 'high', 'signals': signals}

    # Strong signals disagree - majority wins, drop to medium. Break exact ties
    # with the first_l3 hint if it matches one of the candidates.
    expanded = [_expand_iface(i).lower() for i in fired_ifaces]
    counts = Counter(expanded)
    top = counts.most_common()
    if len(top) > 1 and top[0][1] == top[1][1] and first_iface:
        fl = _expand_iface(first_iface).lower()
        if fl in expanded:
            for i in fired_ifaces:
                if _expand_iface(i).lower() == fl:
                    return {'interface': i, 'confidence': 'medium', 'signals': signals}
    best = top[0][0]
    for i in fired_ifaces:
        if _expand_iface(i).lower() == best:
            return {'interface': i, 'confidence': 'medium', 'signals': signals}

    return {'interface': fired_ifaces[0], 'confidence': 'medium', 'signals': signals}

# ---------------------------------------------------------------------------
# 9. BGP VRF map from running config
# ---------------------------------------------------------------------------

def parse_bgp_vrf_map(show_running_bgp_section):
    """
    Build {neighbor_ip: vrf_name} map from 'show running-config | section router bgp'.
    Returns dict - empty string for global (default VRF) neighbors.
    """
    vrf_map = {}
    if not show_running_bgp_section:
        return vrf_map

    current_vrf = ''
    for line in show_running_bgp_section.splitlines():
        stripped = line.strip()
        vrf_m = re.match(r'^address-family\s+\S+\s+vrf\s+(\S+)', stripped, re.IGNORECASE)
        if vrf_m:
            current_vrf = vrf_m.group(1)
            continue
        if re.match(r'^exit-address-family', stripped, re.IGNORECASE):
            current_vrf = ''
            continue
        nb_m = re.match(r'^neighbor\s+(\d+\.\d+\.\d+\.\d+)', stripped)
        if nb_m:
            ip = nb_m.group(1)
            # Only set vrf if not already recorded (global takes precedence? No - VRF-specific wins)
            vrf_map[ip] = current_vrf  # Overwrite: last address-family block wins

    return vrf_map

# ---------------------------------------------------------------------------
# 10. BGP summary parser
# ---------------------------------------------------------------------------

def parse_bgp_summary(bgp_all_summary_text):
    """
    Parse 'show ip bgp all summary' into list of neighbor state dicts.
    Returns: [{'neighbor': ip, 'as': str, 'state': str, 'established': bool, 'vrf': str}]
    """
    neighbors = []
    if not bgp_all_summary_text:
        return neighbors

    current_vrf = ''
    in_table = False

    for line in bgp_all_summary_text.splitlines():
        stripped = line.strip()

        # Detect VRF context (IOS/IOS-XE: "For vrf: TEST", IOS-XR: "VRF: TEST")
        vrf_m = re.search(r'(?:[Ff]or vrf|VRF):\s*(\S+)', stripped)
        if vrf_m:
            vrf_name = vrf_m.group(1)
            current_vrf = '' if vrf_name.lower() in ('default', 'global') else vrf_name
            in_table = False
            continue

        # Reset to global on top-level address family without VRF qualifier
        if re.search(r'[Ff]or address family:\s*IPv4 Unicast\s*$', stripped):
            current_vrf = ''
            in_table = False
            continue

        if re.search(r'Neighbor\s+V\s+AS', stripped):
            in_table = True
            continue

        if not in_table:
            continue

        # Capture the full state field including multi-word states
        # like "Idle (Admin)", "No Neg", "Idle (PfxCt)"
        # Pattern: IP  V  AS  MsgRcvd  MsgSent  TblVer  InQ  OutQ  Up/Down  State/PfxRcd
        m = re.match(
            r'^\s*(\d+\.\d+\.\d+\.\d+)\s+\d+\s+(\d+)\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+(.+?)\s*$',
            line
        )
        if m:
            nb_ip = m.group(1)
            as_num = m.group(2)
            state_field = m.group(3).strip()
            established = state_field.isdigit()
            # Admin-shutdown: "Idle (Admin)" - must NOT be cleared
            admin_down = 'admin' in state_field.lower()
            neighbors.append({
                'neighbor': nb_ip,
                'as': as_num,
                'state': 'Established' if established else state_field,
                'established': established,
                'admin_down': admin_down,
                'vrf': current_vrf,
            })

    return neighbors

# ---------------------------------------------------------------------------
# 11. find_stuck_bgp_neighbors
# ---------------------------------------------------------------------------

def find_stuck_bgp_neighbors(bgp_all_summary_text, bgp_vrf_map):
    """
    Find non-Established BGP neighbors.
    bgp_vrf_map: {neighbor_ip: vrf} from parse_bgp_vrf_map.

    Returns list of {neighbor, vrf, state, as_number, hint, admin_down}.

    SAFETY: admin_down=True neighbors are included in the list BUT must NOT
    be cleared - they were intentionally shut. The YAML loop must filter them:
      loop: "{{ stuck_neighbors | rejectattr('admin_down', 'equalto', true) | list }}"
    """
    stuck = []
    all_neighbors = parse_bgp_summary(bgp_all_summary_text)

    for nb in all_neighbors:
        if nb['established']:
            continue
        vrf = bgp_vrf_map.get(nb['neighbor'], nb['vrf'])
        admin_down = nb.get('admin_down', False)
        stuck.append({
            'neighbor': nb['neighbor'],
            'as_number': nb['as'],
            'vrf': vrf,
            'state': nb['state'],
            'hint': bgp_state_hint(nb['state']),
            'admin_down': admin_down,   # True = Idle (Admin) - do NOT clear
        })

    return stuck

# ---------------------------------------------------------------------------
# 12. bgp_state_hint
# ---------------------------------------------------------------------------

def bgp_state_hint(state):
    """Per-state root-cause hint covering both operational and config causes per MOP."""
    _hints = {
        'idle':       'Possible causes: (config) neighbor IP mismatch, wrong AS, or neighbor '
                      'not configured on peer side; (operational) no route to peer, reset by '
                      'operator, or local policy blocking the session.',
        'active':     'BGP is attempting TCP connection but failing. Possible causes: '
                      'TCP port 179 blocked by ACL/firewall/ISP on the path, peer unreachable, '
                      'or peer BGP not running.',
        'connect':    'TCP handshake not completing - SYN sent, no SYN-ACK received. '
                      'Likely transient or upstream TCP filtering.',
        'opensent':   'TCP up, BGP OPEN sent, awaiting peer OPEN. Possible causes: '
                      'AS-number mismatch, BGP version/capability mismatch, or MD5 '
                      'authentication mismatch.',
        'openconfirm':'BGP OPEN received and replied; hold-timer negotiation in progress. '
                      'Possible causes: hold-time mismatch or MD5 authentication mismatch.',
        'established':'Session is UP and exchanging prefixes.',
        'deleted':    'Neighbor configuration deleted or being removed.',
        'unknown':    'State unrecognized - check full "show ip bgp neighbors" output.',
    }
    return _hints.get(state.lower(), f'State: {state} - check "show ip bgp neighbors {{}}" for detail.')

# ---------------------------------------------------------------------------
# 13. build_bgp_clear_command
# ---------------------------------------------------------------------------

def build_bgp_clear_command(neighbor_ip, vrf, platform='ios'):
    """
    Build platform-aware BGP clear command.
    neighbor_ip must be a string IP address (not a dict).

    Platform command matrix:
      ios / ios_xe : clear ip bgp <ip> [vrf <vrf>]
      ios_xr       : clear bgp vrf <vrf> <ip>    (VRF)
                     clear bgp <ip>              (global)

    NOTE: On IOS 15.x, 'clear ip bgp <ip>' (without vrf qualifier) also works
    for VRF neighbors when the neighbor IP is unique across all VRFs.
    The explicit 'vrf' qualifier is used on IOS-XE for precision.
    """
    if not isinstance(neighbor_ip, str):
        raise ValueError(
            f'build_bgp_clear_command expects string IP, got {type(neighbor_ip)}: {neighbor_ip}'
        )

    ip = neighbor_ip.strip()
    if not re.match(r'^\d+\.\d+\.\d+\.\d+$', ip):
        raise ValueError(f'Invalid neighbor IP: {ip!r}')

    has_vrf = bool(vrf and vrf.lower() not in ('', 'default', 'global'))

    if str(platform) == 'ios_xr':
        # IOS-XR: "clear bgp" not "clear ip bgp"
        if has_vrf:
            return f'clear bgp vrf {vrf} {ip}'
        return f'clear bgp {ip}'

    # ios and ios_xe - same syntax
    vrf_part = f' vrf {vrf}' if has_vrf else ''
    return f'clear ip bgp {ip}{vrf_part}'


# ---------------------------------------------------------------------------
# build_bgp_vrf_summary_command - platform-aware VRF BGP summary
# ---------------------------------------------------------------------------

def build_bgp_vrf_summary_command(vrf, platform='ios'):
    """
    Return the correct BGP VRF summary command for the given platform.
    Used in bgp_remediation.yaml VRF cross-check (task 1600).

    ios    : show ip bgp vpnv4 vrf <vrf> summary
    ios_xe : show ip bgp vrf <vrf> summary
    ios_xr : show bgp vrf <vrf> summary
    """
    if not vrf or str(vrf).lower() in ('', 'default', 'global'):
        if str(platform) == 'ios_xr':
            return 'show bgp summary'
        return 'show ip bgp summary'

    if str(platform) == 'ios_xr':
        return f'show bgp vrf {vrf} summary'
    if str(platform) == 'ios':
        return f'show ip bgp vpnv4 vrf {vrf} summary'
    # ios_xe (and unknown - default to XE syntax which is more modern)
    return f'show ip bgp vrf {vrf} summary'


# ---------------------------------------------------------------------------
# get_bgp_discovery_commands - full platform-aware BGP discovery list
# ---------------------------------------------------------------------------

def get_bgp_discovery_commands(platform='ios'):
    """
    Return list of BGP summary commands covering global + all VRF sessions.

    ios    : ['show ip bgp summary', 'show ip bgp vpnv4 all summary']
             Classic IOS may not include VRF sessions in 'show ip bgp all summary'
             so we explicitly use vpnv4 all to catch all VRF neighbors.
    ios_xe : ['show ip bgp all summary']
             Single command covers global + all VRFs.
    ios_xr : ['show bgp summary', 'show bgp all summary']
             'ip bgp' prefix not valid on XR.
    """
    if str(platform) == 'ios_xr':
        return ['show bgp summary', 'show bgp all summary']
    if str(platform) == 'ios':
        return ['show ip bgp summary', 'show ip bgp vpnv4 all summary']
    # ios_xe
    return ['show ip bgp all summary']


# ---------------------------------------------------------------------------
# merge_bgp_summary_outputs - combine outputs into single parse string
# ---------------------------------------------------------------------------

def merge_bgp_summary_outputs(outputs_dict, platform='ios'):
    """
    Given the outputs dict from device_ssh.py, extract and combine the
    BGP summary text appropriate for the platform into a single string
    for parse_bgp_summary to process.
    """
    if not isinstance(outputs_dict, dict):
        return ''

    if str(platform) == 'ios_xr':
        return (outputs_dict.get('show bgp all summary', '')
                or outputs_dict.get('show bgp summary', ''))

    if str(platform) == 'ios':
        # vpnv4 all includes all VRF sessions; global catches non-VPN global peers
        vpnv4 = outputs_dict.get('show ip bgp vpnv4 all summary', '')
        global_v4 = outputs_dict.get('show ip bgp summary', '')
        parts = [p for p in [vpnv4, global_v4] if p]
        return '\n'.join(parts)

    # ios_xe
    return (outputs_dict.get('show ip bgp all summary', '')
            or outputs_dict.get('show ip bgp summary', ''))


# ---------------------------------------------------------------------------
# 14. compute_other_end_ip  (PE IP from /30 or /31)
# ---------------------------------------------------------------------------

def compute_other_end_ip(ip, mask):
    """
    For a /30 or /31 link, return the other-end IP (PE side).
    Returns empty string if subnet is wider than /30.
    """
    if not ip or not mask:
        return ''
    try:
        net = ipaddress.IPv4Network(f'{ip}/{mask}', strict=False)
        prefix_len = net.prefixlen
        if prefix_len == 31:
            hosts = list(net.hosts()) if net.num_addresses > 2 else list(net)
            ce_addr = ipaddress.IPv4Address(ip)
            others = [h for h in hosts if h != ce_addr]
            return str(others[0]) if others else ''
        if prefix_len == 30:
            hosts = list(net.hosts())
            ce_addr = ipaddress.IPv4Address(ip)
            others = [h for h in hosts if h != ce_addr]
            return str(others[0]) if others else ''
    except Exception:
        pass
    return ''

# ---------------------------------------------------------------------------
# 15. derive_pe_ip  (three-method derivation with confidence)
# ---------------------------------------------------------------------------

def derive_pe_ip(wan_ip, wan_mask, bgp_neighbors_text, static_nh):
    """
    Derive PE IP using three methods:
    1. /30 or /31 subnet arithmetic (CE WAN IP -> PE IP)
    2. Static default next-hop
    3. BGP neighbor on WAN subnet

    Returns {'pe_ip': str, 'confidence': 'high'|'medium'|'low'|'none', 'method': str}
    """
    # Method 1: subnet arithmetic
    if wan_ip and wan_mask:
        try:
            net = ipaddress.IPv4Network(f'{wan_ip}/{wan_mask}', strict=False)
            if net.prefixlen in (30, 31):
                pe_ip = compute_other_end_ip(wan_ip, wan_mask)
                if pe_ip:
                    return {
                        'pe_ip': pe_ip,
                        'confidence': 'high',
                        'method': f'/{"30" if net.prefixlen == 30 else "31"} subnet arithmetic - CE: {wan_ip}, PE: {pe_ip}',
                    }
        except Exception:
            pass

    # Method 2: static default next-hop
    if static_nh and re.match(r'^\d+\.\d+\.\d+\.\d+$', static_nh.strip()):
        return {
            'pe_ip': static_nh.strip(),
            'confidence': 'medium',
            'method': f'Static default route next-hop: {static_nh}',
        }

    # Method 3: BGP neighbor on WAN subnet
    if wan_ip and wan_mask and bgp_neighbors_text:
        try:
            wan_net = ipaddress.IPv4Network(f'{wan_ip}/{wan_mask}', strict=False)
            for line in bgp_neighbors_text.splitlines():
                m = re.match(r'^\s*(\d+\.\d+\.\d+\.\d+)', line)
                if m:
                    candidate = ipaddress.IPv4Address(m.group(1))
                    if candidate in wan_net and str(candidate) != wan_ip:
                        return {
                            'pe_ip': str(candidate),
                            'confidence': 'medium',
                            'method': f'BGP neighbor {candidate} on WAN subnet {wan_net}',
                        }
        except Exception:
            pass

    return {'pe_ip': '', 'confidence': 'none', 'method': 'PE IP could not be derived by any available method'}

# ---------------------------------------------------------------------------
# 16. replace_update_with_notify
# ---------------------------------------------------------------------------

def replace_update_with_notify(text):
    """
    VBSM word sanitizer.
    VBSM strips certain words from work_notes:
      'update'  -> 'notify'
      'execute' -> 'run'
    Apply these replacements proactively so output.dat is WYSIWYG.

    Cisco show output uses 'update' in protocol-specific phrases (Last Update,
    update filter list, update-source). Those are protected before the global
    substitution so device output stays verbatim, then restored after.
    """
    if not text:
        return text

    # Cisco output phrases that contain 'update' or 'Update'. These are real
    # protocol terms (show ip protocols / show ip bgp / running-config router bgp).
    # Protect them through the substitution.
    protected = [
        ('Last Update',          '\x00CRD_P01\x00'),
        ('last update',          '\x00CRD_P02\x00'),
        ('update filter list',   '\x00CRD_P03\x00'),
        ('Update filter list',   '\x00CRD_P04\x00'),
        ('update-source',        '\x00CRD_P05\x00'),
        ('Update-source',        '\x00CRD_P06\x00'),
        ('no update-source',     '\x00CRD_P07\x00'),
        ('update source',        '\x00CRD_P08\x00'),
        ('Update source',        '\x00CRD_P09\x00'),
    ]
    for orig, placeholder in protected:
        text = text.replace(orig, placeholder)

    text = re.sub(r'\bupdate\b', 'notify', text, flags=re.IGNORECASE)
    text = re.sub(r'\bexecute\b', 'run', text, flags=re.IGNORECASE)

    for orig, placeholder in protected:
        text = text.replace(placeholder, orig)
    return text

# ---------------------------------------------------------------------------
# 17. diff_running_configs
# ---------------------------------------------------------------------------

def diff_running_configs(pre_config, post_config):
    """
    Produce unified diff of pre and post running-config.
    Returns human-readable diff string, or no-change message.
    """
    if not pre_config and not post_config:
        return 'PRE and POST configs both empty - cannot produce diff.'

    pre_lines = (pre_config or '').splitlines(keepends=True)
    post_lines = (post_config or '').splitlines(keepends=True)

    diff = list(difflib.unified_diff(
        pre_lines,
        post_lines,
        fromfile='running-config (pre-remediation)',
        tofile='running-config (post-remediation)',
        lineterm='',
    ))

    if not diff:
        return 'NO CONFIGURATION CHANGE - Running-config identical before and after automation.'

    return ''.join(diff)

# ---------------------------------------------------------------------------
# 18. format_wan_identification_result
# ---------------------------------------------------------------------------

def format_wan_identification_result(wan_result):
    """
    Format WAN identification result into NOC-readable block.
    wan_result: dict from derive_wan_interface_with_confidence.
    """
    iface = wan_result.get('interface', '')
    confidence = wan_result.get('confidence', 'low')
    signals = wan_result.get('signals', {})

    lines = []
    if iface:
        lines.append(f'[WAN INTERFACE] STATUS: IDENTIFIED')
        lines.append(f'Interface : {iface}')
        lines.append(f'Confidence: {confidence.upper()}')
    else:
        lines.append(f'[WAN INTERFACE] STATUS: NOT IDENTIFIED')
        lines.append(f'Confidence: {confidence.upper()} - Automation cannot safely determine WAN interface.')

    lines.append('')
    lines.append('Signal evaluation:')
    for sig_name, sig_data in signals.items():
        fired = sig_data.get('fired', False)
        reason = sig_data.get('reason', '')
        iface_found = sig_data.get('interface', '')
        mark = 'FIRED' if fired else 'not fired'
        sig_line = f'  {sig_name:<18}: [{mark}]'
        if iface_found:
            sig_line += f' -> {iface_found}'
        lines.append(sig_line)
        lines.append(f'    Reason: {reason}')

    return '\n'.join(lines)

# ---------------------------------------------------------------------------
# 19. parse_ping_result
# ---------------------------------------------------------------------------

def parse_ping_result(ping_json):
    """Parse ping.py JSON output. Returns {'reachable': bool, 'loss': int, 'output': str}."""
    if isinstance(ping_json, str):
        ping_json = safe_json_parse(ping_json)
    loss = ping_json.get('packet_loss', 100)
    return {
        'reachable': loss < 100,
        'loss': loss,
        'output': ping_json.get('output', ''),
        'error': ping_json.get('error', ''),
    }

# ---------------------------------------------------------------------------
# 20. extract_bgp_neighbor_section
# ---------------------------------------------------------------------------

def extract_bgp_neighbor_section(show_running_bgp, neighbor_ip):
    """Extract config lines for a specific BGP neighbor from running-config section."""
    lines = []
    in_block = False
    for line in show_running_bgp.splitlines():
        stripped = line.strip()
        if f'neighbor {neighbor_ip}' in stripped:
            lines.append(stripped)
        elif stripped.startswith('neighbor') and neighbor_ip not in stripped and in_block:
            in_block = False
    return '\n'.join(lines)

# ---------------------------------------------------------------------------
# 21. derive_shortname_from_neid
# ---------------------------------------------------------------------------

def derive_shortname_from_neid(dns_entity_name):
    """Extract customer shortname from NEID (first hyphen-delimited segment)."""
    if not dns_entity_name:
        return ''
    return dns_entity_name.split('-')[0].lower()

# ---------------------------------------------------------------------------
# 22. derive_site_group
# ---------------------------------------------------------------------------

def derive_site_group(dns_entity_name, suffix_chars=3):
    """Compute site group by stripping last N chars from NEID (for ESP partner discovery)."""
    if not dns_entity_name or len(dns_entity_name) <= suffix_chars:
        return dns_entity_name or ''
    return dns_entity_name[:-suffix_chars]

# ---------------------------------------------------------------------------
# 23. normalize_description
# ---------------------------------------------------------------------------

def normalize_description(raw_description):
    r"""
    Normalize Description field: replace literal '\n' with actual newlines.
    Jenkins passes Description as a single-line string with \n tokens.
    """
    if not raw_description:
        return ''
    return raw_description.replace('\\n', '\n')

# ---------------------------------------------------------------------------
# 24. extract_neid_from_description
# ---------------------------------------------------------------------------

def extract_neid_from_description(description_normalized):
    """Extract NEID from normalized description text."""
    m = re.search(r'NEID:\s*(\S+)', description_normalized, re.IGNORECASE)
    return m.group(1) if m else ''

# ---------------------------------------------------------------------------
# 25. is_bgp_active
# ---------------------------------------------------------------------------

def is_bgp_active(bgp_all_summary_text):
    """Return True if BGP is running (not the '% BGP not active' response)."""
    if not bgp_all_summary_text:
        return False
    return 'bgp not active' not in bgp_all_summary_text.lower()

# ---------------------------------------------------------------------------
# 26. check_privilege_denied
# ---------------------------------------------------------------------------

def check_privilege_denied(device_ssh_result):
    """Return True if device_ssh.py result indicates privilege denied."""
    if isinstance(device_ssh_result, str):
        device_ssh_result = safe_json_parse(device_ssh_result)
    return device_ssh_result.get('privilege_denied', False)

# ---------------------------------------------------------------------------
# 27. extract_ssh_output
# ---------------------------------------------------------------------------

def extract_ssh_output(device_ssh_result, command=None):
    """
    Extract command output from device_ssh.py JSON result.
    If command is specified, returns that command's output from 'outputs' dict.
    Otherwise returns single 'output' field.
    """
    if isinstance(device_ssh_result, str):
        device_ssh_result = safe_json_parse(device_ssh_result)

    if command:
        return device_ssh_result.get('outputs', {}).get(command, '')

    return device_ssh_result.get('output', '') or ''

# ---------------------------------------------------------------------------
# 28. summarize_phase_results
# ---------------------------------------------------------------------------

def summarize_phase_results(phase_results):
    """Format phase_results dict into NOC-readable summary."""
    if not phase_results:
        return 'No phase results recorded.'
    lines = []
    for phase, status in sorted(phase_results.items()):
        mark = 'OK' if status == 'ok' else ('--' if status == 'skipped' else 'XX')
        lines.append(f'  {mark} {phase}: {status}')
    return '\n'.join(lines)

# ---------------------------------------------------------------------------
# 29. redact_password
# ---------------------------------------------------------------------------

def redact_password(text):
    """Redact common Cisco password/secret/key patterns from CLI output.

    Covers: 'password [<enc>] <val>', 'secret [<enc>] <val>', 'key [<enc>] <val>'
    (BGP/OSPF/EIGRP MD5), and SNMP 'community <val>'. Encoding digit (0/5/7/9)
    is preserved when present so the line still reads as a config line.
    """
    if not text:
        return text
    text = re.sub(r'(?i)\b(password|secret|key)(\s+\d+)?\s+\S+', r'\1\2 [REDACTED]', text)
    text = re.sub(r'(?i)\b(community)\s+\S+', r'\1 [REDACTED]', text)
    return text

# ---------------------------------------------------------------------------
# 30. precheck_aborted
# ---------------------------------------------------------------------------

def precheck_aborted(device_ssh_result):
    """Return True if device_ssh.py aborted due to pre_check gate failure."""
    if isinstance(device_ssh_result, str):
        device_ssh_result = safe_json_parse(device_ssh_result)
    return device_ssh_result.get('pre_check_failed', False)

# ---------------------------------------------------------------------------
# FilterModule registration
# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# extract_bgp_update_source
# ---------------------------------------------------------------------------
def extract_bgp_update_source(bgp_config_text, neighbor_ip):
    """
    Parse 'show running-config | section router bgp' to find the
    update-source interface for a specific BGP neighbor.
    Returns interface name or '' (empty = use physical exit interface).
    MOP logic: neighbor X update-source <intf> -> ping X source <intf>
    """
    if not bgp_config_text or not neighbor_ip:
        return ''
    ip = str(neighbor_ip).strip()
    for line in str(bgp_config_text).splitlines():
        m = re.match(
            r'\s*neighbor\s+' + re.escape(ip) + r'\s+update-source\s+(\S+)',
            line
        )
        if m:
            return m.group(1)
    return ''


# ---------------------------------------------------------------------------
# verify_bgp_neighbor_config
# ---------------------------------------------------------------------------
def verify_bgp_neighbor_config(bgp_config_text, stuck_neighbors):
    """
    After failed BGP clear, verify config for each stuck neighbor.
    Checks: neighbor present, remote-AS, local-AS, update-source, shutdown flag.
    Returns list of dicts with 'verdict' key for NOC guidance.
    """
    if not bgp_config_text or not stuck_neighbors:
        return []
    results = []
    for nb in stuck_neighbors:
        ip = str(nb.get('neighbor', '')).strip()
        if not ip:
            continue
        in_cfg = remote_as = local_as = update_src = ''
        shutdown_cfg = False
        for line in str(bgp_config_text).splitlines():
            s = line.strip()
            if 'neighbor ' + ip not in s:
                continue
            in_cfg = True
            m = re.match(r'neighbor\s+\S+\s+remote-as\s+(\d+)', s)
            if m:
                remote_as = m.group(1)
            m = re.match(r'neighbor\s+\S+\s+local-as\s+(\d+)', s)
            if m:
                local_as = m.group(1)
            m = re.match(r'neighbor\s+\S+\s+update-source\s+(\S+)', s)
            if m:
                update_src = m.group(1)
            if 'shutdown' in s:
                shutdown_cfg = True
        verdict = (
            'NEIGHBOR_NOT_IN_CONFIG'    if not in_cfg else
            'ADMIN_SHUTDOWN_IN_CONFIG'  if shutdown_cfg else
            'MISSING_REMOTE_AS'         if not remote_as else
            'CONFIG_LOOKS_CORRECT'
        )
        results.append({
            'neighbor': ip,
            'vrf': nb.get('vrf', ''),
            'state': nb.get('state', ''),
            'in_config': bool(in_cfg),
            'remote_as': remote_as,
            'local_as': local_as,
            'update_source': update_src,
            'shutdown_in_config': shutdown_cfg,
            'verdict': verdict,
        })
    return results


# ---------------------------------------------------------------------------
# parse_bgp_neighbor_tcp_state
# ---------------------------------------------------------------------------
def parse_bgp_neighbor_tcp_state(text):
    """
    Parse `show ip bgp neighbors <ip>` output and extract TCP-layer evidence
    needed to diagnose whether BGP is stuck due to TCP/179 blocking, peer-side
    BGP not listening, or BGP-protocol-layer failure.

    Fields harvested from real Cisco IOS/IOS-XE output:
      - 'BGP state = <state>'
      - 'Connection state is <STATE>' (TCP layer: IDLE / LISTEN / SYNSENT /
                                       ESTAB / CLOSE_WAIT / FINWAIT-1 / ...)
      - 'Connections established <N>; dropped <M>'
      - 'Last reset <duration> ago, due to ...'  / 'Last reset never'
      - 'Opens:           Sent <X>     Rcvd <Y>'
      - 'Notifications:   Sent <X>     Rcvd <Y>'
      - 'Local host: <ip>, Local port: <p>' / 'Foreign host: <ip>, Foreign port: <p>'

    Returns dict (all keys always present, empty string when not found):
      {
        bgp_state, tcp_state,
        established_count, dropped_count,
        opens_sent, opens_rcvd,
        notif_sent, notif_rcvd,
        last_reset, last_reset_reason,
        local_port, foreign_port,
      }
    """
    fields = {
        'bgp_state': '', 'tcp_state': '',
        'established_count': '', 'dropped_count': '',
        'opens_sent': '', 'opens_rcvd': '',
        'notif_sent': '', 'notif_rcvd': '',
        'last_reset': '', 'last_reset_reason': '',
        'local_port': '', 'foreign_port': '',
    }
    if not text or not isinstance(text, str):
        return fields

    m = re.search(r'BGP state\s*=\s*([A-Za-z]+)', text)
    if m:
        fields['bgp_state'] = m.group(1)

    m = re.search(r'Connection state is\s+([A-Z_\- ]+?)(?:,|$)', text, re.MULTILINE)
    if m:
        fields['tcp_state'] = m.group(1).strip()

    m = re.search(r'Connections established\s+(\d+)\s*;\s*dropped\s+(\d+)', text)
    if m:
        fields['established_count'] = m.group(1)
        fields['dropped_count']     = m.group(2)

    # Two-column counters: "Opens:    Sent 3    Rcvd 0"
    m = re.search(r'Opens:\s*(\d+)\s+(\d+)', text)
    if m:
        fields['opens_sent'] = m.group(1)
        fields['opens_rcvd'] = m.group(2)
    m = re.search(r'Notifications:\s*(\d+)\s+(\d+)', text)
    if m:
        fields['notif_sent'] = m.group(1)
        fields['notif_rcvd'] = m.group(2)

    if 'Last reset never' in text:
        fields['last_reset']        = 'never'
        fields['last_reset_reason'] = ''
    else:
        m = re.search(r'Last reset\s+([^\n,]+?)(?:,\s*due to\s+([^\n]+))?\n', text)
        if m:
            fields['last_reset']        = m.group(1).strip()
            fields['last_reset_reason'] = (m.group(2) or '').strip()

    m = re.search(r'Local host:\s*\S+,\s*Local port:\s*(\d+)', text)
    if m:
        fields['local_port'] = m.group(1)
    m = re.search(r'Foreign host:\s*\S+,\s*Foreign port:\s*(\d+)', text)
    if m:
        fields['foreign_port'] = m.group(1)

    return fields


# ---------------------------------------------------------------------------
# evaluate_bgp_underlay_with_tcp
# ---------------------------------------------------------------------------
def evaluate_bgp_underlay_with_tcp(stuck_neighbors, all_outputs):
    """
    Three-way verdict per neighbor combining ICMP ping and TCP-layer evidence
    from `show ip bgp neighbors`. Replaces the prior binary (clearable /
    l3_blocked) split with: clearable, tcp179_blocked, auth_or_as_mismatch,
    l3_blocked, undetermined.

    Args:
      stuck_neighbors: list of dicts (neighbor, vrf, state, ...).
      all_outputs: FLAT dict of {command_string: output_text} as produced by
        the jump_ssh.py batch run. Keys look like:
          'ping 192.168.31.124 source Gi0/0 repeat 5 timeout 3'
          'show ip bgp neighbors 192.168.31.124'
          'show ip route 192.168.31.124'
        Per-neighbor selection is done by matching the neighbor IP inside the
        command string (robust against VRF / source-interface variants).

    Returns: list of dicts, one per non-admin-down neighbor, with fields:
      ping_ok, bgp_state, tcp_state, opens_sent, opens_rcvd,
      established_count, dropped_count, last_reset, last_reset_reason,
      verdict, verdict_reason.

    Decision matrix:
      ping_fail                                              -> 'l3_blocked'
      ping_ok + established_count > 0                        -> 'clearable'
      ping_ok + opens_sent > 0, opens_rcvd == 0              -> 'tcp179_blocked'
      ping_ok + opens_sent > 0, opens_rcvd > 0, reset reason
              matches mismatch/auth/open                     -> 'auth_or_as_mismatch'
      ping_ok + tcp_state in (IDLE,LISTEN) + opens_sent == 0 -> 'tcp179_blocked'
      ping_ok + insufficient evidence                        -> 'undetermined'
    """
    if not stuck_neighbors:
        return []
    if not isinstance(all_outputs, dict):
        all_outputs = {}
    results = []
    for nb in stuck_neighbors:
        ip = str(nb.get('neighbor', '')).strip()
        if not ip:
            continue
        # Skip admin-down neighbors - they go through a different gate.
        if nb.get('admin_down'):
            continue

        # Slice the flat outputs to this neighbor's commands.
        ping_txt = ''
        bgp_nb_txt = ''
        for k, v in all_outputs.items():
            if ip not in k:
                continue
            ks = k.lstrip()
            if ks.startswith('ping ') and not ping_txt:
                ping_txt = str(v or '')
            elif (ks.startswith('show ip bgp neighbors')
                  or ks.startswith('show ip bgp vpnv4 vrf')
                  or (ks.startswith('show bgp ') and 'neighbor' in ks)) and not bgp_nb_txt:
                bgp_nb_txt = str(v or '')

        ping_ok = bool(re.search(r'Success rate is\s+([1-9]\d*)\s*percent', ping_txt))
        tcp = parse_bgp_neighbor_tcp_state(bgp_nb_txt)

        opens_sent  = int(tcp['opens_sent']) if tcp['opens_sent'].isdigit() else 0
        opens_rcvd  = int(tcp['opens_rcvd']) if tcp['opens_rcvd'].isdigit() else 0
        established = int(tcp['established_count']) if tcp['established_count'].isdigit() else 0
        tcp_state   = tcp['tcp_state'].upper()
        reset_reason = tcp['last_reset_reason'].lower()

        if not ping_ok:
            verdict, why = 'l3_blocked', (
                'ICMP to neighbor failed - underlay (L3/ACL/interface) is broken. '
                'Hard clear cannot recover BGP until L3 is restored. Fix Layer-3 first.'
            )
        elif established > 0:
            verdict, why = 'clearable', (
                f'TCP/179 historically established ({established} time(s)) - issue is at '
                'BGP-protocol layer (flap, hold-down). Hard clear is appropriate.'
            )
        elif opens_sent > 0 and opens_rcvd == 0:
            verdict, why = 'tcp179_blocked', (
                f'Local BGP sent {opens_sent} OPEN message(s), received 0 back. TCP '
                'path likely reaches peer but peer either silently drops the OPEN '
                '(upstream ACL/firewall on TCP/179) or its BGP process is not running. '
                'Hard clear will not help - fix path security policy / peer BGP.'
            )
        elif opens_sent > 0 and opens_rcvd > 0 and (
                'mismatch' in reset_reason or 'auth' in reset_reason or 'open' in reset_reason):
            verdict, why = 'auth_or_as_mismatch', (
                f'OPEN exchanged (sent {opens_sent}, rcvd {opens_rcvd}) but session reset: '
                f'"{tcp["last_reset_reason"]}". Likely AS-number, capability, or MD5-auth '
                'mismatch. Verify config on both sides; clear alone will not fix.'
            )
        elif tcp_state in ('IDLE', 'LISTEN') and opens_sent == 0:
            verdict, why = 'tcp179_blocked', (
                f'TCP connection state {tcp_state or "unknown"} with no OPEN attempts - '
                'local BGP has not yet completed SYN, or every SYN attempt is being '
                'dropped. Suspect upstream ACL/firewall blocking TCP/179.'
            )
        else:
            verdict, why = 'undetermined', (
                'L3 reachable but TCP/BGP-layer evidence is inconclusive. Allowing '
                'clear under read-only gate; observe post-clear state.'
            )

        results.append({
            'neighbor': ip,
            'vrf': nb.get('vrf', ''),
            'state': nb.get('state', ''),
            'as_number': nb.get('as_number', ''),
            'ping_ok': ping_ok,
            'bgp_state': tcp['bgp_state'],
            'tcp_state': tcp['tcp_state'],
            'opens_sent': tcp['opens_sent'],
            'opens_rcvd': tcp['opens_rcvd'],
            'established_count': tcp['established_count'],
            'dropped_count': tcp['dropped_count'],
            'last_reset': tcp['last_reset'],
            'last_reset_reason': tcp['last_reset_reason'],
            'verdict': verdict,
            'verdict_reason': why,
        })
    return results


# ---------------------------------------------------------------------------
# build_bgp_underlay_commands
# ---------------------------------------------------------------------------
def build_bgp_underlay_commands(nb, wan_interface, platform='ios'):
    """
    Build BGP underlay reachability commands for one stuck neighbor.
    MOP: ping <neighbor> source <update-source or WAN>, traceroute, show arp,
    plus `show ip bgp neighbors <ip>` to expose TCP-layer state (M3) -
    Connection state / Connections established / dropped / Opens Sent vs Rcvd /
    Last reset reason. Reading this is preferred over an active `telnet <ip> 179`
    probe because it carries no risk of leaving the SSH session inside an
    interactive telnet sub-session if TCP succeeds.
    """
    if not isinstance(nb, dict):
        return []
    neighbor_ip = str(nb.get('neighbor', '')).strip()
    vrf         = str(nb.get('vrf', '')).strip()
    has_vrf     = bool(vrf and vrf.lower() not in ('', 'default', 'global'))
    if not neighbor_ip:
        return []
    update_source = str(nb.get('update_source', '')).strip()
    source_intf   = update_source or (str(wan_interface).strip() if wan_interface else '')
    cmds = []
    if str(platform) == 'ios_xr':
        pfx = f'vrf {vrf} ' if has_vrf else ''
        cmds.append(f'ping {pfx}{neighbor_ip} count 5 timeout 3')
        cmds.append(f'traceroute {pfx}{neighbor_ip} timeout 1 maxttl 5')
        cmds.append(f'show arp {pfx}| utility grep {neighbor_ip}')
        cmds.append(f'show route {pfx}{neighbor_ip}')
        # IOS-XR equivalent for TCP/179 + last-error evidence
        cmds.append(f'show bgp {("vrf " + vrf + " ") if has_vrf else ""}neighbor {neighbor_ip}')
    else:
        if has_vrf:
            cmds.append(f'ping vrf {vrf} {neighbor_ip} repeat 5 timeout 3')
            cmds.append(f'traceroute vrf {vrf} {neighbor_ip} timeout 1 probe 1 ttl 1 5')
            cmds.append(f'show ip arp vrf {vrf} | include {neighbor_ip}')
            cmds.append(f'show ip route vrf {vrf} {neighbor_ip}')
            cmds.append(f'show ip bgp vpnv4 vrf {vrf} neighbors {neighbor_ip}')
        else:
            src = f' source {source_intf}' if source_intf else ''
            cmds.append(f'ping {neighbor_ip}{src} repeat 5 timeout 3')
            cmds.append(f'traceroute {neighbor_ip} timeout 1 probe 1 ttl 1 5')
            cmds.append(f'show ip arp | include {neighbor_ip}')
            cmds.append(f'show ip route {neighbor_ip}')
            cmds.append(f'show ip bgp neighbors {neighbor_ip}')
    return cmds


# ---------------------------------------------------------------------------
# build_bgp_neighbor_ping_cmd -
# ---------------------------------------------------------------------------
def build_bgp_neighbor_ping_cmd(nb, platform='ios'):
    """Build platform/VRF-aware ping command for a BGP neighbor.
    Used post-clear to ping neighbor IP (not MgmtIP) per MOP."""
    if not isinstance(nb, dict):
        return ''
    ip  = str(nb.get('neighbor', '')).strip()
    vrf = str(nb.get('vrf', '')).strip()
    has_vrf = bool(vrf and vrf.lower() not in ('', 'default', 'global'))
    if not ip:
        return ''
    if str(platform) == 'ios_xr':
        return f'ping vrf {vrf} {ip} count 5 timeout 3' if has_vrf else f'ping {ip} count 5 timeout 3'
    return f'ping vrf {vrf} {ip} repeat 5 timeout 3' if has_vrf else f'ping {ip} repeat 5 timeout 3'


# ---------------------------------------------------------------------------
# evaluate_underlay_reachability -
# Match each stuck neighbor to its underlay ping output (robust to the
# "source <intf>" variant and VRF), decide L3-reachable, and carry the
# matched ping/traceroute/arp text so the log task does not reconstruct keys.
# ---------------------------------------------------------------------------
def evaluate_underlay_reachability(stuck_neighbors, underlay_outputs):
    """
    Returns one dict per non-admin-down neighbor:
      {neighbor, vrf, as_number, state, admin_down, update_source,
       reachable (bool), ping_text, tracert_text, arp_text}
    reachable=True only when the ping output shows a non-zero success rate.
    """
    if not stuck_neighbors:
        return []
    outputs = underlay_outputs if isinstance(underlay_outputs, dict) else {}

    def _match(prefixes, ip, vrf_token):
        for key, val in outputs.items():
            k = key.strip()
            if not any(k.startswith(p) for p in prefixes):
                continue
            if ip not in k:
                continue
            if vrf_token and vrf_token not in k:
                continue
            if (not vrf_token) and ' vrf ' in k:
                continue
            return val
        return ''

    def _reachable(ping_text):
        t = ping_text or ''
        if 'Success rate is 0' in t:
            return False
        if 'Success rate is' in t:        # any non-zero percentage
            return True
        if '!!!' in t:
            return True
        # weak fallback: a bare '!' with no success-rate line
        if '!' in t and 'Success rate' not in t:
            return True
        return False

    results = []
    for nb in stuck_neighbors:
        if not isinstance(nb, dict):
            continue
        if nb.get('admin_down', False):
            continue
        ip  = str(nb.get('neighbor', '')).strip()
        vrf = str(nb.get('vrf', '')).strip()
        has_vrf = bool(vrf and vrf.lower() not in ('', 'default', 'global'))
        vtok = f'vrf {vrf}' if has_vrf else ''
        ping_text    = _match(('ping',), ip, vtok)
        tracert_text = _match(('traceroute',), ip, vtok)
        arp_text     = _match(('show ip arp', 'show arp'), ip, vtok)
        results.append({
            'neighbor':      ip,
            'vrf':           vrf,
            'as_number':     nb.get('as_number', ''),
            'state':         nb.get('state', ''),
            'state_hint':    bgp_state_hint(nb.get('state', '')),
            'admin_down':    False,
            'update_source': nb.get('update_source', ''),
            'reachable':     _reachable(ping_text),
            'ping_text':     ping_text or '(not executed)',
            'tracert_text':  tracert_text or '(not executed)',
            'arp_text':      arp_text or '(no ARP entry)',
        })
    return results


# ---------------------------------------------------------------------------
# VRRP/HSRP virtual-IP parsing + primary LAN IP derivation (jump-host)
# ---------------------------------------------------------------------------

def find_partner_candidates(devices, primary_neid, primary_ip, site_prefix=''):
    """
    Find HA partner router candidates for the primary from an ESP device list.

    ESP API facts (validated in SIT/PROD): server-side deviceType / dnsShortName
    filters do NOT work, so all role/type filtering is done here in Python. The
    ESP query is scoped by shortName + dnsEntityName=-<location>- (see
    partner_discovery.yaml), so `devices` is already the site/location set.

    Site-matching is TWO-TIER, because Verizon HA pairs use two conventions and
    only the network team can say which applies at a given site:
      - precise: partner shares the NEID minus its last 3 chars (the cinfo key,
                 e.g. 'hcla-munchen-41927159e') - same serial, index 001 vs 002.
      - broad  : partner shares only the first two NEID tokens (customer +
                 location, e.g. 'stnb-saopaulo-') - serial MAY differ
                 (PROD ticket 2026092303540: stnb-saopaulo-42815155e001 partnered
                 stnb-saopaulo-16085837e002).
    We try the precise prefix first; only if it yields nothing do we fall back to
    the broad prefix. This finds same-serial pairs precisely and different-serial
    pairs via fallback, and never declares 'single-router' while a same-location
    router exists. The chosen secondary NEID is always shown in the NOC ticket so
    a human can catch a wrong pick.

    Handles both ESP response shapes (wrapped {"device": {...}} and unwrapped).
    Excludes: the primary itself (by NEID and IP), explicitly unmanaged devices,
    and known non-router device types.
    """
    _SKIP_TYPES = frozenset([
        'vmanage', 'vsmart', 'vbond', 'director', 'controller',
        'modem', 'switch', 'ap', 'access point', 'firewall',
        'wlc', 'access-point', 'wireless',
    ])
    parts = str(primary_neid).split('-')
    broad_prefix = ('-'.join(parts[:2]) + '-') if len(parts) >= 2 else str(primary_neid)
    # Precise prefix: the caller's site_group (NEID minus last 3), else derive it.
    precise_prefix = str(site_prefix).strip() if (site_prefix and str(site_prefix).strip()) \
        else (str(primary_neid)[:-3] if len(str(primary_neid)) > 3 else str(primary_neid))

    def _is_managed(dev):
        raw = dev.get('isManaged', True)          # missing -> assume managed (keep)
        if isinstance(raw, str):
            return raw.strip().lower() not in ('false', 'no', '0', 'n', '')
        return True if raw is None else bool(raw)

    def _match(prefix):
        pfx = str(prefix).lower()
        out = []
        for item in (devices or []):
            if not isinstance(item, dict):
                continue
            dev = item.get('device', item)
            if not isinstance(dev, dict):
                continue
            neid  = dev.get('dnsEntityName', '') or ''
            ip    = dev.get('mgmtIPAddress', '') or ''
            dtype = (dev.get('deviceType', '') or '').lower().strip()
            if neid == primary_neid or (ip and ip == primary_ip):
                continue
            # v51 - skip child/logical sub-records of the primary: a NEID that is
            # the full primary NEID plus a suffix (e.g. '<primary>f009') is a
            # feature/child object of the SAME device, never a real HA peer. A
            # genuine peer (e.g. '...e002') does NOT start with the primary's full
            # NEID, so same-serial e001/e002 and different-serial pairs are
            # unaffected. (PROD build 8916: ESP returned 'aecom-...e001f009'.)
            if neid != primary_neid and str(neid).startswith(str(primary_neid)):
                continue
            # v51 - skip candidates with no management IP: they cannot be reached,
            # so selecting one made partner_login SSH an empty host and fail with
            # 'Either ip or host must be set' (PROD build 8916). Dropping it lets
            # the run fall through to the correct single-router escalation.
            if not str(ip).strip():
                continue
            if not _is_managed(dev):
                continue
            if any(kw in dtype for kw in _SKIP_TYPES):
                continue
            if not str(neid).lower().startswith(pfx):
                continue
            out.append(dev)
        out.sort(key=lambda d: str(d.get('dnsEntityName', '')))
        return out

    result = _match(precise_prefix)
    if not result and broad_prefix.lower() != precise_prefix.lower():
        result = _match(broad_prefix)
    return result


def reject_non_router_devices(candidates):
    """
    Filter out non-router device types from ESP inventory candidate list.

    The ESP deviceType URL filter is confirmed non-functional - it returns all
    devices regardless of the parameter. This function provides the Python-side
    filtering that the URL param was supposed to give, so that switches,
    firewalls, controllers, etc. are never selected as partner router candidates.

    Handles both flat response shape (deviceType at top level) and nested shape
    (device.deviceType sub-object) since the exact ESP response format is
    environment-dependent.
    """
    _SKIP_TYPES = frozenset([
        'vmanage', 'vsmart', 'vbond', 'director', 'controller',
        'modem', 'switch', 'ap', 'access point', 'firewall',
        'wlc', 'access-point', 'wireless',
    ])
    result = []
    for item in candidates:
        if not isinstance(item, dict):
            continue
        # Flat shape: item has 'deviceType' directly
        # Nested shape: item has 'device' sub-dict with 'deviceType'
        dtype = (
            item.get('deviceType', '')
            or (item.get('device') or {}).get('deviceType', '')
        ).lower().strip()
        if any(kw in dtype for kw in _SKIP_TYPES):
            continue
        result.append(item)
    return result


def parse_vty_acl(vty_section, access_class_lines, ip_access_lists, secondary_lan_ip=''):
    """
    Parse VTY/ACL config gathered from the SECONDARY router to explain a refused
    SSH jump to the primary. The primary's own ACL is unreachable (that's why the
    jump failed), but managed CE pairs are provisioned from the same template, so
    the secondary's VTY ACL is the best available evidence of the site policy.

    Inputs (all raw CLI text from the secondary):
      vty_section        : 'show running-config | section vty'
      access_class_lines : 'show running-config | include access-class'
      ip_access_lists    : 'show ip access-lists'

    Returns dict:
      {vty_lines, access_class_in, access_class_out, acl_name,
       acl_rules, secondary_permitted, summary}
    """
    out = {
        'vty_lines': [], 'access_class_in': '', 'access_class_out': '',
        'acl_name': '', 'acl_rules': [], 'secondary_permitted': None, 'summary': '',
    }

    # VTY line ranges present (e.g. "line vty 0 4")
    for ln in (vty_section or '').splitlines():
        m = re.match(r'\s*(line vty\s+\d+(?:\s+\d+)?)', ln, re.I)
        if m:
            out['vty_lines'].append(m.group(1).strip())

    # access-class <name|num> in|out  (the ACL bound to VTY)
    for ln in ((access_class_lines or '') + '\n' + (vty_section or '')).splitlines():
        m = re.search(r'access-class\s+(\S+)\s+(in|out)', ln, re.I)
        if m:
            name, direction = m.group(1), m.group(2).lower()
            if direction == 'in' and not out['access_class_in']:
                out['access_class_in'] = name
                out['acl_name'] = name      # inbound is the one that gates SSH to the VTY
            elif direction == 'out' and not out['access_class_out']:
                out['access_class_out'] = name

    # If only an outbound class exists, still surface it as the acl_name fallback
    if not out['acl_name'] and out['access_class_out']:
        out['acl_name'] = out['access_class_out']

    # Extract the rules for the bound ACL from 'show ip access-lists'
    if out['acl_name'] and ip_access_lists:
        capturing = False
        for ln in ip_access_lists.splitlines():
            header = re.match(r'^(?:Standard|Extended)?\s*IP access list\s+(\S+)', ln, re.I) \
                or re.match(r'^ip access-list\s+\w+\s+(\S+)', ln, re.I)
            if header:
                capturing = (header.group(1) == out['acl_name'])
                continue
            if capturing:
                r = ln.strip()
                if r and (r.startswith(('permit', 'deny')) or re.match(r'^\d+\s+(permit|deny)', r)):
                    out['acl_rules'].append(r)

    # Does the secondary's own LAN IP appear permitted? (heuristic: if the
    # secondary can be reached but the primary refuses, the ACL likely permits
    # a mgmt range that does not include the secondary's jump source.)
    sec = str(secondary_lan_ip).strip()
    if out['acl_rules'] and sec:
        permit_hit = any('permit' in r and (sec in r) for r in out['acl_rules'])
        deny_hit = any('deny' in r and (sec in r) for r in out['acl_rules'])
        if permit_hit and not deny_hit:
            out['secondary_permitted'] = True
        elif deny_hit:
            out['secondary_permitted'] = False

    # Human summary line for the NOC
    parts = []
    if out['vty_lines']:
        parts.append('VTY: ' + ', '.join(out['vty_lines']))
    if out['acl_name']:
        parts.append(f"access-class {out['acl_name']} in" if out['access_class_in']
                     else f"access-class {out['acl_name']}")
    else:
        parts.append('no access-class found on secondary VTY (primary policy may still differ)')
    if out['acl_rules']:
        parts.append(f"{len(out['acl_rules'])} ACL rule(s) captured from secondary")
    out['summary'] = '; '.join(parts)
    return out


def parse_fhrp_state(show_vrrp_brief, show_standby_brief='', secondary_lan_ip=''):
    """
    Parse VRRP ('show vrrp brief') or HSRP ('show standby brief') run on the
    secondary CE. Returns a dict:
      {vip, active_ip, standby_ip, protocol, secondary_is_active}

    show standby brief (HSRP):
      Interface Grp Pri P State   Active         Standby        Virtual IP
      Gi0/0     1   90  P Standby 192.168.31.75  local          192.168.31.125
    show vrrp brief (VRRP):
      Interface Grp Pri Time Own Pre State  Master addr    Group addr
      Gi0/0     1   100 ...      Y  Master  192.168.31.75  192.168.31.125

    'local' denotes the secondary itself. For HSRP the last IP is the VIP and
    the Active column points at the primary. For VRRP the last IP is the VIP
    and the Master addr is the primary.
    """
    result = {'vip': '', 'active_ip': '', 'standby_ip': '',
              'protocol': '', 'secondary_is_active': False}

    def _resolve_local(token, sec_ip):
        return sec_ip if token.lower() == 'local' else token

    if show_standby_brief:
        for line in show_standby_brief.splitlines():
            if not re.match(r'^\s*(Gi|Te|Fa|Et|Vl|Po|Hu|Fo)\S*\s+\d+', line):
                continue
            cols = line.split()
            ips = [c for c in cols if re.match(r'^\d+\.\d+\.\d+\.\d+$', c)]
            has_local = 'local' in [c.lower() for c in cols]
            state = next((c for c in cols if c.lower() in ('active', 'standby', 'init', 'listen', 'speak')), '')
            if not ips and not has_local:
                continue
            result['protocol'] = 'hsrp'
            result['vip'] = ips[-1] if ips else ''
            try:
                vip_idx = cols.index(result['vip'])
                active_tok = cols[vip_idx - 2]
                standby_tok = cols[vip_idx - 1]
                result['active_ip'] = _resolve_local(active_tok, secondary_lan_ip)
                result['standby_ip'] = _resolve_local(standby_tok, secondary_lan_ip)
            except (ValueError, IndexError):
                pass
            result['secondary_is_active'] = state.lower() == 'active'
            return result

    if show_vrrp_brief:
        for line in show_vrrp_brief.splitlines():
            if not re.match(r'^\s*(Gi|Te|Fa|Et|Vl|Po|Hu|Fo)\S*\s+\d+', line):
                continue
            cols = line.split()
            ips = [c for c in cols if re.match(r'^\d+\.\d+\.\d+\.\d+$', c)]
            state = next((c for c in cols if c.lower() in ('master', 'backup', 'init')), '')
            if not ips:
                continue
            result['protocol'] = 'vrrp'
            result['vip'] = ips[-1]
            if len(ips) >= 2:
                result['active_ip'] = _resolve_local(ips[-2], secondary_lan_ip)
            result['secondary_is_active'] = state.lower() == 'master'
            return result

    return result


def parse_vrrp_vip(show_vrrp_brief, show_standby_brief=''):
    """Backward-compatible VIP-only accessor."""
    return parse_fhrp_state(show_vrrp_brief, show_standby_brief).get('vip', '')


def derive_primary_jump_targets(fhrp_state, secondary_lan_ip=''):
    """
    Return the SSH jump target for the secondary->primary login when the
    primary's management IP is down but the device is alive on the LAN.

    Per MOP: the jump uses the FHRP virtual IP (VRRP/HSRP VIP) only - never a
    physical interface IP. The VIP always resolves to whichever node is Active,
    which is the primary when only its management loopback is down.

    Returns a single-element list with the VIP, or [] if no VIP was parsed.
    """
    if not isinstance(fhrp_state, dict):
        return []
    vip = str(fhrp_state.get('vip', '')).strip()
    if not re.match(r'^\d+\.\d+\.\d+\.\d+$', vip):
        return []
    sec = str(secondary_lan_ip).strip()
    if vip == sec:
        return []
    return [vip]


def fhrp_peer_ips(show_vrrp_brief='', show_standby_brief='', secondary_lan_ip=''):
    """
    v53 [display-only, additive, READ-ONLY] - collect the FHRP PEER's real LAN
    IP(s) - i.e. the PRIMARY router's LAN-side IP when reached from the
    secondary - across ALL groups, from 'show vrrp brief' and/or
    'show standby brief' captured on the secondary CE. Handles load-shared
    multi-group designs (a router is Backup on some groups, Master on others).

    Returns an ordered, de-duplicated list of peer IP strings. NEVER raises;
    returns [] on empty / unparseable input, so a caller can simply print
    nothing when no peer IP is available.

    SAFETY: this helper is NOT consumed by any decision / jump / close /
    escalate logic. parse_fhrp_state() and derive_primary_jump_targets() are
    left byte-for-byte untouched; this is purely additive evidence.

    Extraction rules (matched to the Site A/B dummy captures; the exact brief
    column layout MUST still be confirmed on a real IOS-XE device):
      VRRP ('show vrrp brief'): only a BACKUP line exposes the peer - its
        'Master addr' column (the IP immediately before the Group/virtual addr)
        is the remote master = the primary's real IP. A MASTER line's master
        addr is the secondary itself (sometimes tagged '(local)') and is
        deliberately skipped, so the secondary's own IP is never reported.
      HSRP ('show standby brief'): the Active/Standby address that is not
        'local' is the peer's real IP, in either role (both routers send
        hellos). The last IP on the line (the Virtual IP) is excluded.
      Any address equal to secondary_lan_ip is dropped as a final safety net.
    """
    peers = []
    sec = str(secondary_lan_ip or '').strip()
    _ip_re = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')
    _if_re = re.compile(r'^\s*(Gi|Te|Fa|Et|Vl|Po|Hu|Fo)\S*\s+\d+')

    def _add(ip):
        ip = str(ip or '').strip()
        # drop the unspecified address (VRRP 'Init' groups print 0.0.0.0 as the
        # master addr - seen in prod) and the secondary's own IP.
        if _ip_re.match(ip) and ip not in ('0.0.0.0',) and ip != sec and ip not in peers:
            peers.append(ip)

    # HSRP: Interface Grp Pri [P] State Active Standby VirtualIP
    try:
        for line in str(show_standby_brief or '').splitlines():
            if not _if_re.match(line):
                continue
            iptoks = [c for c in line.split() if _ip_re.match(c)]
            if len(iptoks) < 2:
                continue
            # last IP = Virtual IP (excluded); the rest (non-'local') = peer(s)
            for tok in iptoks[:-1]:
                _add(tok)
    except (TypeError, ValueError, AttributeError) as exc:
        log.debug('fhrp_peer_ips hsrp: %s', exc)

    # VRRP: Interface Grp Pri Time Own Pre State Master-addr Group-addr
    try:
        for line in str(show_vrrp_brief or '').splitlines():
            if not _if_re.match(line):
                continue
            cols = line.split()
            state = next((c for c in cols
                          if c.lower() in ('master', 'backup', 'init')), '')
            if state.lower() != 'backup':
                continue  # only a BACKUP line reveals the remote master (peer)
            iptoks = [c for c in cols if _ip_re.match(c)]
            if len(iptoks) < 2:
                continue
            _add(iptoks[-2])  # master addr = peer; iptoks[-1] is the virtual IP
    except (TypeError, ValueError, AttributeError) as exc:
        log.debug('fhrp_peer_ips vrrp: %s', exc)

    return peers


def fhrp_peer_targets(show_vrrp_brief='', show_standby_brief='', secondary_lan_ip=''):
    """Like fhrp_peer_ips, but returns ordered, de-duplicated dicts
    [{'interface': <intf>, 'ip': <peer real IP>}] so the caller can look up the
    per-interface VRF (show running-config interface <intf>) for a VRF-aware
    login. Same per-site, Backup-line (VRRP) / non-local (HSRP) rules; never
    raises; [] on empty/unparseable input."""
    out = []
    sec = str(secondary_lan_ip or '').strip()
    _ip_re = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')
    _if_re = re.compile(r'^\s*((?:Gi|Te|Fa|Et|Vl|Po|Hu|Fo)\S*)\s+\d+')

    def _add(intf, ip):
        ip = str(ip or '').strip()
        if (_ip_re.match(ip) and ip not in ('0.0.0.0',) and ip != sec
                and not any(d['ip'] == ip for d in out)):
            out.append({'interface': intf, 'ip': ip})

    try:
        for line in str(show_standby_brief or '').splitlines():
            m = _if_re.match(line)
            if not m:
                continue
            intf = m.group(1)
            iptoks = [c for c in line.split() if _ip_re.match(c)]
            if len(iptoks) < 2:
                continue
            for tok in iptoks[:-1]:
                _add(intf, tok)
    except (TypeError, ValueError, AttributeError) as exc:
        log.debug('fhrp_peer_targets hsrp: %s', exc)

    try:
        for line in str(show_vrrp_brief or '').splitlines():
            m = _if_re.match(line)
            if not m:
                continue
            intf = m.group(1)
            cols = line.split()
            state = next((c for c in cols
                          if c.lower() in ('master', 'backup', 'init')), '')
            if state.lower() != 'backup':
                continue
            iptoks = [c for c in cols if _ip_re.match(c)]
            if len(iptoks) < 2:
                continue
            _add(intf, iptoks[-2])
    except (TypeError, ValueError, AttributeError) as exc:
        log.debug('fhrp_peer_targets vrrp: %s', exc)

    return out


# v53 - per-site VRF detection for the secondary->primary LAN-side login.
# Verizon is not uniform: some LAN interfaces are in a VRF (e.g. 'vrf
# forwarding 1' on cEdge), many are in the global table. We NEVER assume a VRF -
# we read it from THIS device's 'show running-config interface <intf>' and use
# it only if present. Matches IOS-XE 'vrf forwarding X' and older 'ip vrf
# forwarding X'. Returns '' (global) when no VRF line is found.
_INTF_VRF_RE = re.compile(r'(?im)^\s*(?:ip\s+)?vrf\s+forwarding\s+(\S+)\s*$')


def parse_intf_vrf(show_run_int_text):
    """Return the VRF name on an interface from 'show running-config interface
    <intf>' output, or '' if the interface is in the global table. Never
    raises; '' on empty/unparseable input (fail-safe -> plain, non-VRF form)."""
    try:
        m = _INTF_VRF_RE.search(str(show_run_int_text or ''))
        return m.group(1) if m else ''
    except (TypeError, ValueError) as exc:
        log.debug('parse_intf_vrf: %s', exc)
        return ''


# v53 - defense-in-depth credential scrubber for any device transcript that
# may be written to evidence/output.dat/Jenkins. The login drivers already
# never log secret VALUES (they log 'sent password at Password:', not the
# password), so this is a second safety net that redacts credential-bearing
# tokens (config secrets, keys, communities, interactive Password: lines).
_SCRUB_PATTERNS = [
    (re.compile(r'(?im)^(.*\b(?:password|passwd|secret)\b\s+(?:\d+\s+)?)\S+.*$'),
     r'\1***REDACTED***'),
    (re.compile(r'(?im)^(.*\b(?:key|authentication)\s+(?:\d+\s+)?)\S+(.*)$'),
     r'\1***REDACTED***\2'),
    (re.compile(r'(?im)^(\s*snmp-server\s+community\s+)\S+(.*)$'),
     r'\1***REDACTED***\2'),
    (re.compile(r'(?im)^(.*[Pp]assword:\s*)\S.*$'),
     r'\1***REDACTED***'),
]


def scrub_credentials(text):
    """Redact credential-bearing tokens from a captured device transcript
    before it is written anywhere. Never raises; returns the input unchanged
    on error (but the drivers already avoid logging secret values)."""
    try:
        s = str(text or '')
        for pat, repl in _SCRUB_PATTERNS:
            s = pat.sub(repl, s)
        return s
    except (TypeError, ValueError) as exc:
        log.debug('scrub_credentials: %s', exc)
        return text


# v50 - dual-router failover completeness.
_NEIGHBOR_IP_RE = re.compile(
    r'(?im)(?:IP(?:v4)?\s+address|Management\s+Address(?:es)?|IP)\s*:\s*'
    r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')


def parse_neighbor_ips(text):
    """
    Extract neighbour IPv4 addresses from 'show cdp neighbors detail' and/or
    'show lldp neighbors detail' output run on the secondary. Catches the
    'IP address:' (CDP) and 'IP:' / 'Management Addresses:' (LLDP) lines.
    Returns an ordered, de-duplicated list. Never raises.
    """
    out = []
    try:
        for m in _NEIGHBOR_IP_RE.finditer(str(text or '')):
            ip = m.group(1)
            if ip not in out:
                out.append(ip)
    except (TypeError, ValueError) as exc:
        log.debug('parse_neighbor_ips: %s', exc)
    return out


def summarize_neighbor_dumps(outputs_dict):
    """
    v52 [B - evidence trim]: CDP/LLDP 'neighbors detail' output can be thousands
    of lines in production, yet the automation only needs the neighbour IPs it
    parses at run time (parse_neighbor_ips) to attempt the jump. This filter
    REPLACES the raw CDP/LLDP neighbour-detail values in the evidence dict with
    a short, relevant summary (just the parsed IPs), so the automation evidence
    file (<neid>_commands.txt) and the Jenkins log store only what matters, not
    the full table. Every other command is left untouched. CDP/LLDP are not in
    the NOC crux list, so the NOC ticket / output.dat are unaffected either way.
    Never raises; a non-dict input is returned unchanged.
    """
    try:
        if not isinstance(outputs_dict, dict):
            return outputs_dict
        trimmed = {}
        for key, value in outputs_dict.items():
            kl = str(key).lower()
            if ('cdp neighbor' in kl) or ('lldp neighbor' in kl):
                ips = parse_neighbor_ips(value)
                if ips:
                    trimmed[key] = (
                        '[neighbour table summarised by iAutomate - relevant IPs '
                        'only] Neighbour IP(s) parsed at run time and used for the '
                        'primary-jump attempt: %s. Full CDP/LLDP neighbour detail '
                        'omitted from evidence.' % ', '.join(ips))
                else:
                    trimmed[key] = (
                        '[neighbour table summarised by iAutomate - relevant IPs '
                        'only] No neighbour IP could be parsed from this output. '
                        'Full CDP/LLDP neighbour detail omitted from evidence.')
            else:
                trimmed[key] = value
        return trimmed
    except (TypeError, ValueError, AttributeError) as exc:
        log.debug('summarize_neighbor_dumps: %s', exc)
        return outputs_dict


# v52 [NOC] - identify log messages that differ ONLY by timestamp or by the
# FRU/slot that logged them (SIP0 / R0/0 / F0 / FP0 ...), e.g. the EXT2-fs
# 'bad page' kernel error repeated dozens of times across slots.
_LL_TS_RE = re.compile(
    r'^\s*[*.]?[A-Za-z]{3}\s+\d{1,2}\s+\d{1,2}:\d{2}:\d{2}(?:\.\d+)?:\s*')
_LL_SLOT_RE = re.compile(
    r'^(%[A-Z0-9_]+-\d+-[A-Z0-9_]+:\s*)'
    r'(?:(?:SIP|RP|SP|LC|FP|ESP|CPP|R|F)\d+(?:/\d+)*:\s*)', re.IGNORECASE)


def last_log_lines(text, count=30, keep_last=5):
    """
    v52 [NOC request]: return the recent 'show logging' entries for the ticket -
    a clue to the events leading up to the failure - without the whole buffer.
    DMI-5-AUTH lines are dropped defensively (older images may not apply the
    on-box '| exclude').

    v52 behaviour (NOC-refined): a message that recurs (same text apart from
    timestamp / FRU-slot) is NOT flattened to one line - the most recent
    `keep_last` (default 5) occurrences are kept IN PLACE with their real
    timestamps, so a genuine flap/event sequence stays intact. Only when a
    message occurs MORE than `keep_last` times are the earlier ones dropped, and
    the oldest kept line is tagged '[xN total - showing last 5]' so NOC still
    sees how many times it fired. The remaining lines keep their original order;
    the last `count` are returned. Never raises.
    """
    try:
        n = int(count)
    except (TypeError, ValueError):
        n = 30
    try:
        k = int(keep_last)
    except (TypeError, ValueError):
        k = 5
    if k < 1:
        k = 1
    try:
        raw = [ln for ln in str(text or '').replace('\r', '').split('\n')
               if ln.strip() and 'DMI-5-AUTH' not in ln]
        occ = {}             # normalised body -> [line indices, in order]
        for i, ln in enumerate(raw):
            body = _LL_TS_RE.sub('', ln)             # drop leading timestamp
            key = _LL_SLOT_RE.sub(r'\1', body)       # drop FRU/slot token
            key = re.sub(r'\s+', ' ', key).strip().lower()
            occ.setdefault(key, []).append(i)
        keep = set()
        annotate = {}        # line index -> total count (tagged on oldest kept)
        for idxs in occ.values():
            total = len(idxs)
            if total <= k:
                keep.update(idxs)
            else:
                window = idxs[-k:]       # the most recent k occurrences
                keep.update(window)
                annotate[window[0]] = total
        out = []
        for i, ln in enumerate(raw):
            if i not in keep:
                continue
            if i in annotate:
                out.append('%s   [x%d total - showing last %d]'
                           % (ln, annotate[i], k))
            else:
                out.append(ln)
        if n > 0 and len(out) > n:
            out = out[-n:]
        return '\n'.join(out)
    except (TypeError, ValueError, AttributeError) as exc:
        log.debug('last_log_lines: %s', exc)
        return str(text or '')


def build_primary_jump_ladder(fhrp_state, secondary_lan_ip='',
                              neighbor_ips=None, include_vip=True):
    """
    v50 - ordered list of candidate PRIMARY LAN IPs to jump to from the
    secondary, richest-first. Extends derive_primary_jump_targets (VIP-only)
    so the failover case (secondary holds the FHRP Active/Master role) is no
    longer a blind escalate.

    Order:
      1. FHRP VIP           - ONLY when the primary holds Active (else the VIP
                              resolves to the secondary). Same as the v49 path.
      2. FHRP Active/Master addr (the primary's physical LAN IP) - ONLY when the
                              primary holds Active; when the SECONDARY is Active
                              this address IS the secondary, so it is skipped.
      3. CDP/LLDP neighbour IPs that sit on the FHRP LAN subnet (/24 of the VIP)
                              - the directly-connected peer CE. This is the only
                              rung that still finds the primary once it has lost
                              the Active role, provided its LAN link is up.

    Excludes the secondary's own IP, the VIP (from the neighbour rung), and
    de-duplicates. Every candidate is still PINGED from the secondary before any
    SSH (caller task 1256/1257), and only ONE candidate is SSH'd (1259), so the
    primary's login-block quiet period is never at risk. Returns [] when nothing
    can be derived (caller then escalates). Never raises.
    """
    out = []
    try:
        sec = str(secondary_lan_ip or '').strip()
        fs = fhrp_state if isinstance(fhrp_state, dict) else {}
        vip = str(fs.get('vip', '') or '').strip()
        active = str(fs.get('active_ip', '') or '').strip()
        sec_active = bool(fs.get('secondary_is_active'))
        ipre = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'

        def add(ip):
            ip = str(ip or '').strip()
            if re.match(ipre, ip) and ip != sec and ip not in out:
                out.append(ip)

        # LAN /24 reference to keep neighbour candidates on the FHRP segment
        lan_ref = next((x for x in (vip, active, sec)
                        if re.match(ipre, x or '')), '')
        lan_pfx = ('.'.join(lan_ref.split('.')[:3]) + '.') if lan_ref else ''

        # rung 1 + 2: only meaningful while the PRIMARY still holds Active
        if not sec_active:
            if include_vip and vip:
                add(vip)
            if active and active != vip:
                add(active)

        # rung 3: peer CE from CDP/LLDP, restricted to the FHRP LAN subnet
        for ip in (neighbor_ips or []):
            ip = str(ip or '').strip()
            if ip == vip:
                continue
            if lan_pfx and not ip.startswith(lan_pfx):
                continue
            add(ip)
    except (TypeError, ValueError, AttributeError) as exc:
        log.debug('build_primary_jump_ladder: %s', exc)
    return out


# v41 - CINFO entries whose "username" slot is really a type label, never a
# device login name. Compared case-insensitively.
_CINFO_TYPE_LABELS = {
    'ENABLE', 'ENABLED', 'PRIVILEGED', 'PRIVILEGE', 'SMARTS', 'TRAPS', 'TACACS',
    'SNMP', 'SNMPV3', 'COMMUNITY', 'RW', 'RO', 'KEY', 'SECRET', 'PASSWORD',
}
_LOGIN_NAME_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.@\-]{0,63}$')


def _cinfo_login_name(value):
    """Return value if it looks like a real device login name, else ''.

    A login name is one token (no spaces or slashes) and is not a CINFO type
    label. Case is preserved: Verizon CEs use 'aaa authentication login
    default local-case ...', so 'VZuser' and 'Vzuser' are different users.
    """
    name = str(value or '').strip()
    if not name or not _LOGIN_NAME_RE.match(name):
        return ''
    if name.upper() in _CINFO_TYPE_LABELS:
        return ''
    return name


def _cinfo_entries(creds, idx):
    entries = (creds or {}).get('cinfo_%s' % idx)
    if isinstance(entries, (dict, str)):
        entries = [entries]
    return entries or []


def _cinfo_field(entry, *names):
    for n in names:
        val = entry.get(n)
        if val:
            return val
    return None


def resolve_login_chain(credentials, cinfo_indices, ansible_user, ansible_password,
                        local_index='3', enable_index='4'):
    """Build the role-tagged credential list [{'user','pass','role'}].

    v41 - roles follow the Verizon CE AAA design
    (aaa authentication login default local-case group <TACACS>):
      tacacs : service account (HCL_NetBot). Used for the direct login and the
               secondary login (management path up, TACACS reachable).
      local  : CINFO <local_index> (e.g. VZuser). A local account is checked
               FIRST by the device and works without TACACS - it is the login
               for the jump from the secondary when the primary management
               path (and so TACACS) is down.
      enable : CINFO <enable_index> password. Enable secret ONLY - never sent
               as a login password (it would be a failed login that counts
               towards 'login block-for').
    Other CINFO indices (SNMP strings, keys) are ignored.

    List order is tacacs, local, enable. jump_ssh.py picks by role; older
    readers that ignore 'role' still see the TACACS account first.
    """
    out = []
    seen = set()

    def add(user, pw, role):
        if not pw:
            return
        key = (user, pw, role)
        if key in seen:
            return
        seen.add(key)
        out.append({'user': user or '', 'pass': pw, 'role': role})

    if ansible_user and ansible_password:
        add(ansible_user, ansible_password, 'tacacs')

    wanted = [x.strip() for x in str(cinfo_indices or '').split(',') if x.strip().isdigit()]
    local_index = str(local_index or '').strip()
    enable_index = str(enable_index or '').strip()

    if local_index in wanted:
        user, pws = '', []
        for entry in _cinfo_entries(credentials, local_index):
            if isinstance(entry, dict):
                name = _cinfo_login_name(_cinfo_field(entry, 'username', 'user', 'login'))
                pw = _cinfo_field(entry, 'password', 'pass', 'pwd', 'secret')
                if name and not user:
                    user = name
                if pw:
                    pws.append(pw)
            elif entry:
                pws.append(entry)
        if user:
            for pw in pws:
                add(user, pw, 'local')
        else:
            # No usable login name for the local account: keep the password as
            # an enable candidate only. Never pair it with the TACACS user.
            for pw in pws:
                add('', pw, 'enable_fallback')

    if enable_index in wanted:
        for entry in _cinfo_entries(credentials, enable_index):
            pw = _cinfo_field(entry, 'password', 'pass', 'pwd', 'secret') if isinstance(entry, dict) else entry
            if pw:
                add('', pw, 'enable')
    return out


def credential_roles_summary(chain, local_index='3', enable_index='4'):
    """One output.dat line describing the credential roles. Never shows a password."""
    chain = [c for c in (chain or []) if isinstance(c, dict)]
    tac = [c.get('user', '') for c in chain if c.get('role') == 'tacacs']
    loc = [c.get('user', '') for c in chain if c.get('role') == 'local']
    ena = [c for c in chain if c.get('role') == 'enable']
    efb = [c for c in chain if c.get('role') == 'enable_fallback']
    parts = [
        'TACACS user ' + (tac[0] if tac else 'MISSING'),
        ('local user ' + loc[0] + ' (CINFO ' + str(local_index) + ')') if loc
        else ('local user MISSING (CINFO ' + str(local_index) + ' has no usable username)'),
        'enable secret (CINFO ' + str(enable_index) + '): ' + ('present' if ena else 'MISSING'),
    ]
    if efb:
        parts.append('CINFO ' + str(local_index) + ' password kept as enable fallback only')
    return ' | '.join(parts)


def promote_login_user(chain, user, role=''):
    """Mark the credential that just logged in to the primary as preferred so
    every later jump in this run tries it first (no repeat failed logins)."""
    out = []
    for c in (chain or []):
        if not isinstance(c, dict):
            out.append(c)
            continue
        d = dict(c)
        d.pop('preferred', None)
        if user and d.get('user') == user and (not role or d.get('role') == role):
            d['preferred'] = True
        out.append(d)
    return out


def resolve_enable_chain(login_chain):
    """Distinct passwords from the login chain, order-preserving, for enable secrets."""
    out, seen = [], set()
    for item in (login_chain or []):
        pw = item.get('pass') if isinstance(item, dict) else item
        if pw and pw not in seen:
            seen.add(pw)
            out.append(pw)
    return out


def classify_jump_failure(result):
    """Derive an honest, NOC-readable reason for a jump_ssh.py failure result.

    Returns {category, summary, detail}. category in
    {auth_failed, acl_refused, no_route, hung_at_banner, unknown}.
    """
    if not isinstance(result, dict):
        return {'category': 'unknown',
                'summary': 'jump result missing or malformed',
                'detail': ''}
    if result.get('connection_refused') and result.get('refused_after_failed_login'):
        # v41 - a refusal that follows our own failed login can be the
        # 'login block-for' quiet period, not only the VTY access list.
        return {'category': 'acl_refused',
                'summary': ('SSH from the secondary was refused after a rejected login - VTY access '
                            'list or login block (quiet period) on the primary'),
                'detail': 'Wait for the login block period to expire before a manual attempt.'}
    if result.get('connection_refused'):
        return {'category': 'acl_refused',
                'summary': 'VTY ACL on the primary refused the SSH session from the secondary',
                'detail': 'Verify the primary VTY access-class permits the secondary management IP.'}
    if result.get('auth_failed'):
        return {'category': 'auth_failed',
                'summary': 'All credentials were rejected by the primary',
                'detail': ('Likely cause: the configured login account is not authorized on this device '
                           '(TACACS unreachable on a loopback-down event AND no local fallback account '
                           'configured), or the cinfo password is wrong for the user attempted.')}
    if result.get('no_route'):
        return {'category': 'no_route',
                'summary': 'No route or L3 timeout from the secondary to the primary',
                'detail': 'Primary is unreachable at L3 from the secondary - WAN/LAN fault, not authentication.'}
    if result.get('jump_attempted') and not result.get('landing_verified'):
        return {'category': 'hung_at_banner',
                'summary': 'SSH session opened but no verified exec prompt was returned',
                'detail': ('Possible causes: unexpected MOTD/banner stalled the reader, host-key prompt '
                           'not handled, or the primary accepted SSH but its login process is unresponsive.')}
    if result.get('error'):
        return {'category': 'unknown',
                'summary': 'jump exception',
                'detail': str(result.get('error'))[:240]}
    return {'category': 'unknown',
            'summary': 'jump failed without a recognized fault signal',
            'detail': ''}


# ---------------------------------------------------------------------------
# detect_mgmt_iface_admin_down
# ---------------------------------------------------------------------------

def detect_mgmt_iface_admin_down(show_ip_interface_brief_text, mgmt_ip):
    """
    Parse `show ip interface brief` and report the interface bound to mgmt_ip
    and whether it is administratively down. Returns:
      {'interface': str, 'status': str, 'admin_down': bool}  when matched
      None                                                    when not matched
    Admin-down on the mgmt-IP-bearing interface is the root-cause indicator
    for the management-plane-only failure mode this role most often handles.
    """
    if not show_ip_interface_brief_text or not mgmt_ip:
        return None
    for line in show_ip_interface_brief_text.splitlines():
        parts = line.split()
        if len(parts) < 6:
            continue
        # Interface IP-Address OK? Method Status... Protocol
        # Status may be multi-word ("administratively down"), so it spans parts[4..-1].
        if parts[1] != mgmt_ip:
            continue
        status = ' '.join(parts[4:-1]).strip().lower()
        return {
            'interface': parts[0],
            'status':    status,
            'admin_down': 'administratively down' in status,
        }
    return None


# ---------------------------------------------------------------------------
# trim_cisco_legal
# ---------------------------------------------------------------------------
def trim_cisco_legal(text):
    """
    Strip Cisco 'show version' cryptographic-export legal boilerplate. Every
    Cisco IOS/IOS-XE/IOS-XR device emits the same 12-18 line block warning
    about export laws + 'send email to export@cisco.com', which is identical
    on every device and useless to NOC.

    Preserves: version line, ROM, uptime, image, reload reason, processor
    board ID, interface count, memory, flash, config-register.

    Removes the contiguous block from 'This product contains cryptographic'
    through the 'export@cisco.com' email line. Safe globally because that
    phrase is never operational data, only Cisco's legal notice.

    Empty / non-string input returns unchanged.
    """
    if not text or not isinstance(text, str):
        return text or ''
    import re
    # Classic IOS crypto-export legal block.
    out = re.sub(
        r'\n*This product contains cryptographic features.*?export@cisco\.com\.\s*\n+',
        '\n', text, count=1, flags=re.DOTALL
    )
    # v52 [NOC space-saving]: IOS-XE 17.x emits a DIFFERENT, equally useless
    # legal block - "Cisco IOS-XE software, Copyright ... GNU General Public
    # License ... accompanying the IOS-XE software." It is identical on every XE
    # device and never operational, so strip it too. Preserves every
    # operational line (version, uptime, reload reason, model, config register).
    out = re.sub(
        r'\n*Cisco IOS-XE software, Copyright.*?accompanying the IOS-?XE\s+software\.\s*\n+',
        '\n', out, count=1, flags=re.DOTALL | re.IGNORECASE
    )
    return out


def trim_environment_output(text):
    """
    v52 [NOC space-saving]: 'show environment all' lists every fan / temperature
    / voltage sensor, and on a healthy device every row reads 'Normal' - 20+
    noise lines NOC does not need. Collapse the all-'Normal' rows into a single
    count line and KEEP the header plus any sensor NOT reading Normal (the ones
    that actually matter). Signature-gated on genuine environment output
    (sensor + Celsius/RPM/mV/'environmental monitoring'); any other command is
    returned unchanged. Never raises.
    """
    if not text or not isinstance(text, str):
        return text or ''
    low = text.lower()
    if ('sensor' not in low or
            not any(k in low for k in
                    ('environmental monitoring', 'celsius', ' rpm', ' mv'))):
        return text
    try:
        kept, normal = [], 0
        for ln in text.split('\n'):
            if re.search(r'\bNormal\b', ln):
                normal += 1
                continue
            kept.append(ln)
        if normal:
            kept.append('[%d sensor(s) reading Normal - collapsed by iAutomate; '
                        'only non-Normal sensors (if any) shown above]' % normal)
        return '\n'.join(kept)
    except (TypeError, ValueError, AttributeError) as exc:
        log.debug('trim_environment_output: %s', exc)
        return text


# ---------------------------------------------------------------------------
# trim_platform_output  (v45)
# ---------------------------------------------------------------------------
# Markers that begin the low-level register / profiling / boot detail in
# 'show platform'. On virtual IOSv this section is ~230 lines of GRUB info,
# PC/ISR/VirtIO profiling counters and a full APIC register dump - none of it
# NOC-relevant. On real ISR/ASR/IOS-XE hardware 'show platform' is a compact
# slot / module / PSU / fan status table that contains NONE of these markers,
# so it is returned UNCHANGED. The cut therefore only ever removes the virtual
# junk and never touches a physical router's module table.
_PLATFORM_NOISE_MARKERS = (
    'grub multiboot info',
    'program counter profiling',
    'interrupt service routine profiling',
    'probes profiling',
    'cpu information',
    'cpu capabilities',
    'cpu controllers',
    'apic:',
)


def trim_platform_output(text):
    """
    Trim Cisco 'show platform' to the operationally useful header.

    Keeps everything from the top of the output down to (but NOT including) the
    first line that begins one of the register / profiling / boot-detail blocks
    listed in _PLATFORM_NOISE_MARKERS. A one-line note replaces the removed
    section. If none of the markers are present (the normal case on physical
    IOS/IOS-XE hardware, whose 'show platform' is a slot/module table), the
    text is returned UNCHANGED.

    Boundary, stated explicitly for the NOC/automation team:
      * KEPT   : version echo, disk / flash geometry, total size, and any
                 model / slot / module / PSU / fan summary lines above the cut.
      * DROPPED: GRUB multiboot info, Linker, Router-memory profiling, PC / ISR
                 / Probes / VirtIO profiling counters, CPU capabilities, CPU
                 controllers and the APIC register dump.

    Never raises. Empty / non-string input is returned unchanged.
    """
    if not text or not isinstance(text, str):
        return text or ''
    try:
        lines = text.replace('\r', '').split('\n')
        cut_idx = -1
        for i, ln in enumerate(lines):
            stripped = ln.strip().lower()
            if not stripped:
                continue
            for marker in _PLATFORM_NOISE_MARKERS:
                if stripped.startswith(marker):
                    cut_idx = i
                    break
            if cut_idx >= 0:
                break
        if cut_idx <= 0:
            # No noise section found (physical-hardware table) -> unchanged.
            return text
        kept = lines[:cut_idx]
        while kept and not kept[-1].strip():
            kept.pop()
        kept.append(
            '[platform register/profiling detail trimmed by iAutomate - '
            'not NOC-relevant]')
        return '\n'.join(kept)
    except (TypeError, ValueError, AttributeError):
        return text


# ---------------------------------------------------------------------------
# strip_orphan_pipes
# ---------------------------------------------------------------------------
def strip_orphan_pipes(text):
    """
    Cisco IOS / IOS-XE 'show standby brief' and 'show vrrp brief' emit a
    column-underline artifact: a line containing only whitespace and a single
    '|' character, sitting right under the 'P indicates configured to preempt.'
    legend. The pipe marks where the 'P' header column begins. It's a literal
    IOS display quirk, not data, and it pollutes the NOC ticket.

    This filter removes any line whose stripped content is exactly '|'. All
    other content is preserved untouched. Safe to apply globally because no
    legitimate Cisco show-command output contains a line consisting of only
    that single character.
    """
    if not text or not isinstance(text, str):
        return text or ''
    import re
    return re.sub(r'^[ \t]*\|[ \t]*\r?\n', '', text, flags=re.MULTILINE)


# ---------------------------------------------------------------------------
# trim_proc_output
# ---------------------------------------------------------------------------
def trim_proc_output(text, n=10):
    """
    Trim 'show processes cpu sorted' / 'show processes memory sorted' output to
    [summary + header] + top n data rows. Cisco IOS does not support '| count'
    or 'head -n'; we trim on the iAutomate side after capture.

    The column header is identified by the line containing both 'PID' and
    'Process' tokens (true for every IOS/IOS-XE/IOS-XR process table). All
    lines up to and including the header are preserved (CPU pct summary or
    memory-pool summary). The next n non-blank lines are kept; a blank line
    after data ends the table.

    If the output has no recognisable header (unexpected format, empty, or
    non-string), the original value is returned unchanged so downstream
    rendering does not break.
    """
    if not text or not isinstance(text, str):
        return text or ''
    try:
        rows_n = int(n)
    except (TypeError, ValueError):
        rows_n = 10
    if rows_n <= 0:
        return text

    lines = text.splitlines()
    header_idx = -1
    for i, ln in enumerate(lines):
        if 'PID' in ln and 'Process' in ln:
            header_idx = i
            break
    if header_idx < 0:
        return text

    kept = list(lines[:header_idx + 1])
    data_rows = []
    for ln in lines[header_idx + 1:]:
        if ln.strip() == '':
            if data_rows:
                break
            kept.append(ln)
            continue
        data_rows.append(ln)
        if len(data_rows) >= rows_n:
            break

    total_after_header = sum(1 for ln in lines[header_idx + 1:] if ln.strip())
    trimmed = total_after_header > rows_n
    out = '\n'.join(kept + data_rows)
    if trimmed:
        out += '\n... (output trimmed: showing top {} of {} entries by usage)'.format(
            rows_n, total_after_header)
    return out


# =============================================================================
# v37.8 - ntc-templates parse + fallback + evidence cleaner. NOC-facing
# command output formatting. All filters are Python 3.12 compatible, use
# stdlib + optional ntc-templates. Failures never raise; they always fall
# back to safe defaults so a broken parse cannot break the play.
# =============================================================================

# Markers a device prints when a command is invalid or unsupported. The
# entry is dropped from KEY EVIDENCE / KEY DIAGNOSTIC OUTPUT so NOC only
# sees commands that produced real data.
_INVALID_OUTPUT_MARKERS = (
    "% invalid input",
    "invalid input detected",
    "% incomplete command",
    "% ambiguous command",
    "% unknown command",
    "% bad ip",
    "command not found",
    "syntax error",
    "error: not collected",
    "(no output)",
    "(no output collected)",
)

# ntc-templates is optional. If not installed on the SIT/prod host, filter
# falls back to truncated raw output. Verified importable on Python 3.12.
try:
    from ntc_templates.parse import parse_output as _ntc_parse_output
    _NTC_AVAILABLE = True
except ImportError:
    _NTC_AVAILABLE = False

_NTC_PLATFORM_MAP = {
    "ios":    "cisco_ios",
    "ios_xe": "cisco_xe",
    "ios_xr": "cisco_xr",
    "iosxe":  "cisco_xe",
    "iosxr":  "cisco_xr",
    "":       "cisco_ios",   # default when platform not yet detected
}


def _is_real_cmd_output(text):
    """True when a command's output carries meaningful operational data.

    False for None / empty / whitespace-only / device-rejection markers.
    """
    if text is None:
        return False
    s = str(text).strip()
    if not s:
        return False
    low = s.lower()
    for marker in _INVALID_OUTPUT_MARKERS:
        if marker in low:
            return False
    # Lone prompt / caret line is not data.
    if s in ("^", "#", ">"):
        return False
    return True


def clean_cli_outputs(evidence_dict):
    """
    v37.8 - Drop empty and device-rejected outputs from a command-name -> output
    dict. Returns a NEW dict (input unchanged). Used before select_crux_commands
    so the NOC report never shows "% Invalid input" or blank outputs.

    Any non-dict input returns {}. Never raises.
    """
    try:
        if not isinstance(evidence_dict, dict):
            return {}
        return {k: v for k, v in evidence_dict.items() if _is_real_cmd_output(v)}
    except Exception:
        return {}


def _compact_show_version(rows):
    """Render ntc parsed 'show version' rows as short key:value block."""
    if not rows:
        return ""
    r = rows[0]
    lines = []
    if r.get("version"):
        img = r.get("software_image", "")
        lines.append("Version   : %s%s" % (r["version"], (" (%s)" % img) if img else ""))
    if r.get("hostname"):
        lines.append("Hostname  : %s" % r["hostname"])
    if r.get("uptime"):
        lines.append("Uptime    : %s" % r["uptime"])
    if r.get("reload_reason"):
        lines.append("Reload    : %s" % r["reload_reason"])
    hw = r.get("hardware")
    if hw:
        lines.append("Hardware  : %s" % (", ".join(hw) if isinstance(hw, list) else str(hw)))
    ser = r.get("serial")
    if ser:
        lines.append("Serial    : %s" % (", ".join(ser) if isinstance(ser, list) else str(ser)))
    return "\n".join(lines)


def _compact_show_ip_int_brief(rows):
    """Render 'show ip interface brief' as compact table (drop unassigned)."""
    if not rows:
        return ""
    lines = ["%-30s %-16s %-10s %s" % ("Interface", "IP-Address", "Status", "Protocol")]
    lines.append("-" * 78)
    for r in rows:
        intf = r.get("interface") or r.get("intf") or ""
        ip = r.get("ipaddr") or r.get("ip_address") or "unassigned"
        status = r.get("status") or ""
        proto = r.get("proto") or r.get("protocol") or ""
        # Skip loopbacks-with-no-ip and clean output
        if not intf:
            continue
        lines.append("%-30s %-16s %-10s %s" % (intf[:30], ip[:16], status[:10], proto))
    return "\n".join(lines) if len(lines) > 2 else ""


def _compact_show_ip_route(rows):
    """Render 'show ip route' as compact summary: default route + protocol counts."""
    if not rows:
        return ""
    default_route = None
    counts = {}
    for r in rows:
        proto = r.get("protocol", "?")
        counts[proto] = counts.get(proto, 0) + 1
        net = r.get("network", "")
        plen = r.get("prefix_length", "")
        if net == "0.0.0.0" and plen in ("0", 0):
            nh = r.get("nexthop_ip", "") or r.get("nexthop_if", "")
            default_route = "Default: %s via %s (protocol %s)" % (
                net + "/" + str(plen), nh, proto)
    lines = []
    if default_route:
        lines.append(default_route)
    else:
        lines.append("Default: NOT PRESENT in route table")
    lines.append("Route counts by protocol: " +
                 ", ".join("%s=%d" % (k, v) for k, v in sorted(counts.items())))
    lines.append("Total routes: %d" % len(rows))
    return "\n".join(lines)


def _compact_show_ip_bgp_summary(rows):
    """Render BGP summary as per-neighbor state list."""
    if not rows:
        return ""
    lines = ["%-16s %-10s %-12s %-10s %s" %
             ("Neighbor", "AS", "Up/Down", "State", "PfxRcd")]
    lines.append("-" * 66)
    for r in rows:
        nbr = r.get("bgp_neigh") or r.get("neighbor") or r.get("remote_ip") or ""
        asn = r.get("remote_as") or r.get("bgp_neigh_as") or ""
        up = r.get("up_down") or r.get("up_time") or ""
        state = r.get("state_pfxrcd") or r.get("input_queue") or ""
        pfx = r.get("prefix_received") or r.get("state_pfxrcd") or ""
        if not nbr:
            continue
        lines.append("%-16s %-10s %-12s %-10s %s" %
                     (str(nbr)[:16], str(asn)[:10], str(up)[:12], str(state)[:10], pfx))
    return "\n".join(lines) if len(lines) > 2 else ""


def _compact_show_interfaces_description(rows):
    """Render 'show interfaces description' - filter to non-down and NAMED interfaces."""
    if not rows:
        return ""
    lines = ["%-24s %-18s %s" % ("Interface", "Status", "Description")]
    lines.append("-" * 78)
    kept = 0
    for r in rows:
        intf = r.get("port") or r.get("interface") or ""
        status_full = "%s / %s" % (r.get("status", ""), r.get("protocol", ""))
        desc = r.get("descrip") or r.get("description") or ""
        # Keep everything that has a description OR is not fully down
        if desc.strip() or "up" in status_full.lower():
            lines.append("%-24s %-18s %s" % (intf[:24], status_full[:18], desc[:38]))
            kept += 1
        if kept >= 15:  # keep NOC-report compact
            lines.append("(... more interfaces truncated - see output.dat)")
            break
    return "\n".join(lines) if kept > 0 else ""


# Per-command formatter registry. When ntc parse succeeds and the command
# has a compact formatter, use it. Otherwise fall back to truncated raw.
_COMPACT_FORMATTERS = {
    "show version":                   _compact_show_version,
    "show ip interface brief":        _compact_show_ip_int_brief,
    "show ipv4 interface brief":      _compact_show_ip_int_brief,
    "show ip route":                  _compact_show_ip_route,
    "show route ipv4":                _compact_show_ip_route,
    "show ip bgp summary":            _compact_show_ip_bgp_summary,
    "show bgp all summary":           _compact_show_ip_bgp_summary,
    "show interfaces description":    _compact_show_interfaces_description,
    "show interface description":     _compact_show_interfaces_description,
}


def _truncate_raw(text, max_lines=30):
    """Fallback: keep first N lines of raw output, add note if truncated."""
    if not text:
        return ""
    lines = str(text).splitlines()
    if len(lines) <= max_lines:
        return "\n".join(lines)
    kept = lines[:max_lines]
    kept.append("(... %d more lines truncated - see output.dat / Jenkins build log)" %
                (len(lines) - max_lines))
    return "\n".join(kept)


def format_cmd_output(raw_text, command, platform=""):
    """
    v37.8 - Format a single command's raw output for the NOC KEY DIAGNOSTIC
    OUTPUT block. Order:
      1) ntc-templates parse (structured)
         - if a compact formatter exists -> render key fields
         - if not but parse succeeded -> truncate raw to 30 lines
      2) ntc-templates parse fails or library missing -> truncate raw to 30 lines
      3) Anything raises -> return empty string (safe fallback)

    Never raises. Input types tolerated (str, bytes, None). Signature is
    filter-friendly: `raw | format_cmd_output(command, platform)`.
    """
    try:
        if not raw_text or not str(raw_text).strip():
            return ""
        text = str(raw_text)
        cmd_key = str(command or "").strip().lower()

        # Skip formatting for empty command name
        if not cmd_key:
            return _truncate_raw(text)

        # Try ntc-templates if library is available.
        rows = None
        if _NTC_AVAILABLE:
            ntc_platform = _NTC_PLATFORM_MAP.get(str(platform).lower(), "cisco_ios")
            try:
                rows = _ntc_parse_output(platform=ntc_platform,
                                         command=cmd_key, data=text)
            except Exception:
                rows = None

        # If we got parsed rows AND have a compact formatter for this command,
        # render the compact form.
        if rows:
            # Find the compact formatter - try exact match first, then prefix.
            fmt = _COMPACT_FORMATTERS.get(cmd_key)
            if fmt is None:
                for prefix, func in _COMPACT_FORMATTERS.items():
                    if cmd_key.startswith(prefix):
                        fmt = func
                        break
            if fmt is not None:
                try:
                    compact = fmt(rows)
                    if compact and compact.strip():
                        return compact
                except Exception:
                    pass  # fall through to truncated raw

        # No compact formatter or parse failed -> truncated raw.
        return _truncate_raw(text)

    except Exception:
        return ""


def parse_show_version_facts(raw_text, platform=""):
    """
    v37.12 - Extract useful facts from raw 'show version' output for NOC
    observation bullets. Returns a dict with keys the caller can safely
    reference with `| default('')`. Never raises. Empty dict on any error
    or unparseable input.

    Preferred: ntc-templates (cisco_ios / cisco_xe / cisco_xr) - structured.
    Fallback: regex over the raw text - catches version + uptime at minimum.
    """
    facts = {
        'version': '',
        'image': '',
        'hostname': '',
        'uptime': '',
        'reload_reason': '',
        'hardware': '',
        'serial': '',
    }
    try:
        if not raw_text or not str(raw_text).strip():
            return facts
        text = str(raw_text)

        # ntc-templates first
        if _NTC_AVAILABLE:
            ntc_platform = _NTC_PLATFORM_MAP.get(str(platform).lower(), "cisco_ios")
            try:
                rows = _ntc_parse_output(platform=ntc_platform,
                                         command='show version', data=text)
                if rows:
                    r = rows[0]
                    facts['version']       = str(r.get('version', '') or '')
                    facts['image']         = str(r.get('software_image', '') or '')
                    facts['hostname']      = str(r.get('hostname', '') or '')
                    facts['uptime']        = str(r.get('uptime', '') or '')
                    facts['reload_reason'] = str(r.get('reload_reason', '') or '')
                    hw = r.get('hardware')
                    if hw:
                        facts['hardware'] = (', '.join(hw)
                                             if isinstance(hw, list) else str(hw))
                    ser = r.get('serial')
                    if ser:
                        facts['serial'] = (', '.join(ser)
                                           if isinstance(ser, list) else str(ser))
                    # If we got anything real, return.
                    if any(v for v in facts.values()):
                        return facts
            except Exception:
                pass

        # Regex fallback (covers IOS + IOS-XE + IOS-XR banner patterns)
        try:
            import re as _re
            m = _re.search(r'Version\s+([0-9A-Za-z.()\-_]+)', text)
            if m:
                facts['version'] = m.group(1)
            m = _re.search(r'\b(\w[\w\-.]*)\s+uptime is\s+(.+)', text)
            if m:
                facts['hostname'] = m.group(1)
                facts['uptime']   = m.group(2).strip().rstrip('.')
            m = _re.search(r'Last reload reason:\s*(.+)', text)
            if m:
                facts['reload_reason'] = m.group(1).strip().rstrip('.')
            m = _re.search(r'Processor board ID\s+(\S+)', text)
            if m:
                facts['serial'] = m.group(1)
        except Exception:
            pass

        return facts
    except Exception:
        return facts


def parse_ip_int_brief_stats(raw_text, platform=""):
    """
    v37.12 - Count interfaces up/down/admin-down from 'show ip interface
    brief'. Returns a small dict {'total','up','down','admin_down'}. Never
    raises. Intended for NOC observation bullet:
      'Interfaces: X of Y up, Z admin-down'
    """
    stats = {'total': 0, 'up': 0, 'down': 0, 'admin_down': 0}
    try:
        if not raw_text or not str(raw_text).strip():
            return stats
        text = str(raw_text)

        if _NTC_AVAILABLE:
            ntc_platform = _NTC_PLATFORM_MAP.get(str(platform).lower(), "cisco_ios")
            try:
                rows = _ntc_parse_output(platform=ntc_platform,
                                         command='show ip interface brief',
                                         data=text)
                if rows:
                    for r in rows:
                        status = str(r.get('status', '') or '').lower()
                        proto  = str(r.get('proto') or r.get('protocol', '') or '').lower()
                        stats['total'] += 1
                        if 'administratively' in status or 'admin' in status:
                            stats['admin_down'] += 1
                        elif status == 'up' and proto == 'up':
                            stats['up'] += 1
                        else:
                            stats['down'] += 1
                    return stats
            except Exception:
                pass

        # Regex fallback - count lines that look like interface entries
        try:
            import re as _re
            for line in text.splitlines():
                if _re.match(r'^\s*(GigabitEthernet|FastEthernet|TenGigE|Ethernet|Serial|Loopback|Vlan|Tunnel|Port-channel|Bundle-Ether)',
                             line, _re.IGNORECASE):
                    stats['total'] += 1
                    low = line.lower()
                    if 'administratively' in low:
                        stats['admin_down'] += 1
                    elif ' up ' in low and low.strip().endswith('up'):
                        stats['up'] += 1
                    else:
                        stats['down'] += 1
        except Exception:
            pass

        return stats
    except Exception:
        return stats


# Empty/error markers used by count_real_outputs and select_crux_commands
# to detect commands whose output is not real data (device rejected the
# command or wrapper wrote a stub). Kept broader than _INVALID_OUTPUT_MARKERS
# because these two functions must also filter jump_ssh.py / device_ssh.py
# exception traces and empty-payload stubs.
_NOC_EMPTY_MARKERS = (
    "% Invalid input detected",
    "% Incomplete command",
    "% Ambiguous command",
    "% Unknown command",
    "% Bad IP",
    "invalid input detected",
    "Command not found",
    "syntax error",
    "Error: not collected",
    "(no output)",
    "(no events)",
    "(no output collected)",
    "(command not run)",
    "Traceback (most recent call",
    "SSH_EXCEPTION:",
    "SSH_TIMEOUT:",
    "SSH_AUTH_FAILED:",
    "SSH_CONN_REFUSED:",
    "PARAMIKO_EXCEPTION:",
    "JUMP_SSH_EXCEPTION:",
    "DEVICE_SSH_EXCEPTION:",
    "COMMAND_ERROR:",
    "COLLECT_FAILED:",
)


def count_real_outputs(outputs_dict):
    """
    v37.6 - Return count of command outputs in the dict that contain
    meaningful data. An "empty" output is one of:
      - None / empty string / whitespace only
      - A caught-exception marker written by jump_ssh.py / device_ssh.py
      - A '% Invalid input detected' banner (wrong-platform command)
      - A stub placeholder like '(no output)' / '(no events)'
    Used to print an honest 'X/Y commands returned data' line to NOC.

    Signature matches BFD-TLOC-VIPTELA-TRIAGE's count_real_outputs so the
    two roles report the same honest count style.
    """
    n = 0
    for value in outputs_dict.values():
        if value is None:
            continue
        text = str(value).strip()
        if not text:
            continue
        # Reject if it starts with any known empty/error marker
        if any(text.startswith(m) or text == m for m in _NOC_EMPTY_MARKERS):
            continue
        # Reject if the whole content is just an empty/error marker
        if any(m in text and len(text) < len(m) + 60 for m in _NOC_EMPTY_MARKERS):
            continue
        n += 1
    return n


# Ordered per-scenario crux command lists. Order matters - earlier entries
# render first in the ticket. Missing commands are silently skipped (the
# select filter tolerates absent keys). Every command listed here is one
# the role ALREADY collects somewhere upstream at v37.5.
_NOC_CRUX_BY_SCENARIO = {
    # Device already UP at initial ping - validation close-out.
    'validation': [
        # v38 - MOP "Ping = YES" leaf: every command below is collected by
        # reachable_closeout.yaml 1151. The v37 entry 'show logging | include
        # LINEPROTO' was never collected on this path, so it never rendered.
        # v52 [NOC] - log evidence at the front. The last-30 'exclude DMI-5-AUTH'
        # capture (sign-off: collect on the UP path too) leads, then reboot log.
        'show logging | exclude DMI-5-AUTH',
        'show logging | include reload',
        'show version',
        'show ip interface brief',
        'show ip bgp summary',
        'show environment all',
        # v40 - MOP reachable-branch commands added to the close-out.
        'show processes cpu | include CPU utilization',
        'show processes memory | include Processor Pool',
    ],
    # v40 - device answers ping but was NOT auto-closed (SSH failed, flapping,
    # or packet loss persisted). Direct close-out keys first, then the same
    # keys collected through the secondary (jump) session.
    'validation_escalated': [
        # v52 [NOC] - log evidence first; last-30 'exclude DMI-5-AUTH' leads.
        'show logging | exclude DMI-5-AUTH',
        'show logging | include %SYS-5-RESTART|%SYS-5-RELOAD|%BGP-5-ADJCHANGE|%LINEPROTO-5-UPDOWN',
        'show logging | include reload',
        'show version',
        'show ip interface brief',
        'show ip bgp summary',
        'show processes cpu | include CPU utilization',
        'show processes cpu sorted | exclude 0.0',
        'show environment all',
    ],
    # Device recovered after WAN interface bounce.
    # 4 commands: WAN-specific interface state + IP brief + route + reload log.
    # WAN-specific 'show interface <wan_interface>' is prepended by the
    # select_crux_commands filter when wan_interface is set.
    'post_bounce': [
        'show interfaces description',
        'show ip interface brief',
        'show ip route',
        'show logging | include reload',
    ],
    # Device recovered after BGP neighbor clear.
    # 4 commands: BGP summary + IP brief + route + UPDOWN log.
    'post_bgp': [
        'show ip bgp summary',
        'show ip interface brief',
        'show ip route',
        'show logging | include UPDOWN',
    ],
    # Device stayed DOWN - full escalation (jump landed on the primary).
    # 6 commands; each is trimmed to 40 lines in the ticket (trim_cmd_output)
    # so the block stays well under the 24800-char cap.
    'escalation': [
        # v38 - order follows the MOP escalation box (show version, reload log,
        # interface state, WAN description, route table, BGP summary).
        # v52 [NOC] - log evidence pulled to the front so the "why it went down"
        # evidence is guaranteed to survive the 24 KB cap. Last-30 leads.
        'show logging | exclude DMI-5-AUTH',
        'show logging | include reload',
        'show version',
        'show ip interface brief',
        'show interfaces description',
        'show ip route',
        'show ip bgp summary',
    ],
    # Device down, no partner router found at site - different crux.
    'escalation_no_partner': [
        # Only host-side ping + partner-discovery evidence exists; no CLI.
        # The ticket's Observation section already reports these; keep the
        # crux block small so NOC sees the ONE clear failure signal.
    ],
    # Device down, partner found, but jump session never landed on primary.
    'escalation_jump_failed': [
        # partner_login writes the failure reason to output.dat directly;
        # keep the crux block minimal here too.
    ],
}


def select_crux_commands(evidence_dict, scenario, wan_interface=''):
    """
    v37.6 - Return an ORDERED list of (command, output) tuples for the crux
    section of the NOC ticket, selected per scenario. Commands NOT in
    evidence_dict are silently skipped. WAN-specific interface command
    ('show interface <wan_interface>') is prepended to post_bounce output
    when wan_interface is set and the corresponding key exists.

    Never returns > 8 commands (safety cap on ticket size).
    """
    if not isinstance(evidence_dict, dict):
        return []
    scenario = str(scenario or '').strip().lower()
    ordered_cmds = _NOC_CRUX_BY_SCENARIO.get(scenario, [])
    result = []
    seen = set()

    # For post_bounce, try to include the wan-specific interface command first
    # if collected.
    if scenario == 'post_bounce' and wan_interface:
        wan_key_candidates = [
            'show interface ' + str(wan_interface),
            'show interfaces ' + str(wan_interface),
        ]
        for wk in wan_key_candidates:
            if wk in evidence_dict and wk not in seen:
                val = evidence_dict.get(wk, '')
                if val and str(val).strip():
                    result.append((wk, str(val)))
                    seen.add(wk)
                    break

    for cmd in ordered_cmds:
        if len(result) >= 8:
            break
        if cmd in seen:
            continue
        val = evidence_dict.get(cmd, '')
        if val is None:
            continue
        text = str(val).strip()
        if not text:
            continue
        # Skip caught-error placeholders - they add no signal to NOC.
        if any(text.startswith(m) for m in _NOC_EMPTY_MARKERS):
            continue
        result.append((cmd, str(val)))
        seen.add(cmd)
    return result


def cap_response_msg(text, max_chars=24800, footer=''):
    """
    v37.6 - Enforce the ETMS/Jenkins single-chunk char limit (~25 KB).
    If text is under max_chars, return unchanged. Otherwise:
      1. Try to preserve the AVA closure tag line if present (FRS Row 3
         match must survive truncation on success paths).
      2. Trim the middle of the body at a line boundary.
      3. Append the caller-supplied footer (pointing NOC to the Jenkins
         build log for full evidence).
      4. Re-append the AVA tag block if it was present, so the master
         template's substring match still finds it.

    max_chars default 24800 matches the platform's 25 KB inline slice with
    ~200 char headroom for the master template's own appended text
    ('Engage NOC to manual troubleshooting and customer update.').
    """
    if text is None:
        return ''
    body = str(text)
    if not body:
        return body
    try:
        cap = int(max_chars)
    except (TypeError, ValueError):
        cap = 24800
    if cap <= 0 or len(body) <= cap:
        return body

    footer_str = str(footer or '')

    # Extract AVA closure tag block if present. The tag itself is a single
    # line; keep the surrounding banner block so the tag doesn't get orphaned.
    ava_marker = 'Post-Test Validation: Device verified UP'
    ava_block = ''
    if ava_marker in body:
        # Match the whole tag banner block (best-effort). Fall back to the
        # single line if the banner shape has drifted.
        m = re.search(
            r'=+\s*\n\s*AVA POST-TEST VALIDATION TAG\s*\n=+\s*\n\s*'
            + re.escape(ava_marker) + r'.*?(?:\n|$)',
            body,
        )
        if m:
            ava_block = '\n\n' + m.group(0).rstrip() + '\n'
        else:
            ava_block = '\n\n' + ava_marker + '\n'

    # Compute how much body to keep, reserving space for footer + AVA block.
    reserve = len(footer_str) + len(ava_block) + 8  # 8-char slack
    keep = cap - reserve
    if keep < 200:
        # Pathological - footer + AVA alone consume the budget. Best-effort
        # return the top of the body plus the AVA tag.
        keep = max(0, cap - len(ava_block) - 8)
        return body[:keep] + ava_block

    truncated = body[:keep]
    # Snap to the last newline so we don't cut a line mid-command.
    last_nl = truncated.rfind('\n')
    if last_nl > 0 and last_nl >= keep - 400:
        truncated = truncated[:last_nl]
    # v39 - the closure line now sits right after Next Plan of Action (near
    # the top). Re-append it only if the cut removed it - never twice.
    if ava_block and ava_marker in truncated:
        ava_block = ''
    return truncated + ('\n' + footer_str if footer_str else '') + ava_block


# =============================================================================
# v38 - NOC standard report helpers (additive). Pure, never raise.
# =============================================================================

_ALARM_START_RE = re.compile(
    r'INCIDENT[ \t]+START[ \t]+TIME[ \t]*:[ \t]*(\d{1,2})[/-](\d{1,2})[/-](\d{4})[ \t]+'
    r'(\d{1,2}):(\d{2})(?::(\d{2}))?(?:[ \t]*([AaPp][Mm]))?', re.IGNORECASE)
# [ \t]* (not \s*) so an empty field can never swallow the next line.
_ALARM_TYPE_RE = re.compile(
    r'INCIDENT[ \t]+TYPE[ \t]*:[ \t]*([^\n]+?)(?:[ \t]+SOURCED[ \t]+FROM\b[^\n]*)?[ \t]*$',
    re.IGNORECASE | re.MULTILINE)
_ALARM_TEXT_RE = re.compile(r'^[ \t]*TEXT[ \t]*:[ \t]*([^\n]+?)[ \t]*$', re.IGNORECASE | re.MULTILINE)
_ALARM_ID_RE = re.compile(r'ALARM\s+ID\s*:\s*(\S+)', re.IGNORECASE)
# v44 - extra INCIDENT INFORMATION fields (standard NOC report). All optional;
# absent -> '' and the report omits the line.
_ALARM_HOSTNAME_RE = re.compile(r'^[ \t]*HOSTNAME[ \t]*:[ \t]*([^\n]+?)[ \t]*$', re.IGNORECASE | re.MULTILINE)
_ALARM_PRODUCT_RE  = re.compile(r'^[ \t]*PRODUCT[ \t]+TYPE[ \t]*:[ \t]*([^\n]+?)[ \t]*$', re.IGNORECASE | re.MULTILINE)
_ALARM_EQUIP_RE    = re.compile(r'^[ \t]*EQUIPMENT[ \t]+TYPE[ \t]*:[ \t]*([^\n]+?)[ \t]*$', re.IGNORECASE | re.MULTILINE)
# v48 - extra standard-header fields (BFD-reference layout). All optional;
# absent -> '' and the report omits the line.
_ALARM_AID_RE      = re.compile(r'^[ \t]*AID[ \t]*:[ \t]*([^\n]+?)[ \t]*$', re.IGNORECASE | re.MULTILINE)
_ALARM_PRIORITY_RE = re.compile(r'PRIORITY[ \t]+(\d+)', re.IGNORECASE)
# Domain is the number in the ".dNN.mso.mci.com" of the AID / TEXT (d46 -> 46).
_ALARM_DOMAIN_RE   = re.compile(r'\.d(\d+)\.mso\.mci\.com', re.IGNORECASE)
# Full incident type, INCLUDING any "SOURCED FROM ..." suffix (the stripped
# form stays in 'incident_type' for the existing master-reconcile logic).
_ALARM_TYPE_FULL_RE = re.compile(
    r'INCIDENT[ \t]+TYPE[ \t]*:[ \t]*([^\n]+?)[ \t]*$', re.IGNORECASE | re.MULTILINE)


def parse_alarm_fields(description):
    """
    v38 - Extract the alarm fields the NOC header needs from the raw
    Description extra-var. Jenkins passes literal '\n' tokens, so they are
    normalised here first.

    Returns {'start_time', 'incident_type', 'alarm_text', 'alarm_id'}; any
    field not present in the Description is ''. start_time is rendered as
    'MM-DD-YYYY HH:MM:SS' to match the BFD-TLOC reference ticket.
    """
    out = {'start_time': '', 'incident_type': '', 'alarm_text': '', 'alarm_id': '',
           'hostname': '', 'product_type': '', 'equipment_type': '', 'ticket_type': '',
           'aid': '', 'priority': '', 'domain': '', 'incident_type_full': ''}
    try:
        text = str(description or '').replace('\\r', '').replace('\\n', '\n')
        if not text.strip():
            return out
        m = _ALARM_START_RE.search(text)
        if m:
            mm, dd, yyyy, hh, mi, ss, ampm = m.groups()
            hour = int(hh)
            if ampm:
                ampm = ampm.upper()
                if ampm == 'PM' and hour < 12:
                    hour += 12
                elif ampm == 'AM' and hour == 12:
                    hour = 0
            # Reject impossible values instead of printing a wrong time.
            if (1 <= int(mm) <= 12 and 1 <= int(dd) <= 31 and hour <= 23
                    and int(mi) <= 59 and int(ss or 0) <= 59):
                out['start_time'] = '%02d-%02d-%s %02d:%s:%s' % (
                    int(mm), int(dd), yyyy, hour, mi, ss or '00')
        m = _ALARM_TYPE_RE.search(text)
        if m:
            out['incident_type'] = m.group(1).strip()
        m = _ALARM_TEXT_RE.search(text)
        if m:
            out['alarm_text'] = m.group(1).strip()
        m = _ALARM_ID_RE.search(text)
        if m:
            out['alarm_id'] = m.group(1).strip()
        m = _ALARM_HOSTNAME_RE.search(text)
        if m:
            out['hostname'] = m.group(1).strip()
        m = _ALARM_PRODUCT_RE.search(text)
        if m:
            out['product_type'] = m.group(1).strip()
        m = _ALARM_EQUIP_RE.search(text)
        if m:
            out['equipment_type'] = m.group(1).strip()
        low = text.lower()
        if 'proactive' in low:
            out['ticket_type'] = 'Proactive'
        elif 'reactive' in low:
            out['ticket_type'] = 'Reactive'
        # v48 - additive standard-header fields.
        m = _ALARM_AID_RE.search(text)
        if m:
            out['aid'] = m.group(1).strip()
        m = _ALARM_PRIORITY_RE.search(text)
        if m:
            out['priority'] = m.group(1).strip()
        m = _ALARM_DOMAIN_RE.search(text)
        if m:
            out['domain'] = m.group(1).strip()
        m = _ALARM_TYPE_FULL_RE.search(text)
        if m:
            out['incident_type_full'] = m.group(1).strip()
    except (TypeError, ValueError, AttributeError) as exc:
        log.debug('parse_alarm_fields: %s', exc)
    return out


def trim_cmd_output(raw_text, max_lines=40):
    """
    v38 - Raw command output for the KEY EVIDENCE block (the reference ticket
    shows raw device output, not a parsed summary). Strips leading/trailing
    blank lines and keeps the first max_lines lines with a truncation note.
    Never raises; returns '' for empty input.
    """
    try:
        if raw_text is None:
            return ''
        lines = str(raw_text).replace('\r', '').split('\n')
        while lines and not lines[0].strip():
            lines.pop(0)
        while lines and not lines[-1].strip():
            lines.pop()
        try:
            cap = int(max_lines)
        except (TypeError, ValueError):
            cap = 40
        if cap > 0 and len(lines) > cap:
            # v39 - cut quietly; full output stays in output.dat / Jenkins log.
            lines = lines[:cap]
        return '\n'.join(lines)
    except (TypeError, ValueError, AttributeError):
        return ''


# ---------------------------------------------------------------------------
# v40 - UP-path stability check (MOP: "check logs, is the router flapping?",
# "stable for the last 5-10 min") and recent-reboot detection.
# ---------------------------------------------------------------------------

_MONTHS = {m: i for i, m in enumerate(
    ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'], 1)}

_UPTIME_RE = re.compile(r'uptime is (?P<txt>[^\n]+)', re.IGNORECASE)
_UPTIME_PART_RE = re.compile(r'(\d+)\s+(year|week|day|hour|minute)s?', re.IGNORECASE)
_RELOAD_REASON_RE = re.compile(r'Last reload reason:\s*(?P<r>[^\n]+)', re.IGNORECASE)
_CLOCK_RE = re.compile(
    r'[*.]?(?P<h>\d{1,2}):(?P<m>\d{2}):(?P<s>\d{2})(?:\.\d+)?\s+\S+\s+\w{3}\s+'
    r'(?P<mon>[A-Za-z]{3})\s+(?P<day>\d{1,2})\s+(?P<year>\d{4})')
_LOG_TS_RE = re.compile(
    r'^\s*[*.]?(?P<mon>[A-Za-z]{3})\s+(?P<day>\d{1,2})\s+(?:(?P<year>\d{4})\s+)?'
    r'(?P<h>\d{1,2}):(?P<m>\d{2}):(?P<s>\d{2})')
_WAN_DESC_RE = re.compile(
    r'(?i)\b(wan|mpls|internet|isp|verizon|circuit|broadband|dia|uplink)\b|\bC\d{7}\b')
# v52 [B - fixes build 10331 cellular flap blind spot]: on cellular Managed-WAN
# CPE the transport is Cellular0 / Dialer0, which usually carries no WAN
# description and so was never added to the WAN set from 'show interfaces
# description'.  A cellular bearer drop (Cellular0 down, %CELLWAN-2-BEARER_*)
# was therefore invisible to the flap check.  Recognise these interfaces by
# NAME so cellular/dialer WAN flaps are counted like any other WAN flap.
_CELL_WAN_IFACE_RE = re.compile(r'^(?:cellular|cell|dialer)\d', re.IGNORECASE)


def _is_cellular_wan_iface(iface_name):
    """True if the (abbreviated) interface name is an inherent cellular/dialer
    WAN transport. Name-based so it works even when the interface has no
    WAN-matching description. Never raises."""
    return bool(_CELL_WAN_IFACE_RE.match(str(iface_name or '').strip()))


def _uptime_minutes(txt):
    mult = {'year': 525600, 'week': 10080, 'day': 1440, 'hour': 60, 'minute': 1}
    total, found = 0, False
    for num, unit in _UPTIME_PART_RE.findall(txt or ''):
        total += int(num) * mult[unit.lower()]
        found = True
    return total if found else None


def _wan_ifaces_from_desc(intf_desc_text):
    wan = set()
    for line in str(intf_desc_text or '').splitlines():
        parts = line.split()
        if len(parts) < 4 or parts[0].lower() == 'interface':
            continue
        desc = line.split(None, 3)[3] if len(line.split(None, 3)) > 3 else ''
        if _WAN_DESC_RE.search(desc):
            wan.add(_abbrev_iface(parts[0]).lower())
    return wan


def evaluate_device_stability(show_version, flap_log='', show_clock='',
                              intf_desc='', window_minutes=60,
                              event_threshold=3, recent_reboot_minutes=10):
    """Return a dict describing uptime / recent reboot / flapping.

    Flapping = at least `event_threshold` separate minutes, inside the last
    `window_minutes` of device clock time, that contain a down event:
      - %BGP-5-ADJCHANGE ... Down
      - %SYS-5-RESTART or %SYS-5-RELOAD (reload / restart)
      - %LINEPROTO-5-UPDOWN ... changed state to down on a WAN interface
        (WAN = description matches WAN/MPLS/INTERNET/... or C + 7 digits, OR
        the interface is a cellular/dialer transport by name - v52)
      - %CELLWAN-2 bearer deleted/down or modem down (cellular transport - v52)
    Several neighbours going down in the same minute count as ONE event.
    If the device clock or the log timestamps cannot be read the flap check
    is reported as inconclusive (never as flapping) - the caller shows that.
    Never raises.
    """
    res = {'uptime_text': '', 'uptime_minutes': None, 'reload_reason': '',
           'recent_reboot': False, 'flapping': False, 'flap_inconclusive': False,
           'flap_events': [], 'flap_event_minutes': 0, 'window_minutes': 0,
           'event_threshold': 0, 'summary': ''}
    try:
        window_minutes = int(window_minutes)
        event_threshold = int(event_threshold)
        recent_reboot_minutes = int(recent_reboot_minutes)
        res['window_minutes'] = window_minutes
        res['event_threshold'] = event_threshold
        sv = str(show_version or '')
        m = _UPTIME_RE.search(sv)
        if m:
            res['uptime_text'] = m.group('txt').strip()
            res['uptime_minutes'] = _uptime_minutes(res['uptime_text'])
        m = _RELOAD_REASON_RE.search(sv)
        if m:
            res['reload_reason'] = m.group('r').strip()
        if res['uptime_minutes'] is not None and res['uptime_minutes'] < recent_reboot_minutes:
            res['recent_reboot'] = True

        log = str(flap_log or '')
        if not log.strip():
            res['summary'] = 'no reload/BGP/WAN up-down events in the device log'
            return res
        if log.lstrip().startswith('%') or log.lstrip().startswith('['):
            res['flap_inconclusive'] = True
            res['summary'] = 'flap check not possible - log command was not accepted by the device'
            return res
        cm = _CLOCK_RE.search(str(show_clock or ''))
        if not cm:
            res['flap_inconclusive'] = True
            res['summary'] = 'flap check not possible - device clock could not be read'
            return res
        import datetime as _dt
        now = _dt.datetime(int(cm.group('year')), _MONTHS.get(cm.group('mon').lower(), 1),
                           int(cm.group('day')), int(cm.group('h')), int(cm.group('m')),
                           int(cm.group('s')))
        wan = _wan_ifaces_from_desc(intf_desc)
        minutes, events, unparsed = set(), [], 0
        for line in log.splitlines():
            low = line.lower()
            kind = None
            if '%bgp-5-adjchange' in low and ' down' in low:
                kind = 'BGP neighbor down'
            elif '%sys-5-restart' in low or '%sys-5-reload' in low:
                kind = 'reload/restart'
            # v52 [B]: cellular/LTE transport loss - bearer deleted/down or the
            # modem going down is a WAN-down event on cellular Managed-WAN CPE.
            elif '%cellwan-' in low and ('bearer_deleted' in low
                                         or 'bearer_down' in low
                                         or 'modem_down' in low):
                kind = 'cellular WAN down'
            elif '%lineproto-5-updown' in low and 'changed state to down' in low:
                im = re.search(r'Interface\s+(\S+?),', line)
                if im:
                    _ifn = _abbrev_iface(im.group(1)).lower()
                    # v52 [B]: match by WAN description (existing) OR by cellular
                    # /dialer interface name (new - covers Cellular0/Dialer0 that
                    # carry no WAN description).
                    if _ifn in wan or _is_cellular_wan_iface(_ifn):
                        kind = 'WAN interface down'
            if not kind:
                continue
            tm = _LOG_TS_RE.match(line)
            if not tm or tm.group('mon').lower() not in _MONTHS:
                unparsed += 1
                continue
            year = int(tm.group('year')) if tm.group('year') else now.year
            ts = _dt.datetime(year, _MONTHS[tm.group('mon').lower()], int(tm.group('day')),
                              int(tm.group('h')), int(tm.group('m')), int(tm.group('s')))
            if ts > now + _dt.timedelta(days=1):
                ts = ts.replace(year=ts.year - 1)
            age = (now - ts).total_seconds() / 60.0
            if age < -5 or age > window_minutes:
                continue
            minutes.add(ts.strftime('%Y%m%d%H%M'))
            ev = '%s %s' % (ts.strftime('%b %d %H:%M'), kind)
            if ev not in events:
                events.append(ev)
        res['flap_events'] = events[-10:]
        res['flap_event_minutes'] = len(minutes)
        if unparsed and not events:
            res['flap_inconclusive'] = True
            res['summary'] = 'flap check not possible - log timestamps could not be read'
            return res
        res['flapping'] = len(minutes) >= event_threshold
        res['summary'] = ('%d separate down event(s) in the last %d minutes (threshold %d)'
                          % (len(minutes), window_minutes, event_threshold))
    except Exception as exc:  # never raise into the play
        res['flap_inconclusive'] = True
        res['summary'] = 'flap check not possible - %s' % exc
    return res



def pack_commands_to_budget(items, budget=24000,
                            demarcation='-x-x-x-x-x-x-x-x-x-x'):
    """
    v47 - Pack command outputs into the NOC ticket's DIAGNOSTIC block within a
    hard character budget (the ETMS/Jenkins ~24 KB message limit).

    items  : ORDERED list of [label, output] pairs - MOST IMPORTANT FIRST. Each
             output must already be noise-trimmed by the caller.
    budget : max characters this whole block may occupy.

    Adds WHOLE command blocks in order until the next one would exceed the
    budget (minus a small reserve for the footer). NEVER splits a command
    mid-output. If one or more commands are omitted, appends a demarcation line
    and a one-line pointer to where the full output lives. Never raises.
    """
    try:
        budget = int(budget)
    except (TypeError, ValueError):
        budget = 24000
    reserve = len(demarcation) + 200          # always leave room for the footer
    parts, used, dropped = [], 0, 0
    for pair in (items or []):
        try:
            label = str(pair[0])
            text = pair[1]
        except (IndexError, TypeError, KeyError):
            continue
        text = str(text) if text not in (None, '') else '(no output returned by device for this command)'
        block = '--- %s ---\n%s\n\n' % (label, text)
        if used + len(block) <= (budget - reserve):
            parts.append(block)
            used += len(block)
        else:
            dropped += 1
    body = ''.join(parts).rstrip('\n')
    if dropped:
        body += ('\n\n%s\n[Output truncated at the ~24 KB ETMS ticket limit - '
                 '%d command(s) not shown here. FULL command output is in the '
                 'Jenkins build console log and in <neid>_commands.txt.]'
                 % (demarcation, dropped))
    return body


def render_all_commands(items):
    """
    v47 - Render EVERY command's output in full (noise already trimmed by the
    caller) for the complete-evidence artifacts (Jenkins build log and
    <neid>_commands.txt). No budget cap. items = ordered [label, output] pairs.
    Never raises.
    """
    parts = []
    for pair in (items or []):
        try:
            label = str(pair[0])
            text = pair[1]
        except (IndexError, TypeError, KeyError):
            continue
        text = str(text) if text not in (None, '') else '(no output returned by device for this command)'
        parts.append('--- %s ---\n%s\n' % (label, text))
    return '\n'.join(parts) if parts else '(no command output was collected on this run)'


def build_diag_items(crux_list, partner_dict=None, partner_neid='', partner_ip=''):
    """
    v47 - Build the ORDERED [label, output] list for the NOC DIAGNOSTIC block:
    the scenario crux commands first (primary/direct), then the secondary-side
    commands (labelled with the secondary NEID/IP). Each output is noise-trimmed
    here (show version legal block, show platform register dump) so the packer's
    length accounting is correct. Never raises.
    """
    def _trim(v):
        try:
            # v52 - env-sensor collapse applied to the NOC ticket only (the full
            # evidence file/Jenkins log via build_all_items keeps the complete
            # sensor table).
            return trim_environment_output(
                trim_platform_output(trim_cisco_legal(v if v not in (None, '') else '')))
        except Exception:
            return v or ''
    out = []
    for pair in (crux_list or []):
        try:
            out.append([str(pair[0]), _trim(pair[1])])
        except (IndexError, TypeError, KeyError):
            continue
    for k, v in (partner_dict or {}).items():
        label = '%s   [secondary %s (%s)]' % (k, partner_neid or '', partner_ip or '')
        out.append([label, _trim(v)])
    return out


def build_all_items(evidence_dict):
    """
    v47 - Build the ORDERED [label, output] list of EVERY collected command for
    the complete-evidence artifacts (Jenkins log + <neid>_commands.txt). Same
    noise-trims as the ticket, but no budget cap. Never raises.
    """
    def _trim(v):
        try:
            return trim_platform_output(trim_cisco_legal(v if v not in (None, '') else ''))
        except Exception:
            return v or ''
    out = []
    for k, v in (evidence_dict or {}).items():
        out.append([str(k), _trim(v)])
    return out


class FilterModule(object):
    """Cisco Router Device Down Jinja2 filter plugin."""

    def filters(self):
        return {
            'pack_commands_to_budget':            pack_commands_to_budget,
            'render_all_commands':                render_all_commands,
            'build_diag_items':                   build_diag_items,
            'build_all_items':                    build_all_items,
            # JSON / parsing
            'safe_json_parse':                    safe_json_parse,
            'extract_ssh_output':                 extract_ssh_output,
            'parse_ping_result':                  parse_ping_result,
            # Platform
            'extract_platform':                   extract_platform,
            # Process-table trimmer (top-N by usage; defends NOC ticket from
            # 200+ line process dumps that Cisco IOS cannot pipe through head)
            'trim_proc_output':                   trim_proc_output,
            # Cisco IOS show standby/vrrp column-underline artifact cleaner
            'strip_orphan_pipes':                 strip_orphan_pipes,
            # Strip Cisco show-version legal/crypto/export boilerplate (~18 lines)
            'trim_cisco_legal':                   trim_cisco_legal,
            # v45 - trim 'show platform' register/profiling dump (virtual IOSv);
            # physical-hardware module tables are returned unchanged.
            'trim_platform_output':               trim_platform_output,
            # Interface
            'parse_interface_state':              parse_interface_state,
            'parse_interface_ip_mask':            parse_interface_ip_mask,
            'parse_default_route_interface':      parse_default_route_interface,
            'parse_static_default_next_hop':      parse_static_default_next_hop,
            # WAN identification
            'derive_wan_interface_with_confidence': derive_wan_interface_with_confidence,
            'format_wan_identification_result':   format_wan_identification_result,
            # BGP
            'parse_bgp_vrf_map':                  parse_bgp_vrf_map,
            'parse_bgp_summary':                  parse_bgp_summary,
            'find_stuck_bgp_neighbors':           find_stuck_bgp_neighbors,
            'bgp_state_hint':                     bgp_state_hint,
            'build_bgp_clear_command':            build_bgp_clear_command,
            'build_bgp_vrf_summary_command':      build_bgp_vrf_summary_command,
            'get_bgp_discovery_commands':         get_bgp_discovery_commands,
            'merge_bgp_summary_outputs':          merge_bgp_summary_outputs,
            'build_bgp_underlay_commands':        build_bgp_underlay_commands,
            'build_bgp_neighbor_ping_cmd':        build_bgp_neighbor_ping_cmd,
            'evaluate_underlay_reachability':     evaluate_underlay_reachability,
            'corroborate_wan_pe_from_static':     corroborate_wan_pe_from_static,
            'parse_vrrp_vip':                     parse_vrrp_vip,
            'parse_fhrp_state':                   parse_fhrp_state,
            'derive_primary_jump_targets':        derive_primary_jump_targets,
            'fhrp_peer_ips':                      fhrp_peer_ips,
            'fhrp_peer_targets':                  fhrp_peer_targets,
            'parse_intf_vrf':                     parse_intf_vrf,
            'scrub_credentials':                  scrub_credentials,
            'parse_neighbor_ips':                 parse_neighbor_ips,
            'summarize_neighbor_dumps':           summarize_neighbor_dumps,
            'last_log_lines':                     last_log_lines,
            'build_primary_jump_ladder':          build_primary_jump_ladder,
            'parse_vty_acl':                      parse_vty_acl,
            'find_partner_candidates':            find_partner_candidates,
            'reject_non_router_devices':          reject_non_router_devices,
            'extract_bgp_update_source':          extract_bgp_update_source,
            'verify_bgp_neighbor_config':         verify_bgp_neighbor_config,
            'is_bgp_active':                      is_bgp_active,
            # PE derivation
            'derive_pe_ip':                       derive_pe_ip,
            'compute_other_end_ip':               compute_other_end_ip,
            # Input normalization
            'normalize_description':              normalize_description,
            'extract_neid_from_description':      extract_neid_from_description,
            'derive_shortname_from_neid':         derive_shortname_from_neid,
            'derive_site_group':                  derive_site_group,
            # ServiceNow message sanitizer
            'replace_update_with_notify':         replace_update_with_notify,
            'detect_mgmt_iface_admin_down':       detect_mgmt_iface_admin_down,
            # Running-config diff
            'diff_running_configs':               diff_running_configs,
            # Utility
            'summarize_phase_results':            summarize_phase_results,
            'extract_bgp_neighbor_section':       extract_bgp_neighbor_section,
            'check_privilege_denied':             check_privilege_denied,
            'precheck_aborted':                   precheck_aborted,
            'redact_password':                    redact_password,
            'resolve_login_chain':                resolve_login_chain,
            'resolve_enable_chain':               resolve_enable_chain,
            # v41 - credential roles (tacacs / local / enable)
            'credential_roles_summary':           credential_roles_summary,
            'promote_login_user':                 promote_login_user,
            'classify_jump_failure':              classify_jump_failure,
            # v37.6 NOC-format additions
            'count_real_outputs':                 count_real_outputs,
            'select_crux_commands':               select_crux_commands,
            'evaluate_device_stability':          evaluate_device_stability,
            'cap_response_msg':                   cap_response_msg,
            # v37.8 NOC-format additions (ntc-templates)
            'clean_cli_outputs':                  clean_cli_outputs,
            'format_cmd_output':                  format_cmd_output,
            # v37.12 NOC-format additions (observation facts extraction)
            'parse_show_version_facts':           parse_show_version_facts,
            'parse_ip_int_brief_stats':           parse_ip_int_brief_stats,
            # v39 NOC standard report helpers
            'parse_alarm_fields':                 parse_alarm_fields,
            'trim_cmd_output':                    trim_cmd_output,
            # BGP TCP-layer evidence
            'parse_bgp_neighbor_tcp_state':       parse_bgp_neighbor_tcp_state,
            'evaluate_bgp_underlay_with_tcp':     evaluate_bgp_underlay_with_tcp,
        }
