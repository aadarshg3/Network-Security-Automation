#!/usr/bin/env python3
"""
jump_ssh.py - iAutomate two-hop SSH executor for Cisco-Router-Device-Down.

Hop-1: SSH to secondary CE.
Hop-2: from secondary, SSH to primary CE via LAN/VRRP IP.
Runs show commands (and optionally config commands with a pre-check gate)
on the primary.  All remediation-path phases use this script instead of
device_ssh.py, because MgmtIP is unreachable on the secondary-jump path.

Usage:
  python3 jump_ssh.py '<sec_host>' '<sec_user>' '<sec_pw_json>' \
      '<primary_ip>' '<pri_pw_json>' '<commands_json>' \
      ['<pre_check_json>'] ['<config_cmds_json>'] \
      [platform=ios|ios_xe|ios_xr] [expect_hostname=<primary-neid>]

  sec_pw_json / pri_pw_json : JSON arrays of credentials. v41: role-tagged
                              dicts {user, pass, role} from resolve_login_chain
                              (role tacacs / local / enable / enable_fallback);
                              bare strings are still accepted (legacy).
  commands_json             : JSON list of show/exec commands to run.
  pre_check_json (optional) : {"command":"...", "must_contain":"..."} gate.
                              If condition not met, config_cmds are skipped
                              and result.pre_check_failed = True.
  config_cmds_json (optional): JSON list of config/exec commands to run
                              AFTER show commands (e.g. WAN bounce, BGP clear).
                              Each command is sent individually and awaits the
                              next prompt (works for both exec and config mode).

Always exits 0. JSON on stdout matches device_ssh.py shape so downstream
Ansible tasks (safe_json_parse, precheck_aborted, check_privilege_denied)
work identically regardless of which script was called.
"""

import sys
import json
import re
import time
import signal

try:
    from netmiko import ConnectHandler
    _NETMIKO_OK = True
except ImportError as _ie:
    _NETMIKO_OK = False
    _IMPORT_ERR = str(_ie)

_DRIVER_MAP = {'ios': 'cisco_ios', 'ios_xe': 'cisco_ios', 'ios_xr': 'cisco_xr'}

_HOSTKEY_PROMPT = re.compile(r'\(yes/no\)|continue connecting|fingerprint', re.IGNORECASE)
# Password prompt may be followed by a streamed login banner, so do NOT anchor to
# end-of-buffer. Match the prompt anywhere in the freshly-read window.
_PASSWORD_PROMPT = re.compile(r'[Pp]assword:\s*', re.MULTILINE)
_REFUSED        = re.compile(r'[Cc]onnection refused|refused by remote host', re.IGNORECASE)
_NO_ROUTE       = re.compile(r'%?\s*(No route to host|Destination unreachable|Connection timed out|% Connection)', re.IGNORECASE)
# Exec prompt: hostname followed by # or > at end of a line. Allow trailing
# whitespace; the prompt is the last meaningful token on the channel.
_EXEC_PROMPT    = re.compile(r'[\r\n][\w.\-]+[#>]\s*$')
_ANY_PROMPT     = re.compile(r'[\w.\-]+(?:\(config[^\)]*\))?[#>]\s*$')


def _result(**kw):
    base = {
        'success': False, 'outputs': {}, 'output': '', 'error': None,
        'stage': 'secondary_ssh',
        'secondary_login': False, 'jump_attempted': False, 'jump_login': False,
        'connection_refused': False, 'landing_verified': False,
        'enable_mode': False,
        'login_cred_index': 0, 'auth_failed': False, 'no_route': False,
        'login_user': '',
        # v41 - credential role that landed, failed logins spent on the primary,
        # and whether a refusal followed one of our own failed logins.
        'login_role': '', 'failed_logins': 0, 'refused_after_failed_login': False,
        'primary_ip_used': '', 'detail': '',
        # device_ssh.py compat keys so precheck_aborted / check_privilege_denied work
        'pre_check_failed': False, 'pre_check_output': '', 'privilege_denied': False,
    }
    base.update(kw)
    return base


# ---------------------------------------------------------------------------
# Hop-1: SSH to secondary
# ---------------------------------------------------------------------------

def _norm_creds(raw, default_user):
    """Normalize a credential list into [{'user','pass','role','preferred'}].

    Accepts dicts or bare strings. v41 - keeps the 'role' tag written by the
    resolve_login_chain filter (tacacs / local / enable / enable_fallback).
    Untagged items get role 'login' (legacy behaviour).
    """
    out = []
    if isinstance(raw, str):
        raw = [raw]
    for item in (raw or []):
        if isinstance(item, dict):
            role = str(item.get('role') or 'login')
            pw = item.get('pass')
            if role in ('enable', 'enable_fallback'):
                user = item.get('user') or ''
            else:
                user = item.get('user') or default_user
            if pw:
                out.append({'user': user, 'pass': pw, 'role': role,
                            'preferred': bool(item.get('preferred'))})
        elif item:
            out.append({'user': default_user, 'pass': item, 'role': 'login', 'preferred': False})
    return out


_LOGIN_ROLES = ('tacacs', 'local', 'login')


def _secondary_login_creds(creds):
    """Secondary router login: TACACS only (its management path is up).

    Falls back to every login-capable entry only for untagged (legacy) input.
    Enable secrets are never used as a login.
    """
    tac = [c for c in creds if c['role'] == 'tacacs']
    if tac:
        return tac
    return [c for c in creds if c['role'] in _LOGIN_ROLES]


def _primary_login_creds(creds):
    """Jump login order on the primary.

    v41 - Verizon CE AAA is 'login default local-case group <TACACS>': a local
    account is checked first and works while TACACS is unreachable (primary
    management path down). Order: the credential that already landed in this
    run (preferred), then local (CINFO), then TACACS. One try per distinct
    (user, password). Enable secrets are never used as a login.
    """
    logins = [c for c in creds if c['role'] in _LOGIN_ROLES]
    if any(c['role'] in ('local', 'tacacs') for c in logins):
        rank = {'local': 0, 'tacacs': 1, 'login': 2}
        logins = sorted(logins, key=lambda c: (0 if c.get('preferred') else 1, rank.get(c['role'], 3)))
    out, seen = [], set()
    for c in logins:
        key = (c['user'], c['pass'])
        if key not in seen:
            seen.add(key)
            out.append(c)
    return out


def _enable_secrets(creds):
    """Enable secrets in priority order: CINFO enable, CINFO local password
    kept as fallback, then the login passwords. Distinct, order-preserving."""
    rank = {'enable': 0, 'enable_fallback': 1, 'local': 2, 'tacacs': 3, 'login': 4}
    out, seen = [], set()
    for c in sorted(creds, key=lambda c: rank.get(c['role'], 5)):
        if c['pass'] not in seen:
            seen.add(c['pass'])
            out.append(c['pass'])
    return out


def _group_by_user(creds):
    """Group [{'user','pass'}] into [(user, [passwords])], preserving first-seen order."""
    order, bucket = [], {}
    for c in creds:
        u = c['user']
        if u not in bucket:
            bucket[u] = []
            order.append(u)
        bucket[u].append(c['pass'])
    return [(u, bucket[u]) for u in order]


def _try_secondary(sec_host, sec_creds, platform):
    driver = _DRIVER_MAP.get(str(platform).lower(), 'cisco_ios')
    last_err = None
    for c in sec_creds:
        try:
            conn = ConnectHandler(
                device_type=driver, host=sec_host, username=c['user'],
                password=c['pass'], secret=c['pass'], conn_timeout=30, auth_timeout=30,
                banner_timeout=30, fast_cli=False,
            )
            try:
                conn.enable()
            except Exception:
                pass
            return conn, c['user'], c['pass'], None
        except Exception as e:
            last_err = f'{type(e).__name__}: {e}'
    return None, None, None, last_err or 'secondary auth failed (all credentials)'


# ---------------------------------------------------------------------------
# Hop-2: in-session SSH from secondary to primary
# ---------------------------------------------------------------------------

def _prompt_hostname(text):
    """
    Return the hostname of the last exec prompt (e.g. 'R25#' -> 'r25') found
    anywhere in the buffer. Robust to banner lines that follow the prompt.
    """
    if not text:
        return ''
    matches = re.findall(r'(?m)^([\w.\-]+)[#>]\s*$', text)
    if matches:
        return matches[-1].strip().lower()
    # Fallback: last non-empty line ending in # or >
    for line in reversed(text.strip().splitlines()):
        m = re.match(r'^([\w.\-]+)[#>]\s*$', line.strip())
        if m:
            return m.group(1).strip().lower()
    return ''


def _attempt_jump(conn, ssh_cmd, password, secondary_hostname, deadline_s=25):
    """One login attempt from the secondary to the primary: ONE password.

    v41 - Verizon CEs run 'login block-for 60 attempts 3 within 30'. Every
    rejected password counts, so:
      - exactly one password is sent per ssh session; a second Password:
        prompt means the login was rejected and the attempt stops there,
      - no blank Enter is ever sent before or at a Password: prompt (an
        empty line there is an empty password = one more failed login),
      - the caller opens a fresh secondary session for the next credential
        instead of Ctrl-C (Ctrl-C may not leave the IOS ssh client prompt).
    """
    out = {
        'jump_attempted': True, 'jump_login': False, 'connection_refused': False,
        'landing_verified': False, 'detail': '', 'error': None,
        'login_cred_index': 0, 'auth_failed': False, 'no_route': False,
        'password_sent': False,
    }
    trail = [f'issued: {ssh_cmd}']
    sec_host = str(secondary_hostname).strip().lower()

    # Raw-channel reader. Inside a nested SSH jump the session is NOT
    # Netmiko-managed, so we read the channel directly and accumulate everything
    # the device streams (SSH banner -> Password: -> login banner -> exec prompt),
    # tolerating multi-line banners that arrive in fragments.
    def _read(window):
        """Accumulate channel data up to `window` seconds, returning as soon as
        the stream goes quiet after data arrives."""
        buf = ''
        end = time.time() + window
        idle = 0
        while time.time() < end:
            try:
                chunk = conn.read_channel()
            except Exception:
                chunk = ''
            if chunk:
                buf += chunk
                idle = 0
            else:
                idle += 1
                if buf and idle >= 2:   # ~0.4s quiet after data => settled
                    break
            time.sleep(0.2)
        return buf

    try:
        conn.write_channel(ssh_cmd + '\n')
        buf = _read(6)
        nudged = False
        deadline = time.time() + deadline_s
        while True:
            if _REFUSED.search(buf):
                out['connection_refused'] = True
                out['detail'] = '; '.join(trail + ['Connection refused by remote host'])
                return out
            if _NO_ROUTE.search(buf):
                out['no_route'] = True
                out['detail'] = '; '.join(trail + ['no route / timeout to primary'])
                return out
            if _HOSTKEY_PROMPT.search(buf):
                conn.write_channel('yes\n')
                trail.append('answered host-key yes')
                buf = ''
            elif _PASSWORD_PROMPT.search(buf):
                if not out['password_sent']:
                    conn.write_channel(password + '\n')
                    out['password_sent'] = True
                    out['login_cred_index'] = 1
                    trail.append('sent password at Password:')
                    buf = ''
                else:
                    # A new Password: prompt after our password = rejected.
                    out['auth_failed'] = True
                    out['detail'] = '; '.join(trail + ['login rejected (Password: prompted again)'])
                    return out
            elif out['password_sent']:
                host = _prompt_hostname(buf)
                if host:
                    if sec_host and host == sec_host:
                        out['auth_failed'] = True
                        out['detail'] = '; '.join(trail + [f'login rejected, returned to secondary {host!r}'])
                        return out
                    out['jump_login'] = True
                    out['landing_verified'] = True
                    trail.append(f'landed on primary, prompt host {host!r}')
                    out['detail'] = '; '.join(trail)
                    return out
            if time.time() >= deadline:
                break
            new = _read(3)
            buf += new
            # One safe nudge only: password already sent, the login banner has
            # arrived (buffer not empty), no Password: prompt, no exec prompt,
            # and the channel went quiet. Never before the password.
            if (not new and not nudged and out['password_sent'] and buf.strip()
                    and not _PASSWORD_PROMPT.search(buf) and not _prompt_hostname(buf)):
                conn.write_channel('\n')
                nudged = True
                trail.append('banner received, prompt not shown - one Enter sent')
                buf += _read(3)

        tail = buf.strip().splitlines()[-1] if buf.strip() else ''
        stage = 'after password' if out['password_sent'] else 'before any Password: prompt'
        out['detail'] = '; '.join(trail + [f'no verified exec prompt within {deadline_s}s ({stage}, last seen: {tail!r})'])
        return out
    except Exception as e:
        out['error'] = f'jump exception: {type(e).__name__}: {e}'
        out['detail'] = '; '.join(trail + [out['error']])
        return out


def _jump_to_primary(conn, reopen_secondary, primary_ip, login_creds, secondary_hostname,
                     max_failed_logins=2):
    """Try each login credential once, each in a FRESH secondary session.

    Stops at: landing, a refusal (deterministic - VTY access list or login
    block), no route, or max_failed_logins rejected logins (stays below the
    'login block-for ... attempts 3' threshold). Returns (conn, attempt).
    """
    history = []
    failed = 0
    last = None
    for i, cred in enumerate(login_creds):
        if i > 0:
            try:
                conn.disconnect()
            except Exception:
                pass
            conn, err = reopen_secondary()
            if conn is None:
                history.append(f'#{i + 1} secondary re-login failed: {err}')
                break
        ssh_cmd = f"ssh -l {cred['user']} {primary_ip}"
        attempt = _attempt_jump(conn, ssh_cmd, cred['pass'], secondary_hostname)
        attempt['login_user'] = cred['user']
        attempt['login_role'] = cred['role']
        attempt['login_cred_index'] = i
        last = attempt
        history.append(f"#{i + 1} user={cred['user']} role={cred['role']} -> {_attempt_outcome(attempt)}")
        if attempt['jump_login'] and attempt['landing_verified']:
            break
        if attempt['connection_refused']:
            attempt['refused_after_failed_login'] = failed > 0
            break
        if attempt['no_route']:
            break
        if attempt.get('password_sent'):
            failed += 1
        if failed >= max_failed_logins:
            history.append(f'stopped after {failed} rejected logins (login block protection)')
            break
    if last is None:
        last = {'jump_attempted': False, 'jump_login': False, 'connection_refused': False,
                'landing_verified': False, 'detail': '', 'error': 'no login credential for the primary',
                'login_cred_index': 0, 'auth_failed': False, 'no_route': False,
                'login_user': '', 'login_role': ''}
    last['failed_logins'] = failed
    last.setdefault('refused_after_failed_login', False)
    last['detail'] = f'attempt history: {" | ".join(history)} | last: {last.get("detail", "")}'
    return conn, last


def _attempt_outcome(attempt):
    """Short outcome label for a single per-user jump attempt."""
    if attempt.get('jump_login') and attempt.get('landing_verified'):
        return 'landed'
    if attempt.get('connection_refused'):
        return 'acl_refused'
    if attempt.get('auth_failed'):
        return 'auth_failed'
    if attempt.get('no_route'):
        return 'no_route'
    if attempt.get('error'):
        return f'error:{type(attempt["error"]).__name__ if not isinstance(attempt["error"], str) else attempt["error"][:40]}'
    return 'no_exec_prompt'


def classify_jump_failure(result):
    """Derive an honest, NOC-readable reason for the jump failure.

    Returns a dict: {category, summary, detail}. category is one of:
      auth_failed, acl_refused, no_route, hung_at_banner, unknown.
    """
    if not isinstance(result, dict):
        return {'category': 'unknown', 'summary': 'jump result missing or malformed', 'detail': ''}
    if result.get('connection_refused'):
        return {
            'category': 'acl_refused',
            'summary': 'VTY ACL on the primary refused the SSH session from the secondary',
            'detail': 'Check the primary VTY access-class permits the secondary management IP.',
        }
    if result.get('auth_failed'):
        return {
            'category': 'auth_failed',
            'summary': 'All credentials were rejected by the primary',
            'detail': ('Likely cause: the configured login account is not authorized on this device '
                       '(e.g. TACACS unreachable on a loopback-down event AND no local fallback '
                       'account configured), or the cinfo password is wrong for the user that was tried.'),
        }
    if result.get('no_route'):
        return {
            'category': 'no_route',
            'summary': 'No route or L3 timeout from the secondary to the primary',
            'detail': 'Primary is unreachable at L3 from the secondary - likely WAN/LAN failure, not auth.',
        }
    if result.get('jump_attempted') and not result.get('landing_verified'):
        return {
            'category': 'hung_at_banner',
            'summary': 'SSH session opened but no verified exec prompt was returned',
            'detail': ('Possible causes: unexpected MOTD/banner stalled the read loop, host-key prompt '
                       'not handled, or the primary accepted SSH but its login process is unresponsive.'),
        }
    if result.get('error'):
        return {'category': 'unknown', 'summary': 'jump exception',
                'detail': str(result.get('error'))[:240]}
    return {'category': 'unknown', 'summary': 'jump failed without a recognized fault signal', 'detail': ''}


# ---------------------------------------------------------------------------
# Enable-mode elevation on the landed primary
# ---------------------------------------------------------------------------

def _enable_on_primary(conn, enable_pw_list):
    """Elevate the landed primary from user EXEC (>) to privileged EXEC (#).

    v41 - the CINFO enable secret is tried first (list order comes from
    _enable_secrets). One 'enable' command is answered at each Password:
    prompt with the next secret (IOS allows 3 per 'enable'); 'enable' is only
    re-sent after IOS returns to the '>' prompt. The word 'enable' is never
    typed at a Password: prompt. No-op (True) when the prompt is already '#'.
    """
    enable_re = re.compile(r'[\w.\-]+#\s*$')

    def _rd(window):
        buf = ''
        end = time.time() + window
        idle = 0
        while time.time() < end:
            try:
                chunk = conn.read_channel()
            except Exception:
                chunk = ''
            if chunk:
                buf += chunk
                idle = 0
            else:
                idle += 1
                if buf and idle >= 2:
                    break
            time.sleep(0.2)
        return buf

    conn.write_channel('\n')
    if enable_re.search(_rd(3)):
        return True
    remaining = list(enable_pw_list or [])
    while remaining:
        conn.write_channel('enable\n')
        buf = _rd(3)
        if enable_re.search(buf):
            return True
        if not _PASSWORD_PROMPT.search(buf):
            break                      # e.g. '% No password set' - nothing to answer
        while remaining and _PASSWORD_PROMPT.search(buf):
            conn.write_channel(remaining.pop(0) + '\n')
            buf = _rd(3)
            if enable_re.search(buf):
                return True
        if _PASSWORD_PROMPT.search(buf):
            # secrets exhausted while IOS still waits at Password: - leave it cleanly
            conn.write_channel('\x03')
            _rd(2)
            break
    conn.write_channel('\n')
    return bool(enable_re.search(_rd(3)))


# ---------------------------------------------------------------------------
# Run commands on landed primary session
# ---------------------------------------------------------------------------

def _run_on_primary(conn, commands, pre_check=None, config_commands=None):
    """
    Execute show/exec commands on the landed primary session. Netmiko's
    base_prompt must already be re-baselined to the primary by the caller.

    pre_check      : {'command','must_contain'} gate; if unmet, config is skipped
                     and outputs['_pre_check_aborted']='True'.
    config_commands: commands sent after show commands (exec or config mode).
    """
    outputs = {}

    def _send(cmd, timeout):
        # Prefer base_prompt-aware send; fall back to a permissive prompt regex.
        try:
            return conn.send_command(cmd, read_timeout=timeout)
        except Exception:
            return conn.send_command(
                cmd, read_timeout=timeout,
                expect_string=r'[\w.\-]+[#>]\s*$')

    if pre_check and isinstance(pre_check, dict):
        gate_cmd = pre_check.get('command', '')
        must_contain = pre_check.get('must_contain', '')
        if gate_cmd and must_contain:
            try:
                gate_output = _send(gate_cmd, 30)
                outputs['_pre_check_gate'] = gate_output
                if must_contain.lower() not in gate_output.lower():
                    outputs['_pre_check_aborted'] = 'True'
                    return outputs
            except Exception as e:
                outputs['_pre_check_error'] = f'[PRE-CHECK ERROR] {type(e).__name__}: {e}'
                outputs['_pre_check_aborted'] = 'True'
                return outputs

    for cmd in commands:
        try:
            outputs[cmd] = _send(cmd, 45)
        except Exception as e:
            outputs[cmd] = f'[COMMAND ERROR] {type(e).__name__}: {e}'

    if config_commands and isinstance(config_commands, list):
        cfg_lines = []
        for cmd in config_commands:
            try:
                out = conn.send_command(
                    cmd, read_timeout=30,
                    expect_string=r'[\w.\-]+(?:\(config[^\)]*\))?[#>]\s*$')
                cfg_lines.append(f'[{cmd}]\n{out}')
            except Exception as e:
                cfg_lines.append(f'[{cmd}] [ERROR] {type(e).__name__}: {e}')
        outputs['_config_output'] = '\n'.join(cfg_lines)

    return outputs


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

# Hard wall-clock cap. Verizon CEs with mgmt down + TACACS unreachable, or a
# half-open nested SSH, can make netmiko disconnect()/read loops block well past
# the per-attempt deadlines (observed 186s in SIT). The Ansible script task has
# no timeout of its own, so without this a single stuck ticket hangs the whole
# Jenkins job. On the alarm we emit the best-effort result and exit 0, exactly
# like every other exit path, so downstream parsing is unaffected.
JUMP_HARD_TIMEOUT = 150
_LAST_RESULT = None


def _emit_and_exit(res):
    try:
        print(json.dumps(res))
    except Exception:
        print(json.dumps({'success': False, 'outputs': {}, 'output': '',
                          'error': 'jump hard timeout (result not serializable)',
                          'pre_check_failed': False, 'privilege_denied': False}))
    sys.stdout.flush()
    import os
    os._exit(0)


def _on_timeout(signum, frame):
    res = _LAST_RESULT if isinstance(_LAST_RESULT, dict) else _result()
    res['error'] = ('hard timeout after %ss - ' % JUMP_HARD_TIMEOUT) + str(res.get('error') or 'no response from device')
    res['detail'] = (str(res.get('detail') or '') + ' | aborted by hard timeout').strip(' |')
    _emit_and_exit(res)


def main():
    platform = 'ios'
    secondary_hostname = ''
    jump_password_override = ''   # LAB-ONLY: if set, tried first. Empty in prod.
    jump_user_override = ''       # LAB-ONLY: if set, used for the jump ssh -l. Empty in prod.
    argv = []
    for a in sys.argv[1:]:
        if a.startswith('platform='):
            platform = a.split('=', 1)[1] or 'ios'
        elif a.startswith('secondary_hostname='):
            secondary_hostname = a.split('=', 1)[1]
        elif a.startswith('jump_password_override='):
            jump_password_override = a.split('=', 1)[1]
        elif a.startswith('jump_user_override='):
            jump_user_override = a.split('=', 1)[1]
        elif a.startswith('expect_hostname='):
            # back-compat: ignored for landing logic; kept so callers don't break
            pass
        else:
            argv.append(a)

    if not _NETMIKO_OK:
        print(json.dumps(_result(error=f'netmiko import failed: {_IMPORT_ERR}')))
        sys.exit(0)

    if len(argv) < 6:
        print(json.dumps(_result(
            error='Usage: jump_ssh.py sec_host sec_user sec_pw_json primary_ip pri_pw_json '
                  'commands_json [pre_check_json] [config_cmds_json] [platform=] [secondary_hostname=]')))
        sys.exit(0)

    sec_host, sec_user = argv[0], argv[1]
    try:
        sec_pw_list = json.loads(argv[2])
        primary_ip  = argv[3]
        pri_pw_list = json.loads(argv[4])
        commands    = json.loads(argv[5])
    except Exception as e:
        print(json.dumps(_result(error=f'bad JSON arg (positions 2-5): {e}')))
        sys.exit(0)

    # Optional: pre_check (argv[6]) and config_commands (argv[7])
    pre_check = {}
    config_commands = []
    if len(argv) > 6 and argv[6] not in ('{}', ''):
        try:
            pre_check = json.loads(argv[6]) or {}
        except Exception:
            pre_check = {}
    if len(argv) > 7 and argv[7] not in ('[]', ''):
        try:
            config_commands = json.loads(argv[7]) or []
        except Exception:
            config_commands = []

    # Normalize both hops to [{'user','pass','role','preferred'}]. Items may
    # arrive role-tagged (resolve_login_chain) or as bare strings (legacy).
    sec_creds = _secondary_login_creds(_norm_creds(sec_pw_list, sec_user))
    all_pri = _norm_creds(pri_pw_list, sec_user)
    pri_login = _primary_login_creds(all_pri)

    # LAB-ONLY override: force a single jump username and/or a first-tried password.
    # Defaults empty -> no effect in prod. Never set these extra-vars in production.
    if jump_user_override:
        pri_login = [dict(c, user=jump_user_override) for c in pri_login]
    if jump_password_override:
        forced_user = jump_user_override or sec_user
        pri_login = ([{'user': forced_user, 'pass': jump_password_override, 'role': 'local', 'preferred': True}]
                     + [c for c in pri_login if c['pass'] != jump_password_override])

    enable_pw_list = _enable_secrets(all_pri)

    res = _result(primary_ip_used=primary_ip)
    global _LAST_RESULT
    _LAST_RESULT = res            # same object; later mutations are visible to the handler
    if hasattr(signal, 'SIGALRM'):
        try:
            signal.signal(signal.SIGALRM, _on_timeout)
            signal.alarm(JUMP_HARD_TIMEOUT)
        except Exception:
            pass

    # Hop-1: SSH to secondary
    conn, sec_login_user, _sec_pw, err = _try_secondary(sec_host, sec_creds, platform)
    if not conn:
        res['error'] = f'secondary SSH failed: {err}'
        res['stage'] = 'secondary_ssh'
        print(json.dumps(res))
        sys.exit(0)
    res['secondary_login'] = True
    res['secondary_login_user'] = sec_login_user
    res['stage'] = 'vrrp_jump'

    # v41 - the live prompt of the secondary is authoritative for "did we
    # bounce back to the secondary?" (a passed NEID may differ from the
    # configured hostname). The passed value is only a fallback.
    try:
        _live_host = _prompt_hostname(conn.find_prompt())
    except Exception:
        _live_host = ''
    if _live_host:
        secondary_hostname = _live_host

    def _reopen():
        c, _u, _p, e = _try_secondary(sec_host, sec_creds, platform)
        return c, e

    if not pri_login:
        res['error'] = 'no login credential for the primary (TACACS and CINFO local both missing)'
        try:
            conn.disconnect()
        except Exception:
            pass
        print(json.dumps(res))
        sys.exit(0)

    conn, jump = _jump_to_primary(conn, _reopen, primary_ip, pri_login, secondary_hostname)
    res.update({k: jump.get(k, res.get(k)) for k in
                ('jump_attempted', 'jump_login', 'connection_refused',
                 'landing_verified', 'detail',
                 'login_cred_index', 'auth_failed', 'no_route', 'login_user',
                 'login_role', 'failed_logins', 'refused_after_failed_login')})
    if jump.get('error'):
        res['error'] = jump['error']

    if not (jump.get('jump_login') and jump.get('landing_verified')):
        try:
            if conn is not None:
                conn.disconnect()
        except Exception:
            pass
        print(json.dumps(res))
        sys.exit(0)

    # Landed and verified - run commands on primary
    res['stage'] = 'landed'

    # The jump was done over the raw channel, so Netmiko's base_prompt still
    # reflects the SECONDARY. Re-baseline to the primary and disable paging on
    # the primary itself, otherwise send_command mismatches the prompt and long
    # outputs stall at --More--.
    try:
        conn.set_base_prompt()
    except Exception:
        pass
    try:
        conn.write_channel('terminal length 0\n')
        time.sleep(1.0)
        conn.read_channel()
    except Exception:
        pass
    try:
        conn.set_base_prompt()
    except Exception:
        pass

    # Elevate to enable mode. The local account (CINFO 3, e.g. VZuser without
    # 'privilege 15') lands in user EXEC (>) and needs the CINFO 4 enable
    # secret. No-op if already enabled.
    res['enable_mode'] = _enable_on_primary(conn, enable_pw_list)
    try:
        conn.set_base_prompt()
    except Exception:
        pass

    outputs = _run_on_primary(conn, commands, pre_check, config_commands)
    res['outputs'] = outputs
    # Pre-check compat: set pre_check_failed if the gate aborted
    if '_pre_check_aborted' in outputs:
        res['pre_check_failed'] = True
    res['success'] = True
    res['stage'] = 'done'

    try:
        conn.disconnect()
    except Exception:
        pass

    if hasattr(signal, 'SIGALRM'):
        try:
            signal.alarm(0)
        except Exception:
            pass
    print(json.dumps(res))
    sys.exit(0)


if __name__ == '__main__':
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:
        import json as _j, sys as _s
        print(_j.dumps({'success': False, 'outputs': {}, 'output': '',
                        'error': f'unhandled exception: {exc}',
                        'pre_check_failed': False, 'privilege_denied': False}))
        _s.exit(0)
