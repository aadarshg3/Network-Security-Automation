#!/usr/bin/env python3
"""SSH diagnostic collection script for Cisco Viptela SD-WAN devices.

Supports both vEdge (Viptela OS) and cEdge (IOS-XE SD-WAN) platforms.
Outputs JSON to stdout for Ansible consumption.

Credentials are NEVER read from argv (which would appear in
/proc/<pid>/cmdline for any local user). The password is taken from
stdin or from the VIPTELA_SSH_PASSWORD environment variable.
"""

# Target runtime: Python 3.12 (/usr/bin/python3.12 on prod agents, paramiko 4.x).
# Compiles cleanly under -W error on 3.12. Annotations remain stringless to keep
# the script portable to any 3.x interpreter without `from __future__`.

import argparse
import getpass
import json
import logging
import os
import re
import socket
import sys
import time
from typing import Dict, Optional

try:
    import paramiko
except ImportError:
    # Emit parseable last-error line on stderr for role-side capture (F5),
    # plus result-shaped JSON on stdout. Exit 0 so Ansible branches on
    # `success`, not on rc.
    sys.stderr.write(
        "VIPTELA_SSH_LAST_ERROR: dep_missing | "
        "paramiko not available in current python interpreter\n")
    print(json.dumps({"success": False, "error": "paramiko not installed",
                      "outputs": {}, "errors": {}, "platform": ""}))
    sys.exit(0)


def _emit_last_error(code: str, message: str) -> None:
    """Print one parseable last-error line to stderr for role-side capture.

    Format (fixed, parsed by tasks/device_ssh.yaml):
        VIPTELA_SSH_LAST_ERROR: <code> | <sanitized-message>

    Codes (closed set): dep_missing, tcp_refused, tcp_timeout, auth_rejected,
    host_key_mismatch, prompt_timeout, generic.

    I8 (v27.1): the message is scrubbed of the three substrings that the
    master template's `is_failed` regex matches on — leaking any of them
    into the role's response_msg on a success-path run flips status_codes
    to 2 and holds the ticket. Equivalent phrases are substituted so the
    operator still gets a readable cause.
    """
    allowed = {"dep_missing", "tcp_refused", "tcp_timeout", "auth_rejected",
               "host_key_mismatch", "prompt_timeout", "generic"}
    tag = code if code in allowed else "generic"
    msg = (message or "").replace("\n", " ").replace("\r", " ").strip()
    # Replace master-trigger phrases (case-insensitive) with equivalents.
    msg = re.sub(r"authentication\s+failed", "auth rejected", msg, flags=re.I)
    msg = re.sub(r"destination\s+host\s+unreachable", "dest host unreachable",
                 msg, flags=re.I)
    msg = re.sub(r"100%\s+packet\s+loss", "100% loss", msg, flags=re.I)
    msg = msg[:200]
    sys.stderr.write("VIPTELA_SSH_LAST_ERROR: %s | %s\n" % (tag, msg))

# Warnings go to stderr — Ansible captures stderr separately from stdout, so
# the JSON contract on stdout stays clean while a truncation/paging warning
# is still recoverable when debugging. Log lines never carry the password.
logging.basicConfig(level=logging.WARNING, stream=sys.stderr,
                    format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)

CEDGE_COMMANDS: Dict[str, str] = {
    "system_status":       "show sdwan system status",
    # v27.1.26 REGRESSION FIX (wawai Oct-19 cohort vs Oct-9 cohort
    # TASK70977{06,17,86}). Verified against the Oct-9 source zip
    # supplied by Aadarsh 2026-10-21.
    #
    # Oct-9 ran: `show version | include uptime|System|returned|reload|image`
    # Oct-19 ran: `show version | include uptime|System returned|reload|image`
    #            (changed by v27.1.17 "GAP-A", which claimed the extra `|`
    #            between "System" and "returned" was a typo and removed it.)
    #
    # The v27.1.17 change was ACTUALLY A REGRESSION. The Oct-9 form had
    # five alternations — uptime | System | returned | reload | image —
    # and the "System" alternation substring-matches "Systems" in both
    # Cisco Copyright lines (that's how the Oct-9 rendered output got
    # 6 lines including both Copyright lines). The "GAP-A fix" collapsed
    # five alternations to four and lost those Copyright-line matches.
    # On some wawai Controller-Managed cEdges Oct-19 the four-alternation
    # form returned empty body entirely and only the SSH-banner Copyright
    # line survived through the read loop.
    #
    # Fix: stop depending on IOS-XE pipe-filter parser quirks. Collect
    # plain `show version` (what any cEdge accepts) and filter in the
    # role via `cli_version_filter`, which keeps the MOP step 58 anchor
    # lines (Cisco IOS header, Copyright, "uptime is", "System returned
    # to ROM", image file, Last reload). Deterministic across every
    # IOS-XE build. parse_cli_uptime already handles full show-version.
    "version":             "show version",
    "control_connections": "show sdwan control connections",
    "control_history":     "show sdwan control connection-history",
    "control_local_props": "show sdwan control local-properties",
    "wan_interface_list":  "show sdwan control local-properties wan-interface-list",
    "tunnel_statistics":   "show sdwan tunnel statistics",
    "omp_peers":           "show sdwan omp peers",
    "bfd_sessions":        "show sdwan bfd sessions",
    "cert_validity":       "show sdwan certificate validity",
    "cert_installed":      "show sdwan certificate installed",
    # v27.1.34 FIX for the NOC-visible "(no output - command rejected)"
    # under --- cert_status --- on every IOS-XE 17.12.x cEdge ticket.
    # Confirmed on TWO independent production NOC captures (2026-10-22):
    #   - NYKBUS-VNYLKHNM2-C (ISR1100-4G, IOS-XE 17.15.1r / build
    #     17.12.08.0.9349)
    #   - aecom-london-dc1-23860719 (C8300-1N1S-4T2X, IOS-XE 17.12 /
    #     build 17.12.08.0.9349)
    # Both devices rejected `show sdwan certificate status` with
    # `% Invalid input detected at '^' marker.` — a short (<500 char)
    # response that starts with `% Invalid input`, so clean_cli_dict's
    # _looks_like_device_error drops the capture and DIAG renders the
    # friendly fallback. The command simply does not exist on this
    # IOS-XE SD-WAN train. `show sdwan certificate validity` IS
    # supported, returns real cert health (validity window + install
    # status), and is already captured under `cert_validity`. Making
    # cert_status an alias of cert_validity on cEdge removes the
    # NOC-visible rejection noise without losing any operational
    # signal. Mirrors the v27.1.27 vEdge-side fix where the same
    # pattern was applied for Viptela OS 20.3.8 syntax-error output.
    "cert_status":         "show sdwan certificate validity",
    # v27.1.17 GAP-B fix: MOP step 60 lists `show sdwan bfd history`
    # alongside `show sdwan control connection-history` for flap
    # detection. Previously only control history was captured, so
    # BFD-only flap evidence relied on vManage telemetry alone.
    "bfd_history":         "show sdwan bfd history",
    "interfaces_desc":     "show interfaces description",
    "ip_int_brief":        "show ip interface brief",
    "logging_control":     "show logging | include control",
    # v27.1.10 (user-approved after SIT review on deapega-cedge-cpe5):
    # on IOS-XE `show logging last N` emits the full config banner first
    # (~500 chars of noise) and only then the real log messages. Using
    # `| begin Log Buffer` jumps directly to the universal IOS-XE
    # "Log Buffer (xxx bytes):" header — the one line that reliably
    # precedes the real syslog entries on both SD-WAN cEdge AND classic
    # IOS-XE autonomous mode. NO QUOTES — IOS-XE's pipe-filter parser
    # treats the entire tail of the command line as a POSIX regex, so
    # `| begin "Log Buffer"` would search for the literal 10 bytes
    # including the quote marks and never match. Spaces inside the
    # regex are literal and need no escaping.
    "logging_last":        "show logging last 100 | begin Log Buffer",
    "arp":                 "show arp",
    "ip_route":            "show ip route",
    # v27.1.34 FIX for the mislabeled DIAG --- reboot_history --- section
    # on every cEdge ticket. The prior v23 choice `show platform` returns
    # slot/module hardware inventory (chassis type, line cards, firmware
    # per slot) — NOT reboot history. NOC confirmed on two independent
    # NOC-forwarded captures (2026-10-22, NYKBUS and aecom-london-dc1):
    #   - NYKBUS `show platform` returned one line: `Chassis type: ISR1100-4G`
    #   - aecom-london `show platform` returned a 20-row slot/firmware table
    # Neither contains last-reload reason, uptime, or restart time.
    #
    # On a Device-Down ticket NOC uses `reboot_history` to answer one
    # question: "Did this router just reload, and if so, why?" The answer
    # drives escalation (hardware/power team vs. unplanned maintenance vs.
    # vendor TAC vs. no-reload-so-look-upstream). On IOS-XE SD-WAN that
    # answer lives in four lines of `show version`:
    #   <host> uptime is ...
    #   System returned to ROM by <reason>
    #   System restarted at <timestamp>
    #   Last reload reason: <reason>
    #
    # Alternations chosen as multi-word anchored phrases to avoid the
    # v27.1.26 regression where bare "System" substring-matched "Systems"
    # in Cisco Copyright lines and the bare "reload" matched other noise:
    #   `uptime is`      — only the uptime line
    #   `System restarted` — only the restart-time line
    #   `System returned`  — only the ROM-return line
    #   `Last reload`      — only the reload-reason line
    # Verified against both NOC captures: exactly 4 lines, no Copyright
    # bleed-through, no `System image file` collision. If a future
    # IOS-XE build changes the wording the role still renders the
    # friendly fallback instead of a leaked banner.
    "reboot_history":      "show version | include uptime is|System restarted|System returned|Last reload",
    # 'show vrrp detail' complements 'show vrrp brief' on the secondary
    # router — brief tells the state (MASTER/BACKUP), detail tells WHY
    # (priority, preempt, auth, timers). NOC needs detail when the state is
    # unexpected or flapping between master/backup.
    "vrrp_detail":         "show vrrp detail",
}

# v27.1.37 — classic IOS-XE AUTONOMOUS-MODE command map.
#
# WHY THIS EXISTS. Across vcdd-3 + vcdd-4 (28 prod tickets reviewed with
# Aadarsh) five devices turned out to be IOS-XE boxes that are tagged
# CEDGE in ESP inventory but running classic autonomous mode — vdaemon
# never loaded, `show sdwan X` commands are device-rejected with
# `% Invalid input detected at '^' marker.` Previously the role sent
# CEDGE_COMMANDS to these devices and 16-17 DIAG sections rendered the
# friendly "(not available - device is running classic IOS-XE autonomous
# mode)" fallback instead of real evidence. NOC asked for the full MOP
# evidence to be collected in the correct classic-IOS-XE form when the
# device is autonomous. v27.1.37 sends this map instead of
# CEDGE_COMMANDS whenever `_probe_sdwan_mode()` returns 'autonomous'
# (SD-WAN system-status probe rejected with Invalid input, device still
# answers show version with the IOS-XE banner).
#
# COMMAND SELECTION PRINCIPLE. Each entry uses commands that exist on
# virtually every modern IOS-XE universalk9 install and give NOC the
# same operational signal the SD-WAN form carried. Where no exact
# analog exists (OMP has no classic-IOS-XE equivalent), the entry
# routes to the closest classic signal (BGP summary) with a comment
# explaining the mapping decision. Pipe-filter alternations follow the
# multi-word-anchored discipline from v27.1.34 (never bare "System" or
# bare "reload") to avoid substring collisions with Copyright lines.
AUTONOMOUS_COMMANDS: Dict[str, str] = {
    # ------------------------------------------------------------------
    # Universal commands — identical to CEDGE_COMMANDS, work on both
    # SD-WAN and autonomous. Reused as-is to keep DIAG section wiring
    # stable in write_output.yaml.
    # ------------------------------------------------------------------
    "version":             "show version",
    "reboot_history":      "show version | include uptime is|System restarted|System returned|Last reload",
    "logging_last":        "show logging | last 100",
    "arp":                 "show arp",
    "ip_route":            "show ip route summary",
    "interfaces_desc":     "show interfaces description",
    "ip_int_brief":        "show ip interface brief",
    "vrrp_detail":         "show vrrp detail",
    "logging_control":     "show logging | include %",

    # ------------------------------------------------------------------
    # Classic IOS-XE analogs for SD-WAN keys. Same DIAG section header
    # as cEdge-SDWAN (write_output.yaml iterates one key list regardless
    # of platform), but the command payload is the autonomous-mode form.
    # ------------------------------------------------------------------

    # system_status: SD-WAN form is `show sdwan system status`
    # (device state banner). Classic-IOS-XE closest analog is
    # `show platform` + `show processes cpu history | section 60`.
    # NOC usage: confirm device is physically healthy and processes
    # are not pegged. The chassis/slot inventory from show platform
    # is also valuable on autonomous devices where SD-WAN health is
    # moot.
    "system_status":       "show platform",

    # control_connections: SD-WAN form is `show sdwan control
    # connections` (vSmart/vBond/vManage DTLS/TLS session state).
    # Classic autonomous has no overlay controllers — the closest
    # peer-state signal is BGP (which is what carries VPNv4 routes
    # in an MPLS L3VPN underlay) or OSPF (underlay IGP). We use
    # `show ip bgp summary` because the overwhelming majority of
    # Verizon Managed WAN autonomous devices run BGP for both PE
    # and MP-BGP peering. On a non-BGP device the command returns
    # a short "BGP not active" line, which also tells NOC
    # something useful.
    "control_connections": "show ip bgp summary",

    # control_history: SD-WAN form is control connection-history
    # (teardown/reconnect event log). Classic has no equivalent
    # history table — closest is routing-protocol state changes
    # that appear in the syslog buffer. We filter show logging for
    # the BGP/OSPF/EIGRP/BFD/LINEPROTO state lines so NOC sees any
    # recent control-plane flaps without reading the full log.
    "control_history":     "show logging | include BGP|OSPF|EIGRP|BFD-6|LINEPROTO-5",

    # control_local_props: SD-WAN form is local-properties banner
    # (system-ip + site-id + certificate state + WAN interfaces).
    # Classic analog: WAN interface list (addresses + state) via
    # show ip interface brief, filtered to administrative-up ports
    # so NOC does not read a long "Loopback / NullX / SVI" tail.
    "control_local_props": "show ip interface brief | exclude unassigned",

    # wan_interface_list: identical signal as above — IOS-XE
    # classic uses show interfaces description for operator-named
    # WAN ports. Same command as the universal entry; harmless
    # dup, keeps the DIAG section populated.
    "wan_interface_list":  "show interfaces description",

    # tunnel_statistics: SD-WAN form is overlay IPsec tunnel
    # counters. Classic analog is `show crypto session detail` for
    # DMVPN / GET-VPN / FlexVPN counters. On an autonomous device
    # with no crypto session this returns an empty line, which is
    # correctly surfaced as "no crypto sessions" rather than a
    # device-rejection.
    "tunnel_statistics":   "show crypto session detail",

    # omp_peers: SD-WAN form is `show sdwan omp peers`. OMP does
    # not exist on classic IOS-XE — closest is MP-BGP VPNv4 state.
    # Fall through to `show ip bgp vpnv4 all summary`; on a non-
    # MPLS-L3VPN device this returns one-line "VPNv4 Unicast is
    # not supported" which also tells NOC the correct answer.
    "omp_peers":           "show ip bgp vpnv4 all summary",

    # bfd_sessions: BFD exists on classic IOS-XE but requires
    # explicit config. `show bfd neighbors` returns the active
    # BFD session table if any exist; empty if BFD is not
    # configured — NOC-readable either way.
    "bfd_sessions":        "show bfd neighbors",

    # bfd_history: no classic analog; fall through to detailed
    # BFD neighbor state which carries session uptime and recent
    # transitions.
    "bfd_history":         "show bfd neighbors details",

    # Certificate commands: classic IOS-XE uses the PKI subsystem,
    # not the SD-WAN cert store. Same intent — identity + validity
    # — different command tree. Pipe-filter alternations use the
    # OpenSSL text-dump wording that `show crypto pki certificates`
    # emits (Issuer, Subject, Validity, Not Before, Not After).
    "cert_status":         "show crypto pki certificates | include Issuer:|Subject:|Validity|Not Before|Not After",
    "cert_validity":       "show crypto pki certificates | include Issuer:|Subject:|Validity|Not Before|Not After",
    "cert_installed":      "show crypto pki certificates",
}

VEDGE_COMMANDS: Dict[str, str] = {
    "system_status":       "show system status",
    "version":             "show version",
    "control_connections": "show control connections",
    "control_history":     "show control connections-history",
    "control_local_props": "show control local-properties",
    "wan_interface_list":  "show control local-properties wan-interface-list",
    "tunnel_statistics":   "show tunnel statistics",
    "omp_peers":           "show omp peers",
    "bfd_sessions":        "show bfd sessions",
    "cert_validity":       "show certificate validity",
    "cert_installed":      "show certificate installed",
    # v27.1.27 FIX (SIT build 1115 on deapega-test13-4359577e001 Viptela OS
    # 20.3.8): `show certificate status` does NOT exist on vEdge — the
    # device replies with a help listing of valid subcommands which is
    # >500 chars and so bypasses `_looks_like_device_error`'s length
    # guard, leaking a "syntax error: expecting ..." block into the
    # DIAG --- cert_status --- section on every vEdge ticket. The MOP
    # intent of cert_status is cert health (validity + install status),
    # which on Viptela OS is reported by `show certificate validity`.
    # v27.1.34: cEdge was ALSO switched to the validity form (same
    # pattern, same reason — see CEDGE_COMMANDS["cert_status"] comment).
    "cert_status":         "show certificate validity",
    # v27.1.17 GAP-B fix: vEdge equivalent of show sdwan bfd history.
    "bfd_history":         "show bfd history",
    "interfaces_desc":     "show interface description | tab",
    "reboot_history":      "show reboot history",
    # v27.1.11 (SIT-confirmed on deapega-vedge-cpe4): Viptela OS CLI
    # pipe filters do NOT include `tail`. The valid filters are:
    # begin | best-effort | count | de-select | display | exclude |
    # include | linnum | match-all | match-any | more | nomore |
    # notab | repeat | save | select | sort-by | tab | until. We use
    # `| nomore` to suppress pagination (vEdge equivalent of cEdge's
    # `terminal length 0`). The config banner at the top of `show log`
    # is ~6 lines of noise but is automatically skipped by
    # logging_filter_window (lines without a syslog timestamp are
    # dropped by the filter's _parse_log_ts gate).
    "logging_last":        "show log | nomore",
    "arp_vpn0":            "show arp vpn 0",
    "ip_routes_vpn0":      "show ip routes vpn 0",
    "vrrp_detail":         "show vrrp detail",
}

# vrf: 'show vrf' is IOS-XE only; vEdge uses 'show ip vpn' (skipped here).
# standby (HSRP) is IOS-XE only; skipped on vEdge.
SECONDARY_COMMANDS: Dict[str, Dict[str, Optional[str]]] = {
    "interfaces_desc":     {"cedge": "show interfaces description",                              "vedge": "show interface description | tab"},
    "wan_interface_list":  {"cedge": "show sdwan control local-properties wan-interface-list",   "vedge": "show control local-properties wan-interface-list"},
    "control_connections": {"cedge": "show sdwan control connections",                           "vedge": "show control connections"},
    "control_local_props": {"cedge": "show sdwan control local-properties",                      "vedge": "show control local-properties"},
    "bfd_sessions":        {"cedge": "show sdwan bfd sessions",                                  "vedge": "show bfd sessions"},
    "vrrp":                {"cedge": "show vrrp brief",                                          "vedge": "show vrrp"},
    "vrrp_detail":         {"cedge": "show vrrp detail",                                         "vedge": "show vrrp detail"},
    "standby":             {"cedge": "show standby brief",                                       "vedge": None},
    "vrf":                 {"cedge": "show vrf",                                                 "vedge": None},
    # v27.1.40 F5: MOP evidence from secondary logs (parallels legacy
    # Cisco-Router-Device-Down task 1253 dying-gasp check + task 1262M
    # secondary-side MOP probe fields). On a true hard-down of the primary,
    # the secondary's syslog typically carries a "DYING-GASP" line from the
    # primary and a reload line. Collecting from the secondary (always
    # reachable) rather than the primary (unreachable) is MOP c2.
    "dying_gasp_log":      {"cedge": "show logging | include [Dd]ying",                          "vedge": "show log | include [Dd]ying"},
    "reload_log":          {"cedge": "show logging | include reload",                            "vedge": "show log | include reload"},
}


class ViptelaSSH:
    """Paramiko-based SSH session handler for Viptela network devices."""

    _RECV_CHUNK          = 65535
    _MAX_OUTPUT_BYTES    = 4_000_000    # large enough for control-conn histories
    _MAX_COMMAND_SECONDS = 120.0
    _KEEPALIVE_SECONDS   = 30
    # Prompt-based read (mirrors BGP-Router-Up-Down-Viptela v3.11):
    _PROMPT_SILENCE_SECONDS = 20.0  # silence after real output, no prompt yet
    _PROMPT_WAIT_SECONDS    = 45.0  # nothing but the echo received
    _PROMPT_MAX_MISSES      = 2     # then fall back to idle-wait reads

    def __init__(self, host: str, username: str, password: str,
                 port: int = 22, timeout: int = 30,
                 known_hosts_path: Optional[str] = None,
                 allow_unknown_hosts: bool = False) -> None:
        self.host                 = host
        self.username             = username
        self.password             = password
        self.port                 = port
        self.timeout              = max(1, int(timeout))
        self.known_hosts_path     = known_hosts_path
        self.allow_unknown_hosts  = allow_unknown_hosts
        self._client:    Optional[paramiko.SSHClient] = None
        self._channel:   Optional[paramiko.Channel]   = None
        self._transport: Optional[paramiko.Transport] = None
        # Prompt-mode state. Env override lets ops roll back to legacy idle
        # reads without a code change: VIPTELA_SSH_READ_MODE=idle.
        self.read_mode = (os.environ.get("VIPTELA_SSH_READ_MODE", "prompt")
                          or "prompt").strip().lower()
        self._prompt_re: Optional["re.Pattern"] = None
        self._prompt_misses = 0
        self.timings: Dict[str, dict] = {}

    def connect(self) -> None:
        """Establish SSH connection and open interactive shell.

        Prefers a known_hosts file; falls back to accepting new host keys
        only when explicitly permitted (e.g. lab / first-run bootstrap).
        """
        self._client = paramiko.SSHClient()
        if self.known_hosts_path and os.path.exists(self.known_hosts_path):
            try:
                self._client.load_host_keys(self.known_hosts_path)
            except (OSError, paramiko.SSHException):
                pass
        if self.allow_unknown_hosts:
            self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        else:
            self._client.set_missing_host_key_policy(paramiko.RejectPolicy())

        try:
            self._client.connect(
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                timeout=self.timeout,
                auth_timeout=self.timeout,
                look_for_keys=False,
                allow_agent=False,
                banner_timeout=30,
            )
        except paramiko.AuthenticationException:
            # Some Viptela builds advertise keyboard-interactive only. Build
            # a fresh transport we own and close on failure. Enforce host-key
            # verification here too — a keyboard-interactive fallback must
            # not bypass the same policy the initial connect would apply.
            transport = paramiko.Transport((self.host, self.port))
            transport.banner_timeout = 30
            try:
                transport.start_client(timeout=self.timeout)
                # Host-key check that mirrors RejectPolicy/known_hosts.
                if not self.allow_unknown_hosts:
                    remote_key = transport.get_remote_server_key()
                    host_keys = self._client.get_host_keys()
                    known = host_keys.lookup(self.host) or {}
                    stored = known.get(remote_key.get_name())
                    if stored is None or stored.asbytes() != remote_key.asbytes():
                        raise paramiko.SSHException(
                            f"Server '{self.host}' host key not in known_hosts "
                            "(keyboard-interactive fallback)")
                try:
                    transport.auth_interactive(
                        self.username,
                        lambda title, instr, prompts: [self.password] * len(prompts),
                    )
                except paramiko.SSHException as exc:
                    # Re-raise as AuthenticationException so main() reports
                    # AuthenticationFailed rather than an opaque SSHException.
                    raise paramiko.AuthenticationException(str(exc)) from exc
            except (paramiko.SSHException, OSError):
                try:
                    transport.close()
                except (paramiko.SSHException, OSError):
                    pass
                raise
            self._transport = transport
            # SSHClient expects an authenticated transport; wire ours in.
            # Uses the documented pattern; if a future paramiko renames the
            # private attribute this will need updating.
            self._client._transport = transport  # noqa: SLF001

        # Keepalive so long collections do not stall on middlebox idle timers
        try:
            t = self._client.get_transport()
            if t is not None:
                t.set_keepalive(self._KEEPALIVE_SECONDS)
        except Exception:
            pass

        self._channel = self._client.invoke_shell(width=250, height=200)
        time.sleep(1.0)
        self._drain()
        self._disable_paging()
        time.sleep(1.5)
        self._drain()
        self._learn_prompt()

    def _learn_prompt(self) -> None:
        """Learn the exec prompt once ('HOST#' or 'host> '). Config prompts
        ('HOST(config)#') match the same compiled pattern. Prompt-mode is
        disabled silently when no match is found."""
        if self._channel is None or self.read_mode == "idle":
            return
        try:
            self._channel.sendall(b"\n")
        except (paramiko.SSHException, OSError):
            return
        time.sleep(0.8)
        text = self._drain()
        lines = [ln.strip() for ln in text.replace("\r", "\n").split("\n")
                 if ln.strip()]
        if not lines:
            return
        m = re.match(r"^([A-Za-z0-9][A-Za-z0-9_.:/@-]*?)(\([^)]*\))?\s*([#>])$",
                     lines[-1])
        if m:
            self._prompt_re = re.compile(
                r"^" + re.escape(m.group(1)) + r"(\([^)]*\))?\s*[#>]$")

    def _prompt_mode(self) -> bool:
        """Return True when prompt-based reads are active for the next send."""
        return (self.read_mode != "idle"
                and self._prompt_re is not None
                and self._prompt_misses < self._PROMPT_MAX_MISSES)

    def _ends_with_prompt(self, output: bytes) -> bool:
        """Return True when the last non-empty line matches the learned prompt."""
        if self._prompt_re is None or not output:
            return False
        tail = output[-300:].decode("utf-8", errors="replace").replace("\r", "\n")
        last = tail.split("\n")[-1].strip()
        return bool(last) and self._prompt_re.match(last) is not None

    @staticmethod
    def _has_body(output: bytes, command: str) -> bool:
        """Return True when the buffer carries at least one body line beyond
        the echoed command."""
        text = output.decode("utf-8", errors="replace").replace("\r", "\n")
        lines = [ln.strip() for ln in text.split("\n") if ln.strip()]
        if lines and lines[0].endswith(command.strip()):
            lines = lines[1:]
        return bool(lines)

    def _quick_drain(self) -> str:
        """Short BLOCKING drain of residual bytes before sending next command.

        v27.1.28 EVIDENCE-BASED RE-ADD: ticket evidence (aecom-london build
        14716, nykbus-phulycity builds 14732/14733) shows the pure non-
        blocking form from v27.1.26 fails on fast short-output cEdge
        commands. Both tickets reproducibly dropped `omp_peers` and
        `cert_status` (and sometimes `control_local_props`, `control_history`,
        `bfd_history`) — all of which share one property: very short device
        reply (<1KB) that returns quickly. The race:
          1. prior command (e.g. version) finishes, prompt returns
          2. send_command for omp_peers calls non-blocking _quick_drain
          3. drain returns immediately with 0 bytes (prior output already
             drained by the previous send_command's read loop)
          4. "show sdwan omp peers\\n" sent
          5. device replies within ~50ms with the short body
          6. BUT prior command's trailing "% Invalid input" from the
             paginate false attempt in _disable_paging had been held in a
             TCP buffer and now lands FIRST in the recv stream
          7. _clean_output sees "% Invalid input..." before the echo and
             strips it; clean_cli_dict then drops the capture because
             it starts with an error token
          8. DIAG renders fallback "(no output - command rejected)"
        Giving the drain a 300ms blocking window with inter-chunk extension
        catches the residual bytes before the next command goes out. Oct-9
        wawai did not manifest this because its SSH turnaround was slower
        (the race only surfaces on sub-100ms-reply cEdges). ~8s overhead
        per 26-command run is acceptable; losing 3-5 DIAG sections per
        ticket is not."""
        out = b""
        end = time.time() + 0.3
        try:
            while time.time() < end:
                if self._channel is not None and self._channel.recv_ready():
                    chunk = self._channel.recv(self._RECV_CHUNK)
                    if not chunk:
                        break
                    out += chunk
                    # Extend the window briefly while bytes keep arriving so
                    # a mid-flush does not get split across commands.
                    end = max(end, time.time() + 0.1)
                else:
                    time.sleep(0.05)
        except (paramiko.SSHException, OSError):
            pass
        return out.decode("utf-8", errors="replace")

    def _drain(self) -> str:
        """Drain buffered output from channel, extending the deadline while
        bytes keep arriving. Returns the drained text (may be empty)."""
        if self._channel is None:
            return ""
        output = b""
        deadline = time.time() + 3.0
        try:
            while time.time() < deadline:
                if self._channel.recv_ready():
                    chunk = self._channel.recv(self._RECV_CHUNK)
                    if not chunk:
                        break
                    output += chunk
                    deadline = time.time() + 0.5
                else:
                    time.sleep(0.1)
        except (paramiko.SSHException, OSError):
            return output.decode("utf-8", errors="replace")
        return output.decode("utf-8", errors="replace")

    def _disable_paging(self) -> None:
        """Turn off terminal paging — platform-aware probe pattern.

        v27.1.29 ROOT-CAUSE FIX for the fast-cEdge DIAG regression seen on
        aecom-london-dc1-23860719 (build 14716) and NYKBUS-VNYLKHNM2-C
        (builds 14732/14733). The prior "send all three" form fired:

            terminal length 0     <- cEdge accepts, no error
            paginate false        <- cEdge errors: "% Invalid input ..."
                                     followed by a >500 char help listing
            screen-length 0       <- cEdge errors: same help listing

        On fast cEdges (c8000be, vISR 17.12 — ~50ms SSH turnaround) the
        trailing "% Invalid input" + help lines from the two rejected
        commands were still arriving when the first real command was
        sent, bleeding into its recv stream. _clean_output then treated
        the residual as the command's data; clean_cli_dict's
        _looks_like_device_error dropped the capture; DIAG rendered
        "(no output - command rejected)". v27.1.28 patched the symptom
        with a 300ms blocking _quick_drain and an echo-position scan in
        _clean_output. v27.1.29 removes the SOURCE of the residual: the
        two commands that error on cEdge are no longer sent on cEdge.

        Probe pattern:
          1. Send `terminal length 0`. Drain. If no error marker in the
             drain text → this is IOS-XE (cEdge or classic autonomous).
             Stop. No further paging commands.
          2. If the drain text carries an error marker (`% Invalid`,
             `syntax error`, `Unknown command`), this is vEdge
             (Viptela OS). Send `paginate false`. Drain.

        v27.1.28's _quick_drain blocking + _clean_output echo scan are
        retained as defense-in-depth: even if a future platform surprises
        us and both commands error, their residual still gets caught.

        Oct-9 parity note: Oct-9 (v27.1) sent all three commands too
        with identical timing. The race it hid never manifested on
        wawai because wawai's SSH turnaround was slower (~200ms). Faster
        cEdges in prod today need this fix."""
        if self._channel is None:
            return
        # Shared error marker — any of these on the drain text means the
        # device rejected the command.
        error_markers = ("% Invalid", "% invalid", "syntax error",
                         "Unknown command", "% Unknown")

        # Step 1: `terminal length 0` — the universal IOS-XE form.
        try:
            self._channel.sendall(b"terminal length 0\n")
            time.sleep(0.4)
            drain_text = self._drain()
        except (paramiko.SSHException, OSError):
            logger.debug("terminal length 0 send failed on %s", self.host)
            return

        if not any(marker in drain_text for marker in error_markers):
            # IOS-XE accepted it. We're on cEdge or classic autonomous.
            # No further commands needed; no residual to flush.
            return

        # Step 2: vEdge path. `paginate false` is the Viptela OS form.
        try:
            self._channel.sendall(b"paginate false\n")
            time.sleep(0.4)
            self._drain()
        except (paramiko.SSHException, OSError):
            logger.debug("paginate false send failed on %s", self.host)

    def send_command(self, command: str, idle_wait: float = 2.0,
                     wait_for_prompt: bool = True) -> str:
        # v27.1.26: reverted idle_wait default from 3.0 back to 2.0 to match
        # the Oct-9 baseline. v27.1.25 had bumped it under the mistaken
        # belief that the Oct-9 code used 3.0. The Oct-9 source audit
        # confirmed Oct-9 ran with idle_wait=2.0 against wawai and worked.
        # Prompt-mode is the primary terminator; idle_wait is only the
        # fallback for the few devices where prompt-regex learning misses.
        """Send command; read until device prompt returns (prompt mode) or
        until the channel is idle for `idle_wait` (fallback, or when
        wait_for_prompt=False — e.g. the two-hop probe that ends at a REMOTE
        'Password:' prompt rather than ours)."""
        if self._channel is None:
            raise RuntimeError("channel not open")

        # Drain any residual bytes so late output from the prior command
        # cannot be mis-filed under this one.
        self._quick_drain()
        use_prompt = wait_for_prompt and self._prompt_mode()

        # sendall so a short write does not truncate the command mid-string
        self._channel.sendall((command + "\n").encode("utf-8"))
        time.sleep(0.3)

        output      = b""
        last_recv   = time.time()
        started     = time.time()
        truncated   = False
        prompt_seen = False

        while True:
            try:
                if self._channel.recv_ready():
                    chunk = self._channel.recv(self._RECV_CHUNK)
                    if not chunk:
                        break
                    output   += chunk
                    last_recv = time.time()
                    # Handle --More-- paging if `terminal length 0` didn't
                    # take effect. v27.1.9 fix: send SPACE (continue to
                    # next page) instead of `q` (quit immediately). Prior
                    # behavior truncated `show logging last 30` and
                    # similar to just the config banner — the actual log
                    # messages come AFTER the first --More-- break, so
                    # sending `q` discarded exactly what NOC needed to
                    # see. SPACE keeps advancing the pager until the
                    # device prompt returns naturally.
                    tail = output[-32:].lower()
                    if b"--more--" in tail:
                        try:
                            self._channel.sendall(b" ")
                        except (paramiko.SSHException, OSError):
                            pass
                    if len(output) >= self._MAX_OUTPUT_BYTES:
                        truncated = True
                        logger.warning("Output cap hit for %r on %s", command, self.host)
                        break
                    if use_prompt and self._ends_with_prompt(output):
                        prompt_seen = True
                        break
                    continue
                now = time.time()
                if now - started > self._MAX_COMMAND_SECONDS:
                    truncated = True
                    logger.warning("Command %r exceeded %.0fs on %s",
                                   command, self._MAX_COMMAND_SECONDS, self.host)
                    break
                if use_prompt:
                    # In prompt mode we tolerate long inter-chunk silences
                    # as long as some body has arrived; terminate only after
                    # _PROMPT_SILENCE_SECONDS of post-body silence, or
                    # _PROMPT_WAIT_SECONDS when nothing but the echo arrived.
                    if self._has_body(output, command):
                        if now - last_recv > self._PROMPT_SILENCE_SECONDS:
                            break
                    elif now - started > self._PROMPT_WAIT_SECONDS:
                        break
                elif now - last_recv > idle_wait:
                    break
                time.sleep(0.05)
            except (paramiko.SSHException, OSError) as exc:
                logger.warning("recv failed on %s: %s", self.host, exc)
                break

        if use_prompt and not prompt_seen and not truncated:
            self._prompt_misses += 1
        self.timings[command] = {"s": round(time.time() - started, 1),
                                 "prompt": prompt_seen}
        cleaned = self._clean_output(output.decode("utf-8", errors="replace"),
                                     command)
        if truncated:
            cleaned += "\n... (output truncated by collection limits) [TRUNCATED]"
        return cleaned

    def _clean_output(self, raw: str, command: str) -> str:
        """Strip command echo, trailing prompt, AND pre-echo residual noise.

        v27.1.28 HARDENING (defense-in-depth with _quick_drain's 300ms
        blocking window). Scan the first 12 non-empty lines looking for the
        command echo. Everything BEFORE the echo is residual output that
        bled over from the prior command (an "% Invalid input" line from a
        paginate false attempt, a short banner echo, a residual prompt
        pop) and must be discarded, not treated as this command's data.
        If the echo is not found within 12 lines, fall back to the previous
        behavior (first non-empty line is data) — some pager-wrapped
        commands can genuinely echo past that point.
        """
        lines     = raw.splitlines()
        cleaned   = []
        cmd_full  = command.strip()

        # Find echo position within the first 12 non-empty lines.
        echo_idx = None
        seen = 0
        for i, line in enumerate(lines):
            if not line.strip():
                continue
            seen += 1
            if line.rstrip().endswith(cmd_full) or cmd_full in line.rstrip():
                echo_idx = i
                break
            if seen >= 12:
                break

        if echo_idx is not None:
            # Discard EVERYTHING at and before the echo line (pre-echo
            # residual + the echo itself). Lines after echo are this
            # command's output.
            cleaned = list(lines[echo_idx + 1:])
        else:
            # Fallback: old behavior — scan line-by-line, first non-empty
            # treated as data if it doesn't end with cmd_full.
            echo_seen = False
            for line in lines:
                if not echo_seen and line.strip():
                    if line.rstrip().endswith(cmd_full):
                        echo_seen = True
                        continue
                    echo_seen = True
                    cleaned.append(line)
                    continue
                cleaned.append(line)

        # Trailing prompt is a bare "hostname[#>$]" — data lines that end in
        # '#', '>', or '$' but carry other content are preserved.
        while cleaned:
            last = cleaned[-1].rstrip()
            if last and re.match(r"\S+[#>$]\s*$", last):
                cleaned.pop()
            else:
                break

        return "\n".join(cleaned)

    # v27.1.32: Viptela OS error syntax markers. These phrases are
    # EXCLUSIVELY emitted by Viptela OS (vEdge) when a CLI parser rejects
    # a command. IOS-XE uses `% Invalid input detected at '^' marker.` —
    # a completely different error form. If any probe returns one of
    # these strings, the device is a vEdge, full stop.
    _VEDGE_ERROR_MARKERS = (
        "syntax error: missing display group",
        "syntax error: incomplete path",
        "syntax error: unknown argument",
        "syntax error: element does not exist",
        "syntax error: expecting",       # vEdge "syntax error: expecting <alternatives>"
    )

    @classmethod
    def _looks_like_vedge_error(cls, text):
        """True if any Viptela OS parser-rejection marker appears in text."""
        if not text:
            return False
        low = text.lower()
        return any(m in low for m in cls._VEDGE_ERROR_MARKERS)

    def detect_platform(self) -> str:
        """Auto-detect device platform by probing system status and version.

        v27.1.32 FIX for the 53bank-type mistag (Jenkins build 14968 on
        53bank-RB046418A1-23280015e001): the ESP inventory tagged a
        Viptela OS vEdge 20.9.7 device as CEDGE. The role sent
        `show sdwan X` commands which Viptela OS rejects with its own
        error syntax (`syntax error: missing display group`, NOT the
        IOS-XE `% Invalid input detected at '^' marker.`). The old
        heuristic missed this and classified the device as cedge.
        v27.1.32 adds two decisive vedge signals, in order:

          (a) Viptela OS error syntax in ANY probe response → vedge.
              `syntax error: <...>` is exclusively vEdge CLI; IOS-XE
              never emits that wording.
          (b) Bare semver version string in the 18.X–22.X range
              (`^\\d+\\.\\d+\\.\\d+(\\.\\d+)?$` after strip) with no
              IOS-XE markers → vedge. 53bank returned `20.9.7` alone.

        Both signals override the generic length / role / banner checks
        below.
        """
        combined = ""
        version_probe = ""

        # Probe 1: show version (works on both platforms; contains XE marker)
        try:
            output = self.send_command("show version", idle_wait=3.0)
            if not self._is_invalid_command(output.lower()):
                combined += output + "\n"
                version_probe = output
                low = output.lower()
                if "cisco ios xe" in low or "controller-managed" in low:
                    return "cedge"
            # v27.1.32 (a): a Viptela error in the show-version response
            # (unusual but possible) is itself a vedge indicator.
            if self._looks_like_vedge_error(output):
                return "vedge"
        except Exception as exc:
            logger.debug("show version probe failed on %s: %s", self.host, exc)

        # Probe 2: show sdwan system status (cEdge-specific)
        try:
            output = self.send_command("show sdwan system status", idle_wait=3.0)
            # v27.1.32 (a): vEdge rejects `show sdwan ...` with
            # Viptela-syntax errors. If we see that, the device is
            # a vEdge regardless of what inventory tags it as.
            if self._looks_like_vedge_error(output):
                return "vedge"
            if not self._is_invalid_command(output.lower()):
                combined += output + "\n"
                low = output.lower()
                if re.search(r"device role\s*:\s*(cedge|sdwan\s+edge)", low):
                    return "cedge"
                if "cedge-sdwan" in low:
                    return "cedge"
        except Exception as exc:
            logger.debug("show sdwan system status probe failed on %s: %s", self.host, exc)

        # Probe 3: show system status (vEdge)
        try:
            output = self.send_command("show system status", idle_wait=3.0)
            if not self._is_invalid_command(output.lower()):
                combined += output + "\n"
        except Exception as exc:
            logger.debug("show system status probe failed on %s: %s", self.host, exc)

        lower = combined.lower()
        if not lower.strip():
            logger.warning("Platform could not be determined on %s", self.host)
            return ""

        # v27.1.32 (b): bare Viptela OS semver (18.X–22.X) is decisive
        # before the IOS-XE keyword scan. 53bank's show version
        # returned exactly "20.9.7" with no accompanying banner.
        version_bare = (version_probe or "").strip()
        if re.match(r"^(18|19|20|21|22)\.\d+\.\d+(\.\d+)?$", version_bare):
            return "vedge"

        # Definitive IOS-XE markers
        if "controller-managed" in lower:
            return "cedge"
        if "cisco ios xe" in lower or "ios-xe" in lower:
            return "cedge"

        # Model-based detection with word boundaries so 'asr'/'isr' don't
        # match banner substrings like 'traceroute' or 'phrase'.
        if re.search(r"\b(csr1000v|csr\d+|c8[0-9]{3}|isr\d+|asr\d+|c11\d{2})\b", lower):
            return "cedge"

        # Role markers MUST be checked before the generic 'viptela'/'vedge'
        # fallback: a cEdge's 'show sdwan system status' banner starts with
        # 'Viptela (tm) vEdge Operating System Software' and a CSR1000v in
        # SD-WAN mode carries device-model 'vedge-CSR-1000v' (SIT: cpe5).
        # Without this ordering, those cEdges fall through to the vedge rule.
        if (re.search(r"device role\s*:\s*(cedge|sdwan\s+edge)", lower)
                or "cedge-sdwan" in lower):
            return "cedge"

        if re.search(r"\bmodel\s*:\s*vedge\b", lower) or "viptela" in lower:
            return "vedge"

        # Weighted fallback with anchored version tokens
        cs = len(re.findall(r"\b17\.\d|\b16\.\d|\bxe software\b|\bsdwan-enabled\b", lower))
        vs = len(re.findall(r"\b18\.\d|\b19\.\d|\b20\.\d|\b21\.\d|\b22\.\d", lower))
        if cs == 0 and vs == 0:
            return ""  # unknown — caller escalates
        return "cedge" if cs > vs else "vedge"

    @staticmethod
    def _is_invalid_command(lower_output: str) -> bool:
        """Detect a rejected command so it is not mistaken for real output."""
        markers = ("invalid input", "% invalid", "syntax error", "unknown command",
                   "% unrecognized", "incomplete command", "% ambiguous",
                   "command not found")
        return any(m in lower_output for m in markers)

    # v27.1.37 — cEdge SD-WAN vs classic IOS-XE autonomous sub-mode probe.
    #
    # Context. detect_platform() returns 'cedge' when the device's `show
    # version` banner carries the "Cisco IOS XE" string. That banner is
    # present on BOTH SD-WAN-mode cEdges (vdaemon loaded, `show sdwan X`
    # works) AND classic autonomous cEdges where the operator never
    # bootstrapped SD-WAN (vdaemon not loaded, `show sdwan X` rejected
    # with `% Invalid input`). vcdd-3 + vcdd-4 (28 prod tickets)
    # surfaced 5 of these — wawai-s08045, grhampkg-mexicali,
    # unitedbank-kernstown, lear-zaeascrp01, fcaus-rtrpitcev — all
    # tagged CEDGE in ESP but all running classic IOS-XE autonomous.
    # Sending CEDGE_COMMANDS to them produces 17 "(not available)"
    # DIAG sections and zero real evidence.
    #
    # This method separates the two sub-modes with ONE extra SSH
    # round-trip, called from run_primary() right after detect_platform()
    # returns 'cedge':
    #   - Send `show sdwan system status`.
    #   - If output carries the Viptela banner markers (Version:, System
    #     state, vmanaged:, Controller Compatibility, Personality) ->
    #     'sdwan' -> caller uses CEDGE_COMMANDS.
    #   - If output carries any invalid-command marker (% Invalid /
    #     Incomplete / Unknown command) -> 'autonomous' -> caller uses
    #     AUTONOMOUS_COMMANDS.
    #   - Any other case (connection error, surprise output) ->
    #     'unknown' -> caller falls back to CEDGE_COMMANDS and the
    #     existing late-detect vedge-mistag path.
    #
    # One extra round-trip per cEdge ticket is the correct trade-off:
    # it saves 16+ wrong commands and gives NOC a real DIAG on the five
    # devices (and any similar ones in the future) instead of a wall of
    # friendly "(not available)" fallbacks.
    def _probe_sdwan_mode(self) -> str:
        """Return 'sdwan' | 'autonomous' for a cEdge device.

        v27.1.38 — MULTI-SIGNAL DETECTION. The previous v27.1.37
        version trusted a single command (`show sdwan system status`)
        and classified the device as "autonomous" the moment that one
        command returned `% Invalid input`. That proved unreliable:
        build 15513 raw CLI capture (wawai-S08045-vISR-23429527,
        2026-10-24) showed `show sdwan system status` rejected with
        `% Invalid input` even though:
          * `show version` carried `Router operating mode: Controller-
            Managed` and `Technology Package License Information:
            Controller-managed`
          * `show ip interface brief` carried Sdwan-intf, Sdwan-system-
            intf, and vmanage_system interfaces UP
          * NOC's follow-up `show sdwan ?` returned the full
            SD-WAN subcommand tree (alarms, bfd, certificate, control,
            omp, system, tunnel, ...)
        That device is 100% SD-WAN controller-managed. The single-
        command probe produced a false "autonomous" classification.

        v27.1.38 fix: FOUR signals probed in authority order, with
        slow-daemon tolerance (vdaemon-backed commands on loaded
        cEdges can take 4-6 sec to answer; idle_wait raised from 3 s
        to 6 s and 1 retry with 2 s backoff added for the SD-WAN
        version probe). SD-WAN by DEFAULT (95%+ of fleet). Only
        returns 'autonomous' when ALL four signals converge on
        no-SD-WAN.

        Signal 1 (authoritative, cheapest):
            `show version | include operating mode|Controller-Managed`
            If output contains "Controller-Managed" (any case) OR
            "operating mode: controller" → return 'sdwan' immediately.
            This single line is set by IOS-XE SD-WAN image at boot
            and is present on every controller-managed cEdge
            regardless of vdaemon runtime state.

        Signal 2 (authoritative):
            `show ip interface brief` filtered to the SD-WAN system
            interfaces (Sdwan-intf, Sdwan-system-intf, vmanage_system).
            Presence of these interfaces means vdaemon is loaded and
            has created its control-plane interfaces. If any match
            → return 'sdwan' immediately.

        Signal 3 (strong, light probe with retry):
            `show sdwan version`
            Shorter sub-command than system-status. If vdaemon is
            marginally responsive (slow but not crashed), this often
            answers when `show sdwan system status` times out or
            errors. Retried once after 2 s backoff for transient
            vdaemon lag. Non-rejection = sdwan.

        Signal 4 (original, now with longer timeout):
            `show sdwan system status` with idle_wait=6 s.
            Viptela banner markers in output → 'sdwan'.

        Final rule:
            If ALL four signals negative (version has no Controller-
            Managed, no sdwan interfaces, show sdwan version
            rejected, show sdwan system status rejected) → return
            'autonomous'. Otherwise → return 'sdwan' (SD-WAN by
            default — matches the 95% field reality).
        """
        logger.debug("sdwan-mode probe starting on %s", self.host)
        # Review-pass-2 hardening: track how many probes actually
        # returned a response (vs raising SSH exceptions). If zero
        # signals responded (session broken mid-probe), we fall back
        # to the SD-WAN default rather than returning autonomous —
        # a broken SSH session is not proof of autonomous mode.
        responded = 0
        # Also track whether any signal gave a positive REJECT (device
        # CLI parser said the command does not exist). A positive
        # rejection is stronger evidence of autonomous than silence.
        rejected_signals = 0

        # Signal 1: `show version | include ...` — authoritative
        try:
            v = self.send_command(
                "show version | include operating mode|Controller-Managed",
                idle_wait=4.0)
            responded += 1
            v_low = v.lower()
            if ("controller-managed" in v_low
                    or "operating mode: controller" in v_low):
                logger.info("%s: SD-WAN confirmed via show-version "
                            "Controller-Managed banner", self.host)
                return "sdwan"
        except (paramiko.SSHException, OSError) as exc:
            logger.debug("Signal 1 (show version include) failed on %s: %s",
                         self.host, exc)

        # Signal 2: SD-WAN system interfaces present
        try:
            intf = self.send_command(
                "show ip interface brief | include Sdwan|vmanage",
                idle_wait=4.0)
            responded += 1
            intf_low = intf.lower()
            if ("sdwan-intf" in intf_low
                    or "sdwan-system-intf" in intf_low
                    or "vmanage_system" in intf_low):
                logger.info("%s: SD-WAN confirmed via Sdwan-intf / "
                            "vmanage_system interface presence", self.host)
                return "sdwan"
        except (paramiko.SSHException, OSError) as exc:
            logger.debug("Signal 2 (show ip int brief include) failed on %s: %s",
                         self.host, exc)

        # Signal 3: `show sdwan version` with retry
        for attempt in (1, 2):
            try:
                sv = self.send_command("show sdwan version", idle_wait=6.0)
                responded += 1
                sv_low = sv.lower()
                if not self._is_invalid_command(sv_low):
                    # Any non-rejection + non-empty response means vdaemon
                    # answered. Even a bare version string suffices.
                    stripped = sv.strip()
                    if stripped and re.search(r"\d+\.\d+\.\d+", stripped):
                        logger.info("%s: SD-WAN confirmed via show sdwan "
                                    "version (attempt %d)", self.host, attempt)
                        return "sdwan"
                    # Non-rejection with empty content is unusual; try again
                else:
                    rejected_signals += 1
                    # Explicitly rejected — no point retrying
                    break
            except (paramiko.SSHException, OSError) as exc:
                logger.debug("Signal 3 (show sdwan version) attempt %d failed on %s: %s",
                             attempt, self.host, exc)
            if attempt == 1:
                time.sleep(2.0)

        # Signal 4: `show sdwan system status` — original probe,
        # longer idle_wait for slow vdaemon
        try:
            ss = self.send_command("show sdwan system status", idle_wait=6.0)
            responded += 1
            ss_low = ss.lower()
            if self._is_invalid_command(ss_low):
                rejected_signals += 1
            else:
                sdwan_markers = (
                    "system state", "controller compatibility",
                    "vmanaged:", "personality:", "version:",
                )
                if any(m in ss_low for m in sdwan_markers):
                    logger.info("%s: SD-WAN confirmed via "
                                "show sdwan system status banner", self.host)
                    return "sdwan"
            # Rejected OR non-banner response — Signal 4 negative
        except (paramiko.SSHException, OSError) as exc:
            logger.debug("Signal 4 (show sdwan system status) failed on %s: %s",
                         self.host, exc)

        # End of probe. Decide classification:
        #   responded == 0  → SSH session is broken; cannot determine.
        #                     Fall back to the SD-WAN default (safer:
        #                     95%+ of fleet is SD-WAN, and later
        #                     late-detect vedge-mistag recovery still
        #                     covers the rare off-case).
        #   responded >= 1 AND rejected_signals >= 1 → device CLI
        #                     actively rejected a show-sdwan command,
        #                     AND no SD-WAN signal (banner,
        #                     interfaces, version) was found. This is
        #                     genuine classic IOS-XE autonomous.
        #   responded >= 1 AND rejected_signals == 0 → device answered
        #                     but no SD-WAN markers matched and no
        #                     explicit rejection either (unusual).
        #                     Default to SD-WAN rather than
        #                     autonomous — matches the 95% field
        #                     assumption and avoids a false autonomous
        #                     flip on a weird-output edge case.
        if responded == 0:
            logger.warning("%s: all SD-WAN probes raised exceptions "
                           "(SSH session may be broken) — defaulting to "
                           "'sdwan' classification", self.host)
            return "sdwan"
        if rejected_signals >= 1:
            logger.warning("%s: %d SD-WAN probe(s) rejected by device CLI "
                           "AND no positive SD-WAN signal across %d probe(s) "
                           "that responded — classifying as classic IOS-XE "
                           "autonomous", self.host, rejected_signals, responded)
            return "autonomous"
        logger.info("%s: SD-WAN probes responded but no positive marker "
                    "matched and no rejection either — defaulting to "
                    "'sdwan' (95% field assumption)", self.host)
        return "sdwan"

    def _section_boundary_reset(self) -> None:
        """v27.1.40 F1+F2: hard reset the SSH recv buffer between sections.

        Target: the konecr-tianjin build 16500 pattern (IOS-XE 17.12.08)
        where 8-10 `show sdwan X` sections rejected with caret positions
        1-21 chars PAST the end of the command. Pattern repeated across
        konecr-addison (16458), suggesting residual bytes from the
        previous section's output tail (pager state, delayed prompt echo,
        or ANSI reset) being prepended to the next command's write.

        v27.1.29's `_disable_paging()` already fixes connect-time residual
        on fast cEdges. v27.1.40 extends the same discipline to
        between-section boundaries: send a bare CR to force a fresh prompt
        redraw on the device side, wait 400ms, then do a blocking drain
        for up to 500ms to pull every residual byte into our buffer where
        it will be discarded (not prepended to the next command).

        Zero behavior change on devices without the residual pattern —
        the drain simply returns empty and we move on. Adds ~400ms per
        section, acceptable given this fires at most ~20 times per run
        (one per command in CEDGE_COMMANDS/VEDGE_COMMANDS/AUTONOMOUS_COMMANDS).
        """
        if self._channel is None:
            return
        try:
            # Force fresh prompt redraw on the device side.
            self._channel.sendall(b"\r")
            # Short wait for the \r to echo back + any late residual.
            # Not using self._drain() here because it has a 3-second
            # deadline that would add seconds per section on a slow
            # device. We only need enough time to absorb a residual
            # tail that is already in flight: 300ms covers the IOS-XE
            # 17.12.08 pattern seen on konecr-tianjin build 16500.
            deadline = time.time() + 0.3
            scratch = b""
            while time.time() < deadline:
                if self._channel.recv_ready():
                    chunk = self._channel.recv(self._RECV_CHUNK)
                    if not chunk:
                        break
                    scratch += chunk
                    # Extend window while bytes keep arriving so a
                    # mid-flush is not split across command boundaries.
                    deadline = max(deadline, time.time() + 0.1)
                else:
                    time.sleep(0.02)
            # Residual (if any) is intentionally discarded — not
            # attributed to any command. _quick_drain() at the start
            # of the next send_command will catch any final stragglers.
            if scratch:
                logger.debug("%s: section boundary absorbed %d residual bytes",
                             self.host, len(scratch))
        except (paramiko.SSHException, OSError):
            logger.debug("%s: section boundary reset failed", self.host)

    @staticmethod
    def _is_caret_rejection(output: str) -> bool:
        """v27.1.40 F3: True when output carries the IOS-XE `% Invalid
        input detected at '^' marker.` rejection phrase. This is the
        exact signature seen on konecr-tianjin build 16500 and
        konecr-addison build 16458. Case-sensitive match is intentional —
        the device always emits this phrase verbatim.
        """
        return "% Invalid input detected at '^' marker" in (output or "")

    def run_commands(self, commands: Dict[str, str]) -> Dict[str, dict]:
        """Execute a dict of named commands and collect outputs.

        Returns a dict of {name: {"ok": bool, "output": str, "error": str}}.
        This shape lets the filter layer distinguish "command errored"
        from "command produced empty output that happens to contain 'up'".

        v27.1.40 F1+F2+F3: before every command AFTER the first, call
        _section_boundary_reset() to clear residual bytes from the prior
        section's output tail (the konecr-tianjin build 16500 pattern).
        If a command's output carries the IOS-XE caret-rejection phrase,
        reset and retry ONCE — a self-healing path for the ~10% of
        IOS-XE 17.12.08 devices where the first attempt still bleeds.
        First-command behavior is unchanged (connect-time _disable_paging
        already covers that case).
        """
        results: Dict[str, dict] = {}
        first = True
        for name, cmd in commands.items():
            if cmd is None:
                continue
            try:
                if not first:
                    # F1+F2: clear residual before THIS command.
                    self._section_boundary_reset()
                out = self.send_command(cmd)
                # F3: self-heal on caret rejection. Retry once after a
                # hard reset. Only retry when the device OBVIOUSLY rejected
                # the command (not a timeout or legitimate empty output).
                if self._is_caret_rejection(out):
                    logger.info("%s: caret rejection on %r, retrying once "
                                "after hard buffer reset", self.host, cmd)
                    self._section_boundary_reset()
                    time.sleep(0.3)
                    retry_out = self.send_command(cmd)
                    # Only adopt the retry if it produced a non-rejection.
                    # If the retry ALSO rejects, keep the first output so
                    # the operator sees the error, not a stale blank.
                    if not self._is_caret_rejection(retry_out) and retry_out.strip():
                        out = retry_out
                results[name] = {"ok": True, "output": out, "error": ""}
            except Exception as exc:
                results[name] = {"ok": False, "output": "", "error": str(exc)}
                logger.warning("Command %r failed on %s: %s", cmd, self.host, exc)
            finally:
                first = False
        return results

    def disconnect(self) -> None:
        """Gracefully close SSH channel, client, and any owned transport."""
        try:
            if self._channel and not self._channel.closed:
                self._channel.close()
        except (paramiko.SSHException, OSError):
            pass
        try:
            if self._client:
                self._client.close()
        except (paramiko.SSHException, OSError):
            pass
        try:
            if self._transport:
                self._transport.close()
        except (paramiko.SSHException, OSError):
            pass

    def __enter__(self) -> "ViptelaSSH":
        self.connect()
        return self

    def __exit__(self, *_: object) -> None:
        self.disconnect()


def _flatten_outputs(results: Dict[str, dict]) -> Dict[str, str]:
    """Compat shim: downstream Jinja expects flat {command_name: text}.

    ONLY real command names live in this dict; errors are reported through
    the sibling `errors` field returned by run_primary/run_secondary so
    consumers that iterate cli_output.items() don't render synthetic entries.
    """
    flat: Dict[str, str] = {}
    for name, entry in (results or {}).items():
        if not isinstance(entry, dict):
            flat[name] = str(entry)
            continue
        flat[name] = entry.get("output", "") or ""
    return flat


def _errors_of(results: Dict[str, dict]) -> Dict[str, str]:
    """Return {command_name: error_text} for commands that failed."""
    errs: Dict[str, str] = {}
    for name, entry in (results or {}).items():
        if isinstance(entry, dict) and not entry.get("ok", True) and entry.get("error"):
            errs[name] = entry["error"]
    return errs


def _looks_like_vedge_error_flood(outputs: dict) -> bool:
    """v27.1.32: True when the capture is dominated by Viptela OS error
    syntax, indicating we sent cEdge commands to a vEdge. Decision rule:
    at least 3 of the SD-WAN-only keys returned a Viptela-syntax error
    AND no key returned a healthy SD-WAN banner. Conservative so a real
    SD-WAN cEdge with a few transient failures is never mis-classified
    as vedge.
    """
    if not isinstance(outputs, dict):
        return False
    sdwan_keys = ("system_status", "control_connections", "control_local_props",
                  "bfd_sessions", "omp_peers", "cert_status", "cert_validity",
                  "cert_installed")
    vedge_err_hits = 0
    healthy_sdwan_banner = False
    for k in sdwan_keys:
        entry = outputs.get(k) or {}
        text = (entry.get("output") if isinstance(entry, dict) else entry) or ""
        if not text:
            continue
        low = text.lower()
        if ViptelaSSH._looks_like_vedge_error(text):
            vedge_err_hits += 1
            continue
        # Signs of a healthy SD-WAN banner / table: Viptela mentions, long
        # content, column headers like "PEER" / "SITE" / "STATE".
        if (len(text) > 200
                and ("viptela" in low
                     or re.search(r"\bpeer\b.*\bstate\b", low)
                     or "device role" in low)):
            healthy_sdwan_banner = True
    return vedge_err_hits >= 3 and not healthy_sdwan_banner


def run_primary(host: str, username: str, password: str,
                platform: str, timeout: int,
                allow_unknown_hosts: bool = False,
                known_hosts_path: Optional[str] = None) -> dict:
    """Collect full diagnostic output from primary device.

    v27.1.32: late-detect vEdge mistag. If initial platform resolves to
    cedge but every `show sdwan X` returns Viptela OS error syntax, re-
    run the whole command set with VEDGE_COMMANDS on the SAME SSH
    session (no reconnect, no reauth). The 53bank-RB046418A1-23280015e001
    case (Jenkins build 14968) proved the Ansible-side override can
    still ship `platform=cedge` even when `detect_platform()` would
    have returned vedge, so this guards the SSH script from honoring an
    incorrect inventory tag.
    """
    with ViptelaSSH(host, username, password, timeout=timeout,
                    allow_unknown_hosts=allow_unknown_hosts,
                    known_hosts_path=known_hosts_path) as ssh:
        if not platform or platform not in ("cedge", "vedge"):
            platform = ssh.detect_platform()
        if platform not in ("cedge", "vedge"):
            return {"success": False, "platform": "", "submode": "",
                    "outputs": {}, "errors": {}, "error": "PlatformDetectionFailed: "
                    "device did not answer either system status probe"}

        # v27.1.37 — cEdge sub-mode gate. BEFORE sending the full cEdge
        # command set, confirm the SD-WAN daemon is actually loaded.
        # On a classic IOS-XE autonomous cEdge (ESP tagged CEDGE but
        # vdaemon never came up — the wawai-s08045 / lear-zaeascrp01 /
        # unitedbank-kernstown pattern), AUTONOMOUS_COMMANDS replaces
        # CEDGE_COMMANDS so DIAG renders real BGP / BFD / crypto /
        # interface evidence instead of 17 "(not available)" lines.
        # One extra SSH round-trip per cEdge; zero behavior change for
        # SD-WAN-mode cEdges.
        submode = ""
        if platform == "cedge":
            submode = ssh._probe_sdwan_mode()
            if submode == "autonomous":
                logger.info(
                    "%s: cEdge detected in classic IOS-XE autonomous "
                    "mode - using AUTONOMOUS_COMMANDS instead of "
                    "CEDGE_COMMANDS", host)
                commands = AUTONOMOUS_COMMANDS
            else:
                commands = CEDGE_COMMANDS
        else:
            commands = VEDGE_COMMANDS

        structured = ssh.run_commands(commands)

        # v27.1.32: vedge-mistag recovery. If platform=cedge but the
        # capture is dominated by Viptela OS error syntax, this device
        # is really a vEdge. Re-run against VEDGE_COMMANDS on the
        # already-open SSH session (one additional pass, same auth).
        # Note: only runs when we used CEDGE_COMMANDS (not for
        # autonomous-mode devices, which have their own classic-IOS-XE
        # command set and should not be re-run as vEdge).
        if (platform == "cedge" and submode != "autonomous"
                and _looks_like_vedge_error_flood(structured)):
            logger.warning(
                "%s: cedge probe produced Viptela OS error flood - "
                "re-running as vedge (mistag recovery)", host)
            platform = "vedge"
            structured = ssh.run_commands(VEDGE_COMMANDS)

        flat       = _flatten_outputs(structured)
        errors     = _errors_of(structured)
        # success only if at least one command produced non-error output
        any_good = any(entry.get("ok") and (entry.get("output") or "").strip()
                       for entry in structured.values())

    return {"success": bool(any_good), "platform": platform,
            "submode": submode,
            "outputs": flat, "errors": errors, "error": None}


def run_secondary(host: str, username: str, password: str,
                  platform: str, timeout: int,
                  allow_unknown_hosts: bool = False,
                  known_hosts_path: Optional[str] = None) -> dict:
    """Collect TLOC and VRRP diagnostics from secondary/redundant router."""
    with ViptelaSSH(host, username, password, timeout=timeout,
                    allow_unknown_hosts=allow_unknown_hosts,
                    known_hosts_path=known_hosts_path) as ssh:
        if not platform or platform not in ("cedge", "vedge"):
            platform = ssh.detect_platform()
        # Contract-symmetric with run_primary: fail loudly on unknown platform.
        if platform not in ("cedge", "vedge"):
            return {"success": False, "platform": "",
                    "outputs": {}, "errors": {}, "error": "PlatformDetectionFailed: "
                    "secondary device did not answer either system status probe"}

        commands: Dict[str, str] = {}
        for name, platform_cmds in SECONDARY_COMMANDS.items():
            cmd = platform_cmds.get(platform)
            if cmd:
                commands[name] = cmd

        structured = ssh.run_commands(commands)
        flat       = _flatten_outputs(structured)
        errors     = _errors_of(structured)
        any_good = any(entry.get("ok") and (entry.get("output") or "").strip()
                       for entry in structured.values())

    return {"success": bool(any_good), "platform": platform,
            "outputs": flat, "errors": errors, "error": None}


def run_two_hop(host: str, username: str, password: str,
                target_ip: str, target_vpn: str, target_user: str,
                wait_seconds: int,
                platform: str, timeout: int,
                allow_unknown_hosts: bool = False,
                known_hosts_path: Optional[str] = None) -> dict:
    """Two-hop SSH: SSH to the secondary device (host/username/password),
    then from the secondary's Viptela CLI issue
        request execute vpn <target_vpn> ssh -l <target_user> <target_ip>
    and observe the response. Verizon reports ~90% of such attempts are
    ACL-blocked; the ~10% that succeed reach primary when its own mgmt is
    down. We interpret the response text (not full login handshake — we
    never send target's password) and return:
      success=True  when we see a password prompt / SSH banner from target
                    (i.e. two-hop path is open — NOC can complete login)
      success=False when timeout / connection refused / ACL block / no banner

    Never sends target's password anywhere — this is a REACHABILITY probe.
    """
    if not target_ip or not target_user:
        return {"success": False, "platform": platform, "outputs": {}, "errors": {},
                "error": "TwoHopMissingArgs: target-ip and target-user are required"}

    with ViptelaSSH(host, username, password, timeout=timeout,
                    allow_unknown_hosts=allow_unknown_hosts,
                    known_hosts_path=known_hosts_path) as ssh:
        if not platform or platform not in ("cedge", "vedge"):
            platform = ssh.detect_platform()

        # Two-hop SSH syntax differs by platform:
        #   vEdge  : `request execute vpn <n> ssh -l <user> <ip>` (VPN IDs).
        #   cEdge, VPN 0 (TLOC transport, global routing table): `ssh -l <user> <ip>`.
        #   cEdge, VPN 1+ (customer service VRF): `ssh -vrf <name> -l <user> <ip>`.
        # cEdge service VRFs use per-customer names that cannot be inferred
        # from the VPN number, so a caller must supply the VRF name via
        # `two_hop_cedge_vrf_name`; otherwise the attempt is skipped with a
        # clear reason rather than guessing.
        if platform == "cedge":
            if str(target_vpn) == "0":
                cmd = "ssh -l {user} {ip}".format(user=target_user, ip=target_ip)
            else:
                # target_user encodes intent; if a VRF name was passed via
                # target_vpn (operator override), use it verbatim as `-vrf`;
                # otherwise skip because guessing gives "% IP routing table
                # X does not exist" which is worse than a clear skip message.
                # The redundant_router.yaml task 3054 passes the extra-var
                # value directly into --target-vpn for this case.
                if not target_vpn or str(target_vpn).strip() in ("", "0", "None"):
                    return {"success": False, "platform": platform,
                            "outputs": {}, "errors": {},
                            "target": {"ip": target_ip, "vpn": target_vpn, "user": target_user},
                            "banner_seen": False,
                            "failure_reason": ("cEdge two-hop VRRP path skipped: no cEdge VRF "
                                               "name supplied. Set extra-var two_hop_cedge_vrf_name "
                                               "to the customer's service VRF (e.g. 512, MPLS, DIA)."),
                            "error": None}
                cmd = "ssh -vrf {vrf} -l {user} {ip}".format(
                    vrf=target_vpn, user=target_user, ip=target_ip)
        else:
            cmd = "request execute vpn {vpn} ssh -l {user} {ip}".format(
                vpn=target_vpn, user=target_user, ip=target_ip)

        # send_command's default idle-wait is 2s; two-hop needs longer for
        # ACL timeout messages or remote SSH handshake to complete.
        try:
            # Two-hop payloads end at the REMOTE device's prompt, not ours,
            # so prompt-mode cannot terminate the read. Use the legacy
            # idle-wait path here on purpose.
            raw = ssh.send_command(cmd, idle_wait=float(wait_seconds),
                                   wait_for_prompt=False)
        except Exception as exc:  # noqa: BLE001
            return {"success": False, "platform": platform, "outputs": {}, "errors": {},
                    "error": "TwoHopSendFailed: " + str(exc)}

        # Send Ctrl-C in case the two-hop ssh hung waiting for input, so we
        # return the secondary's shell to a clean prompt before disconnect.
        try:
            ssh._channel.sendall(b"\x03")
            time.sleep(0.3)
            ssh._drain()
        except Exception:
            pass

    text = (raw or "")
    lower = text.lower()
    # Success signals: any indication the target SSH daemon answered.
    # Covers both platforms:
    #   vEdge: "Welcome to Viptela CLI", "Password:"
    #   cEdge (IOS-XE): "User Access Verification", "Password:", "Username:"
    #   Either: host-key prompt ("authenticity of host"), fingerprint banner
    success = (
        "password:" in lower
        or "welcome to viptela cli" in lower           # vEdge banner
        or "user access verification" in lower         # cEdge/IOS banner
        or "username:" in lower                         # cEdge username prompt
        or "authenticity of host" in lower              # first-time host key
        or "newkeys" in lower                           # paramiko-style key negotiation
        or "keyboard-interactive" in lower              # AAA challenge
    )
    # Explicit failure signals
    failure_reason = ""
    for pat, reason in (
        ("connection timed out", "ACL/route blocked (connection timed out)"),
        ("no route to host",     "no route to target IP"),
        ("connection refused",   "target refused SSH connection"),
        ("permission denied",    "target refused login"),
        ("network is unreachable", "target network unreachable"),
        ("interrupt",            "attempt interrupted"),
        # cEdge (IOS-XE SD-WAN) specific errors
        ("ip routing table",     "cEdge VRF not configured on this device — set two_hop_cedge_vrf_name"),
        ("% invalid input",      "cEdge command syntax rejected (check VRF name or IOS-XE version)"),
        ("% ambiguous command",  "cEdge command was ambiguous (partial match)"),
    ):
        if pat in lower:
            failure_reason = reason
            break

    outputs = {"two_hop_probe": text[-2000:]}  # keep last 2KB for report
    return {"success": bool(success), "platform": platform,
            "outputs": outputs, "errors": {},
            "target": {"ip": target_ip, "vpn": target_vpn, "user": target_user},
            "banner_seen": success,
            "failure_reason": failure_reason,
            "error": None}


def _read_password(args) -> str:
    """Read the password from a safe channel, never from argv."""
    if args.password_env:
        val = os.environ.get(args.password_env, "")
        if val:
            return val
    if args.password_file:
        try:
            with open(args.password_file, "r", encoding="utf-8") as fh:
                return fh.read().rstrip("\r\n")
        except OSError as exc:
            raise SystemExit(f"unable to read --password-file: {exc}")
    # Fallback: stdin (Ansible can pipe it in with `communicate=`)
    if not sys.stdin.isatty():
        return sys.stdin.read().rstrip("\r\n")
    return getpass.getpass("password: ")


def parse_args():
    """Parse command-line arguments. Password is NEVER accepted on argv."""
    parser = argparse.ArgumentParser(description="Viptela SSH Diagnostics")
    parser.add_argument("--host",     required=True, help="Device management IP")
    parser.add_argument("--user",     required=True, help="SSH username")
    parser.add_argument("--password-env", default="VIPTELA_SSH_PASSWORD",
                        help="Env var holding the SSH password")
    parser.add_argument("--password-file", default="",
                        help="File containing the SSH password (single line)")
    parser.add_argument("--platform", default="",
                        help="cedge|vedge (auto-detect if empty)")
    parser.add_argument("--mode",     default="primary", choices=["primary", "secondary", "secondary_full", "two_hop"])
    # v27.1.14 E2: secondary_full mode runs the full primary command set
    # against the partner router. NOC asked for "blast checking of all
    # device" (dual-router sites) so the partner's state is visible with
    # the same per-section symmetry as the primary. secondary mode still
    # exists for the lightweight TLOC/VRRP-only path used by two_hop.
    parser.add_argument("--timeout",  default=30, type=int, help="SSH timeout seconds")
    parser.add_argument("--allow-unknown-hosts", action="store_true",
                        help="Accept unknown SSH host keys (lab only)")
    parser.add_argument("--known-hosts", default="",
                        help="Path to known_hosts file for host-key verification")
    # two-hop mode (MOP: back-to-back SSH from secondary via TLOC peer
    # or VRRP VIP to reach primary when its mgmt path is down). Verizon
    # data shows ~90% of such attempts are ACL-blocked; the ~10% that
    # succeed save significant NOC time.
    parser.add_argument("--target-ip",   default="",
                        help="two_hop mode: destination IP to SSH to from secondary")
    parser.add_argument("--target-vpn",  default="0",
                        help="two_hop mode: VPN context to run the ssh in (0 for TLOC, 1 for VRRP)")
    parser.add_argument("--target-user", default="",
                        help="two_hop mode: username for the two-hop SSH login")
    parser.add_argument("--two-hop-wait", default=10, type=int,
                        help="two_hop mode: seconds to wait for target response")
    return parser.parse_args()


def _sanitize(err_text: str, secret: str) -> str:
    """Best-effort scrub of a secret out of an error message."""
    if not secret:
        return err_text
    try:
        return err_text.replace(secret, "***")
    except Exception:
        return err_text


def main() -> None:
    """Entry point — run SSH diagnostics and emit JSON to stdout.

    Always exits 0 with a result object so Ansible can inspect `success`
    without having to distinguish auth failure from process-level failure.
    """
    args = parse_args()
    try:
        password = _read_password(args)
    except SystemExit as exc:
        print(json.dumps({"success": False, "platform": args.platform,
                          "outputs": {}, "errors": {},
                          "error": f"CredentialInputError: {exc}"}))
        sys.exit(0)

    kwargs = dict(
        platform=args.platform,
        timeout=args.timeout,
        allow_unknown_hosts=args.allow_unknown_hosts,
        known_hosts_path=(args.known_hosts or None),
    )

    def _fail(kind: str, exc: BaseException) -> dict:
        return {"success": False, "platform": args.platform,
                "outputs": {}, "errors": {},
                "error": f"{kind}: {_sanitize(str(exc), password)}"}

    try:
        if args.mode == "two_hop":
            result = run_two_hop(
                args.host, args.user, password,
                target_ip=args.target_ip,
                target_vpn=args.target_vpn,
                target_user=(args.target_user or args.user),
                wait_seconds=args.two_hop_wait,
                **kwargs,
            )
        elif args.mode == "secondary":
            result = run_secondary(args.host, args.user, password, **kwargs)
        elif args.mode == "secondary_full":
            # v27.1.14 E2: NOC "blast check" — run the primary diag set
            # against the partner router. Semantics identical to primary;
            # the differentiator is only which role_name slot the caller
            # saves the output under.
            result = run_primary(args.host, args.user, password, **kwargs)
        else:
            result = run_primary(args.host, args.user, password, **kwargs)
    except paramiko.AuthenticationException as exc:
        result = _fail("AuthenticationFailed", exc)
        _emit_last_error("auth_rejected", _sanitize(str(exc), password))
    except paramiko.BadHostKeyException as exc:
        result = _fail("BadHostKey", exc)
        _emit_last_error("host_key_mismatch", _sanitize(str(exc), password))
    except paramiko.SSHException as exc:
        result = _fail("SSHException", exc)
        emsg = _sanitize(str(exc), password).lower()
        code = ("prompt_timeout" if "prompt" in emsg or "timeout" in emsg
                else "generic")
        _emit_last_error(code, _sanitize(str(exc), password))
    except (socket.timeout, TimeoutError) as exc:
        result = _fail("ConnectionTimeout", exc)
        _emit_last_error("tcp_timeout", _sanitize(str(exc), password))
    except ConnectionRefusedError as exc:
        result = _fail("ConnectionRefused", exc)
        _emit_last_error("tcp_refused", _sanitize(str(exc), password))
    except OSError as exc:
        result = _fail("NetworkError", exc)
        emsg = _sanitize(str(exc), password).lower()
        code = ("tcp_refused" if "refused" in emsg
                else "tcp_timeout" if "timed out" in emsg or "timeout" in emsg
                else "generic")
        _emit_last_error(code, _sanitize(str(exc), password))
    except Exception as exc:  # noqa: BLE001 — last-resort so JSON is always emitted
        result = _fail("UnexpectedError", exc)
        _emit_last_error("generic", _sanitize(str(exc), password))

    print(json.dumps(result))
    # Exit 0 always: the caller inspects result.success. Non-zero here would
    # collide with Ansible's failure semantics and lose the diagnostic JSON.
    sys.exit(0)


if __name__ == "__main__":
    main()
