"""Filter plugins for Cisco Viptela SD-WAN diagnostic processing."""

from __future__ import annotations

import re
import time
from datetime import datetime, timedelta, timezone


class FilterModule:
    """Viptela SD-WAN Ansible filter plugins."""

    def filters(self) -> dict:
        return {
            "detect_platform":              self.detect_platform,
            "is_vmanaged":                  self.is_vmanaged,
            "cap_text":                     self.cap_text,
            "is_control_healthy":           self.is_control_healthy,
            "is_cli_control_healthy":       self.is_cli_control_healthy,
            "parse_ping_loss_pct":          self.parse_ping_loss_pct,
            "normalize_description":        self.normalize_description,
            "strip_invalid_commands":       self.strip_invalid_commands,
            "trim_cli_noise":               self.trim_cli_noise,
            "count_control_flaps":          self.count_control_flaps,
            "count_bfd_flaps":              self.count_bfd_flaps,
            "count_cli_control_flaps":      self.count_cli_control_flaps,
            "get_alarm_uuid":               self.get_alarm_uuid,
            "get_all_alarm_uuids":          self.get_all_alarm_uuids,
            "get_vrrp_virtual_ip":          self.get_vrrp_virtual_ip,
            "derive_tloc_peer_ip":          self.derive_tloc_peer_ip,
            "get_secondary_router_ip":      self.get_secondary_router_ip,
            "find_site_partner_ip":         self.find_site_partner_ip,
            "find_site_partner_hostname":   self.find_site_partner_hostname,
            "get_mgmt_ip_by_hostname":      self.get_mgmt_ip_by_hostname,
            "extract_site_devices":         self.extract_site_devices,
            "tally_blast_radius":           self.tally_blast_radius,
            "get_down_wan_interfaces":      self.get_down_wan_interfaces,
            "was_recent_reboot":            self.was_recent_reboot,
            "parse_tloc_ips_from_wan_list": self.parse_tloc_ips_from_wan_list,
            "parse_tloc_b2b_ip":            self.parse_tloc_b2b_ip,
            "parse_vrrp_vip_from_cli":      self.parse_vrrp_vip_from_cli,
            "parse_standby_vip_from_cli":   self.parse_standby_vip_from_cli,
            "format_vmanage_summary":       self.format_vmanage_summary,
            "format_cli_summary":           self.format_cli_summary,
            # v23 NOC-standard output.dat helpers
            "count_real_outputs":           self.count_real_outputs,
            "trim_to_useful":               self.trim_to_useful,
            "last_lines":                   self.last_lines,
            "mask_gateway_tokens":          self.mask_gateway_tokens,
            "build_router_down_npoa":       self.build_router_down_npoa,
            "uptime_to_minutes":            self.uptime_to_minutes,
            "minutes_since_last_flap":      self.minutes_since_last_flap,
            "clean_cli_dict":               self.clean_cli_dict,
            # NOC-facing vManage renderers (A+)
            "vmanage_ctrl_table":           self.vmanage_ctrl_table,
            "vmanage_bfd_table":            self.vmanage_bfd_table,
            "vmanage_omp_table":            self.vmanage_omp_table,
            "vmanage_down_intfs_table":     self.vmanage_down_intfs_table,
            "vmanage_cpu_mem_line":         self.vmanage_cpu_mem_line,
            "vmanage_last_reboot_line":     self.vmanage_last_reboot_line,
            "vmanage_hw_alarm_line":        self.vmanage_hw_alarm_line,
            "ctrl_summary_line":            self.ctrl_summary_line,
            "bfd_summary_line":             self.bfd_summary_line,
            "omp_summary_line":             self.omp_summary_line,
            # Credential shape normalizer (I0, v27.1)
            "normalize_credentials":        self.normalize_credentials,
            # Master-trigger-substring scrubber (v27.1 review HIGH-B)
            "scrub_master_triggers":        self.scrub_master_triggers,
            # v27.1.3 CLI fallbacks for uptime / cpu-mem / last reboot (NOC
            # feedback on aecom-london ticket 2026101302318: these three
            # fields rendered "unknown"/"not reported" even though SSH
            # succeeded and the CLI captured the data).
            "parse_cli_uptime":             self.parse_cli_uptime,
            "tail_lines":                   self.tail_lines,
            # v27.1.35 — strip Legend-for-Errors preamble from
            # control connection-history captures (both platforms).
            "strip_control_history_legend": self.strip_control_history_legend,
            # v27.1.35 — condense raw X.509 cert dump to the 3 lines
            # NOC uses (Issuer / Subject / Validity).
            "cert_installed_summary":       self.cert_installed_summary,
            # v27.1.36 — pre-SSH platform hint from vManage device row.
            # Lets viptela_ssh.py pick the right command map on the
            # first probe instead of relying on in-session detection
            # that can lose a round-trip to a mistag.
            "derive_platform_from_vmanage": self.derive_platform_from_vmanage,
            # v27.1.36 — post-reload grace gate. Returns True when the
            # device uptime is below the per-platform convergence
            # window (cEdge 15 min, vEdge 10 min). Caller uses this to
            # defer auto-closure to NOC Review when SD-WAN daemon may
            # not yet have converged after a cold boot.
            "is_post_reload_grace":         self.is_post_reload_grace,
            "wan_intf_down_summary":        self.wan_intf_down_summary,
            "alarm_clear_outcome_line":     self.alarm_clear_outcome_line,
            "parse_cli_cpu_mem_line":       self.parse_cli_cpu_mem_line,
            "parse_cli_last_reboot_line":   self.parse_cli_last_reboot_line,
            # v27.1.5 - NOC-driven DIAGNOSTIC-block render rules:
            # (hydroalu build 13226 - logging_last got truncated by the
            # 24,000-char iAutomate cap because big BFD tables filled the
            # budget first; NOC also asked for logging anchored to the
            # ticket timestamp, DOWN-only control/BFD, latest reboots with
            # repeat-count, and tunnel statistics only as a fill-the-rest
            # relevance block).
            "logging_filter_window":        self.logging_filter_window,
            "table_down_or_topn_up":        self.table_down_or_topn_up,
            "reboot_history_topn":          self.reboot_history_topn,
            "tunnel_stats_relevant":        self.tunnel_stats_relevant,
            # v27.1.8 - symmetric DIAG rendering helpers:
            "detect_device_mode":           self.detect_device_mode,
            "diag_fallback_text":           self.diag_fallback_text,
            # v27.1.26 - MOP step 58 version filter (regression fix).
            # Replaces the IOS-XE pipe-filter form that returned empty on
            # some Controller-Managed cEdges after v27.1.17 collapsed the
            # Oct-9 5-alternation form to 4. Full show-version comes back
            # from SSH; this filter keeps only the 6 MOP-required lines.
            "cli_version_filter":           self.cli_version_filter,
            # v27.1.32 - safe response_msg truncation at line boundary.
            # Fixes the "...system-ip:172 Engage NOC to manual
            # troubleshooting..." mid-line concatenation glitch where
            # the Jenkins post-processor appends an "Engage NOC" trailer
            # onto whatever character the budget slice ended at. Also
            # used with the v27.1.32 budget reduction 24,400 -> 23,000
            # so the response_msg stays well inside the single-chunk
            # VBSM API limit and never splits into Chunk 1/2 + Chunk 2/2.
            "safe_truncate_at_line":        self.safe_truncate_at_line,
            # v27.1.40 F5 — dying-gasp evidence parse from secondary logs.
            # MOP c2 says: if the primary powered off, its chassis typically
            # sends a `%VPM-6-DYING_GASP` (or similar) line to the LAN peer
            # before the circuit dies; the SECONDARY's syslog is where that
            # evidence lives (the primary is unreachable). Mirrors legacy
            # Cisco-Router-Device-Down task 1253. Returns a short dict:
            #   {"seen": bool, "evidence": str}
            # with the matched line (if any) so write_output can quote it.
            "parse_dying_gasp_from_logs":   self.parse_dying_gasp_from_logs,
            # v27.1.40 F6 — summarize secondary-side MOP probe output when
            # both two-hops to the primary failed. Parallels legacy
            # Cisco-Router-Device-Down task 1262M. Returns a dict with
            # reload line, dying-gasp line, and a one-line summary.
            "summarize_secondary_mop":      self.summarize_secondary_mop,
        }

    # Platform detection

    def detect_platform(self, output: str) -> str:
        """Detect device platform from system status and show version output.

        cEdge signals (any one is conclusive):
          - 'Device role: cEdge-SDWAN' or 'Device role: cEdge'
          - 'Controller-Managed' (IOS-XE in SD-WAN mode)
          - 'Cisco IOS XE' or 'IOS-XE' in banner
          - Model contains CSR, C8000, ISR, ASR (word-boundary)
        vEdge signals:
          - 'Model: vEdge' or 'viptela' in version
          - Absence of all cEdge signals
        Fallback returns "" (unknown) so callers can escalate instead of
        misclassifying a platform for which the wrong CLI would be sent.
        """
        if not isinstance(output, str) or not output.strip():
            return ""

        lower = output.lower()

        # Definitive cEdge markers. Operator precedence rewritten as
        # sequential checks to avoid the (A or B) if C else False trap.
        if "cedge-sdwan" in lower:
            return "cedge"
        if "device role:" in lower and "cedge" in lower.split("device role:", 1)[-1][:40]:
            return "cedge"
        if "controller-managed" in lower:
            return "cedge"
        if "cisco ios xe" in lower or "ios-xe" in lower:
            return "cedge"

        # Model-based detection using word boundaries so 'asr' does not match
        # 'traceroute' or 'phrase' inside banners.
        if re.search(r"\b(csr1000v|csr\d+|c8[0-9]{3}|isr\d+|asr\d+|c11\d{2})\b", lower):
            return "cedge"

        # Definitive vEdge markers
        if re.search(r"\bmodel\s*:\s*vedge\b", lower):
            return "vedge"
        if "viptela" in lower:
            return "vedge"

        # Version-based scoring with anchoring so "17." only matches versions
        cedge_kw = (r"\b17\.\d", r"\b16\.\d", r"\bsdwan-enabled\b", r"\bxe software\b")
        vedge_kw = (r"\b18\.\d", r"\b19\.\d", r"\b20\.\d", r"\b21\.\d", r"\b22\.\d")

        cedge_score = sum(1 for pat in cedge_kw if re.search(pat, lower))
        vedge_score = sum(1 for pat in vedge_kw if re.search(pat, lower))

        if cedge_score == 0 and vedge_score == 0:
            return ""  # unknown - caller should escalate
        return "cedge" if cedge_score > vedge_score else "vedge"

    def is_vmanaged(self, output: str, version_output: str = "") -> bool:
        """Detect whether the device is under vManage control.

        Three authoritative fields, checked by value rather than keyword
        presence:
          vEdge - 'vManaged: true' in show system status
          vEdge - 'Configuration template: <name>' (None means unmanaged)
          cEdge - 'Router operating mode: Controller-Managed' in show version
        """
        not_managed = {"none", "n/a", "-", "false", "", "not applicable"}

        if isinstance(output, str) and output.strip():
            for line in output.splitlines():
                if re.match(r"\s*vmanaged\s*:", line, re.IGNORECASE):
                    if line.split(":", 1)[-1].strip().lower() == "true":
                        return True
                if "configuration template:" in line.lower():
                    if line.split(":", 1)[-1].strip().lower() not in not_managed:
                        return True

        if isinstance(version_output, str) and version_output.strip():
            for line in version_output.splitlines():
                if re.match(r"\s*router operating mode\s*:", line, re.IGNORECASE):
                    if "controller-managed" in line.split(":", 1)[-1].strip().lower():
                        return True
        return False

    def cap_text(self, text, max_chars: int = 24000) -> str:
        """Hard-cap a rendered report.

        iAutomate rejects payloads beyond roughly 25k characters, and an
        oversized --extra-vars string trips the Linux argument-length limit
        before that. Final backstop after per-section budgeting.
        """
        s = "" if text is None else str(text)
        try:
            limit = int(max_chars)
        except (TypeError, ValueError):
            limit = 24000
        if len(s) <= limit:
            return s
        marker = ("\n\n... report truncated at %d characters to stay within the "
                  "iAutomate payload limit. Full diagnostics remain in output.dat "
                  "on the automation host.\n" % limit)
        return s[: max(0, limit - len(marker))] + marker


    # Control plane health

    def is_control_healthy(self, connections: list) -> bool:
        """Check all vsmart and vmanage control connections are up."""
        if not isinstance(connections, list) or not connections:
            return False
        critical = [
            c for c in connections
            if isinstance(c, dict) and c.get("peer-type") in ("vsmart", "vmanage")
        ]
        if not critical:
            return False
        return all(
            str(c.get("state", "")).strip().lower() == "up"
            for c in critical
        )

    def is_cli_control_healthy(self, output: str) -> bool:
        """Return True when CLI control-connection output shows an established
        vsmart or vmanage session in the up state."""
        if not isinstance(output, str) or not output.strip():
            return False
        for line in output.splitlines():
            low = line.lower()
            # Header-row detection: bare header uses "PEER" and "TYPE" tokens
            tokens = low.split()
            if len(tokens) >= 2 and tokens[0] == "peer" and tokens[1] == "type":
                continue
            if line.strip().startswith("-"):
                continue
            if ("vsmart" in low or "vmanage" in low) and re.search(r"\bup\b", low):
                return True
        return False

    def normalize_description(self, desc: str) -> str:
        """Normalize iAutomate Description across all delivery formats.

        Description can arrive as real newlines, literal backslash-n,
        backslash-space, or a flat string with only spaces between labels.
        Fold escape sequences to real newlines. Bare backslashes are left
        alone so legitimate Windows paths like C:\\Users\\... are not
        corrupted into embedded newlines.
        """
        if not isinstance(desc, str) or not desc.strip():
            return ""
        d = desc
        d = d.replace("\r", "")
        # Escape sequences (literal two-char pairs)
        d = d.replace("\\r", "")
        d = d.replace("\\n", "\n")
        d = d.replace("\\ ", "\n")
        # NOTE: bare "\\" NOT replaced - that would corrupt Windows paths.
        labels = [
            "INCIDENT START TIME:", "NEID:", "HOSTNAME:",
            "IP ADDRESS:", "PRODUCT TYPE:", "EQUIPMENT TYPE:",
            "INCIDENT TYPE:", "ASSURE1 ALARM ID:", "TEXT:", "AID:",
        ]
        for lbl in labels:
            pat = re.compile(r"\s+(" + re.escape(lbl) + ")", re.IGNORECASE)
            d = pat.sub("\n" + r"\1", d)
        return d

    def trim_cli_noise(self, text):
        """Strip certificate PEM/modulus data and control-history error legends."""
        if not isinstance(text, str) or not text.strip():
            return text
        lines = text.split("\n")
        out = []
        skip_legend = False
        skip_cert = False
        for line in lines:
            low = line.strip().lower()
            if "legend for errors" in low:
                skip_legend = True
                continue
            if skip_legend:
                if line.strip().startswith("-" * 10):
                    skip_legend = False
                    out.append(line)
                continue
            if "modulus:" in low or "public-key:" in low:
                skip_cert = True
                out.append(line.rstrip())
                out.append("                    (data omitted)")
                continue
            if skip_cert:
                s = line.strip()
                if not s:
                    continue
                if s.startswith("Exponent:") or s.startswith("-----"):
                    continue
                if "(certificate data omitted)" in s or "(data omitted)" in s:
                    continue
                is_hex = (":" in s and len(s) > 5 and
                          sum(1 for ch in s if ch in "0123456789abcdefABCDEF:") > len(s) * 0.5)
                if is_hex:
                    continue
                skip_cert = False
            out.append(line)
        return "\n".join(out)

    def strip_invalid_commands(self, cli_output):
        """Remove CLI sections that are just invalid-command markers."""
        if not isinstance(cli_output, dict):
            return cli_output
        cleaned = {}
        for key, val in cli_output.items():
            if not isinstance(val, str):
                cleaned[key] = val
                continue
            stripped = val.strip()
            if not stripped:
                continue
            low = stripped.lower()
            if any(m in low for m in ("% invalid input", "syntax error", "unknown command", "% unrecognized")):
                continue
            cleaned[key] = val
        return cleaned

    def parse_ping_loss_pct(self, output: str) -> int:
        """Extract packet-loss percentage from ping output.

        Returns 100 when no loss figure can be parsed, so an unparseable result
        is treated as no response rather than silently as success. Accepts
        both '.' and ',' decimal separators.
        """
        if not isinstance(output, str) or not output.strip():
            return 100
        m = re.search(r"([0-9]+(?:[.,][0-9]+)?)%\s*packet loss", output, re.I)
        if not m:
            return 100
        try:
            return int(round(float(m.group(1).replace(",", "."))))
        except (ValueError, TypeError):
            return 100

    def count_control_flaps(self, history: list, window_minutes: int = 0) -> int:
        """Count vsmart control-connection down events.

        'connect' is deliberately excluded - it is the normal
        attempting-to-establish transient state and would inflate flaps.
        """
        if not isinstance(history, list):
            return 0
        cutoff_ms = 0
        if window_minutes and window_minutes > 0:
            cutoff_ms = int(time.time() * 1000) - (window_minutes * 60 * 1000)
        count = 0
        for h in history:
            if not isinstance(h, dict):
                continue
            state = str(h.get("state") or "").strip().lower()
            peer  = str(h.get("peer-type") or "").strip().lower()
            if peer not in ("vsmart", "vmanage"):
                continue
            if state not in ("down", "tear_down", "tear-down", "connect_fail",
                             "connect-fail", "challenge_fail"):
                continue
            if cutoff_ms:
                ts = self._event_epoch_ms(h)
                if ts is not None and ts < cutoff_ms:
                    continue
            count += 1
        return count

    def count_bfd_flaps(self, history: list, window_minutes: int = 0) -> int:
        """Count BFD session down events, optionally within a trailing window.

        v25 fix: when a window is applied, entries whose timestamp cannot be
        parsed are EXCLUDED from the count instead of being counted. The old
        behaviour counted untimed entries, which produced false counts (e.g.
        bfd_flap_count=333 in a 15-min window) and blocked closure of healthy
        devices with large historical BFD-history dumps.
        """
        if not isinstance(history, list):
            return 0
        cutoff_ms = 0
        if window_minutes and window_minutes > 0:
            cutoff_ms = int(time.time() * 1000) - (window_minutes * 60 * 1000)
        count = 0
        for h in history:
            if not isinstance(h, dict):
                continue
            state = str(h.get("state") or "").strip().lower()
            if state != "down":
                continue
            if cutoff_ms:
                ts = self._event_epoch_ms(h)
                # v25: untimed entries are OUTSIDE the window (safe default).
                if ts is None or ts < cutoff_ms:
                    continue
            count += 1
        return count

    @staticmethod
    def _event_epoch_ms(entry: dict):
        """Extract an epoch-millisecond timestamp from a history entry, or None."""
        for key in ("downtime-date", "create_time_stamp", "entry_time", "event_time",
                    "create_time", "lastupdated", "statechange_time"):
            val = entry.get(key)
            if val in (None, ""):
                continue
            try:
                num = int(float(val))
                # Filter obviously bogus microsecond values (>1e15 = year ~33000)
                if num > 10**14:
                    continue
                return num if num > 10_000_000_000 else num * 1000
            except (ValueError, TypeError):
                continue
        return None

    def count_cli_control_flaps(self, output: str, window_minutes: int = 15) -> int:
        """Count control-connection down events from CLI control-history text.

        Filters events by age: only lines whose trailing timestamp is within
        the last window_minutes are counted. Without a time window a device
        with a long resolved history (e.g. a card that flapped a year ago and
        has been stable since) would report ctrl_flap_count >= threshold and
        trigger a false is_flapping=True, suppressing alarm auto-clear on a
        genuinely-stable device.

        Timestamp formats supported (as they appear in show sdwan / show
        control connection-history LAST-CONNECTION column):
          - '2026-08-31T09:33:04+0000'  (ISO 8601 with tz)
          - '2026-08-31T09:33:04'       (ISO 8601 no tz - assumed UTC)
          - '2026-08-31 09:33:04'       (space-separated, assumed UTC)
        A line whose timestamp cannot be parsed is COUNTED (safer to
        over-count than miss a real flap due to a format change).
        """
        if not isinstance(output, str) or not output.strip():
            return 0
        try:
            win = int(window_minutes)
        except (TypeError, ValueError):
            win = 15
        if win <= 0:
            win = 15
        try:
            from datetime import datetime, timezone, timedelta
            now = datetime.now(timezone.utc)
            cutoff = now - timedelta(minutes=win)
        except Exception:  # pragma: no cover
            cutoff = None

        pat = re.compile(r"\b(tear[_ -]?down|conn(ect)?[_ -]?fail|challenge[_ -]?fail|down)\b",
                         re.IGNORECASE)
        ts_pat = re.compile(
            r"(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}:\d{2})([+-]\d{2}:?\d{2}|Z)?"
        )

        def within_window(line: str) -> bool:
            """True if line's timestamp is within the window OR unparseable
            (fail-open: count when we can't tell, so real flaps are never
            silently dropped by a format change).

            Uses datetime.strptime for portability - datetime.fromisoformat
            was added in Python 3.7 and would silently AttributeError on the
            SIT server's 3.6.8 interpreter, defaulting every event to
            "within window" and defeating the whole time filter.
            """
            if cutoff is None:
                return True
            m = ts_pat.search(line)
            if not m:
                return True
            date_s, time_s, tz_s = m.group(1), m.group(2), m.group(3) or ""
            # Normalize timezone: '', 'Z' -> UTC; '+0000' -> '+0000' (kept);
            # '+00:00' -> '+0000' (colon stripped for strptime %z on 3.6).
            if tz_s in ("", "Z"):
                tz_norm = "+0000"
            else:
                tz_norm = tz_s.replace(":", "")
                if len(tz_norm) == 3:  # e.g. '+05' -> '+0500'
                    tz_norm += "00"
            stamp = f"{date_s} {time_s} {tz_norm}"
            for fmt in ("%Y-%m-%d %H:%M:%S %z",):
                try:
                    ts = datetime.strptime(stamp, fmt)
                    return ts >= cutoff
                except (ValueError, TypeError):
                    continue
            # Fallback: naive parse, assume UTC.
            try:
                ts_naive = datetime.strptime(f"{date_s} {time_s}", "%Y-%m-%d %H:%M:%S")
                ts = ts_naive.replace(tzinfo=timezone.utc)
                return ts >= cutoff
            except (ValueError, TypeError):
                return True

        count = 0
        for line in output.splitlines():
            low = line.lower()
            # Skip header/separator lines
            if "state" in low and "peer" in low:
                continue
            if line.strip().startswith("-"):
                continue
            if not pat.search(low):
                continue
            if not within_window(line):
                continue
            count += 1
        return count

    # Alarm UUID helpers

    def get_alarm_uuid(self, alarms: list) -> str:
        """Extract UUID of first active alarm (single value, for compatibility)."""
        if not isinstance(alarms, list) or not alarms:
            return ""
        for alarm in alarms:
            if isinstance(alarm, dict) and alarm.get("active", False):
                return alarm.get("uuid", "")
        # No 'active' hit - return first dict entry with a uuid
        for alarm in alarms:
            if isinstance(alarm, dict) and alarm.get("uuid"):
                return alarm.get("uuid", "")
        return ""

    def get_all_alarm_uuids(self, alarms: list) -> list:
        """Extract ALL alarm UUIDs as a list for multi-UUID clear loop."""
        if not isinstance(alarms, list) or not alarms:
            return []
        return [
            a.get("uuid", "")
            for a in alarms
            if isinstance(a, dict) and a.get("uuid", "")
        ]

    # VRRP / WAN interface helpers

    def get_vrrp_virtual_ip(self, vrrp_data: list) -> str:
        """Extract VRRP virtual IP from vManage API response."""
        if not isinstance(vrrp_data, list) or not vrrp_data:
            return ""
        return vrrp_data[0].get("virtual-ip", "") if isinstance(vrrp_data[0], dict) else ""

    def parse_tloc_b2b_ip(self, desc_output, wan_output=""):
        """Extract the back-to-back TLOC IP from interface description output."""
        if not isinstance(desc_output, str):
            return []

        ips = []
        for line in desc_output.splitlines():
            low = line.lower()
            if "tloc" not in low and "b2b" not in low:
                continue
            candidates = re.findall(
                r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/\d+",
                line)
            for ip in candidates:
                parts = ip.split(".")
                try:
                    if all(0 <= int(p) <= 255 for p in parts) and ip != "0.0.0.0":
                        ips.append(ip)
                except (ValueError, TypeError):
                    pass
        return ips if ips else self.parse_tloc_ips_from_wan_list(wan_output)

    def derive_tloc_peer_ip(self, ip_address: str) -> str:
        """Derive TLOC P2P peer IP using even/odd /30 rule."""
        if not isinstance(ip_address, str) or not ip_address.strip():
            return ""
        try:
            parts = ip_address.strip().split(".")
            if len(parts) != 4:
                return ""
            last = int(parts[-1])
            peer = last - 1 if last % 2 == 0 else last + 1
            if peer < 1 or peer > 254:
                return ""
            return ".".join(parts[:3] + [str(peer)])
        except (ValueError, IndexError):
            return ""

    def find_site_partner_hostname(self, devices, primary_system_ip, primary_site_id):
        """Return host-name of the partner device at the same vManage site-id."""
        if not isinstance(devices, list) or not primary_site_id:
            return ""
        primary_sip = str(primary_system_ip).strip()
        primary_sid = str(primary_site_id).strip()
        for dev in devices:
            if not isinstance(dev, dict):
                continue
            sid = str(dev.get("site-id", "")).strip()
            sip = str(dev.get("system-ip", "")).strip()
            if sid == primary_sid and sip and sip != primary_sip:
                return str(dev.get("host-name", "")).strip()
        return ""

    def get_mgmt_ip_by_hostname(self, esp_response, hostname):
        """Map a vManage hostname to its ESP management IP via entityHostName."""
        target = str(hostname).strip().lower()
        if not target:
            return ""
        candidates = []
        if isinstance(esp_response, dict):
            candidates = esp_response.get("devices", [])
        elif isinstance(esp_response, list):
            candidates = esp_response
        for idx, entry in enumerate(candidates):
            if idx >= 500:
                # Explicit cap so downstream sees the ceiling was hit
                break
            if not isinstance(entry, dict):
                continue
            dev = entry.get("device") if isinstance(entry.get("device"), dict) else entry
            if str(dev.get("entityHostName", "")).strip().lower() == target:
                ip = str(dev.get("mgmtIPAddress", "")).strip()
                parts = ip.split(".")
                if len(parts) == 4:
                    try:
                        if all(0 <= int(p) <= 255 for p in parts):
                            return ip
                    except (ValueError, TypeError):
                        pass
        return ""

    def extract_site_devices(self, esp_response, primary_ip, site_prefix):
        """v27.1.15 blast-radius: pull all non-Modem routers at this site
        from an ESP inventory-search response. Returns a list of
        {name, ip} dicts, EXCLUDING the primary (so NOC does not get a
        self-loop in the ping fan-out) and EXCLUDING modems.

        Defensive: any shape anomaly returns []."""
        if not isinstance(esp_response, dict):
            return []
        rows = esp_response.get("devices", []) or []
        if not isinstance(rows, list):
            return []
        out = []
        seen_ips = set()
        prim = str(primary_ip or "").strip()
        pref = str(site_prefix or "").strip().lower()
        for idx, entry in enumerate(rows):
            if idx >= 100:  # hard cap, filter still after per-site slice
                break
            if not isinstance(entry, dict):
                continue
            dev = entry.get("device") if isinstance(entry.get("device"), dict) else entry
            if not isinstance(dev, dict):
                continue
            dev_type = str(dev.get("deviceType", "")).strip()
            if "modem" in dev_type.lower():
                continue
            ip = str(dev.get("mgmtIPAddress", "")).strip()
            name = str(dev.get("dnsEntityName", "") or dev.get("entityHostName", "")).strip()
            if not ip or ip == prim or ip in seen_ips:
                continue
            # Validate IPv4
            parts = ip.split(".")
            if len(parts) != 4:
                continue
            try:
                if not all(0 <= int(p) <= 255 for p in parts):
                    continue
            except (ValueError, TypeError):
                continue
            # Scope to the same site when a prefix is provided (e.g.
            # 'herbrt-hongkong-'); if no prefix, trust the ESP query
            # already scoped by -{location}-.
            if pref and name and pref not in name.lower():
                continue
            out.append({"name": name or ip, "ip": ip})
            seen_ips.add(ip)
        return out

    def tally_blast_radius(self, ping_results):
        """v27.1.15 blast-radius: fold a list of ansible-command ping
        results into a flat list of {name, ip, reachable}. Each
        ping_results entry has `_br_dev` (set by loop_control.loop_var)
        and `rc` (0 == alive). Any missing field defaults to not
        reachable."""
        out = []
        if not isinstance(ping_results, list):
            return out
        for r in ping_results:
            if not isinstance(r, dict):
                continue
            dev = r.get("_br_dev") or {}
            if not isinstance(dev, dict):
                dev = {}
            name = str(dev.get("name", "") or dev.get("ip", "")).strip()
            ip = str(dev.get("ip", "")).strip()
            # rc 0 means ping -c succeeded (at least 1 reply)
            try:
                rc = int(r.get("rc", 1))
            except (TypeError, ValueError):
                rc = 1
            reachable = (rc == 0)
            out.append({"name": name, "ip": ip, "reachable": reachable})
        return out

    def find_site_partner_ip(self, devices, primary_system_ip, primary_site_id):
        """Find partner device at the same vManage site-id.

        Returns "" when no management IP is present; a system-ip inside the
        overlay is unreachable from the automation host so it is not returned
        as a fallback.
        """
        if not isinstance(devices, list) or not primary_site_id:
            return ""
        primary_sip = str(primary_system_ip).strip()
        primary_sid = str(primary_site_id).strip()
        for dev in devices:
            if not isinstance(dev, dict):
                continue
            sid = str(dev.get("site-id", "")).strip()
            sip = str(dev.get("system-ip", "")).strip()
            if sid == primary_sid and sip and sip != primary_sip:
                device_ip = str(dev.get("deviceIP", "")).strip()
                if device_ip:
                    return device_ip
        return ""

    def get_secondary_router_ip(self, esp_response, primary_ip: str,
                                 primary_neid: str = "",
                                 site_prefix: str = "") -> str:
        """Extract partner router mgmtIPAddress from an ESP inventory response.

        Selection rules (per ESP integration hints):
          - Skip entries where isManaged is not true or isValid is not true.
          - When `site_prefix` is provided, require dnsEntityName to start
            with it - this keeps partner selection scoped to the same
            physical site (e.g. 'aetna-foxborough-37836171e' matches e001,
            e002, e003 but not another location).
          - Never return the primary device itself (matched by NEID first,
            falling back to management IP).
          - Require a valid IPv4 mgmtIPAddress. `ip` is a legacy fallback
            used only when mgmtIPAddress is absent.
        """
        primary_ip_s   = str(primary_ip or "").strip()
        primary_neid_s = str(primary_neid or "").strip().lower()
        site_prefix_s  = str(site_prefix or "").strip().lower()

        candidates = []
        if isinstance(esp_response, dict):
            candidates = esp_response.get("devices", [])
        elif isinstance(esp_response, list):
            candidates = esp_response

        for entry in candidates:
            if not isinstance(entry, dict):
                continue
            dev = entry.get("device") if isinstance(entry.get("device"), dict) else entry
            if not isinstance(dev, dict):
                continue
            # Only real, managed devices. Accept truthy values (e.g. the
            # string "true" some proxied ESP feeds return) - reject only
            # explicit falsy values.
            def _is_true(v):
                if isinstance(v, bool):
                    return v
                if isinstance(v, str):
                    return v.strip().lower() in ("true", "yes", "1")
                return bool(v)
            # Accept router-class deviceTypes. ESP labels vary by tenant:
            # classic Cisco IOS routers → "Router"; Viptela SD-WAN can show
            # as "Router" in some deployments and as "SDWAN Controller
            # Gateway" or "Viptela Management vEdge" in others. Reject
            # modems, cables, network modules, virtual entities.
            _dt = str(dev.get("deviceType") or "").strip().lower()
            if _dt not in ("router",
                           "sdwan controller gateway",
                           "viptela management vedge"):
                continue
            if not _is_true(dev.get("isManaged", True)):
                continue
            if not _is_true(dev.get("isValid", True)):
                continue
            neid = str(dev.get("dnsEntityName") or "").strip().lower()
            # Same-site gate (skip when caller did not supply a prefix)
            if site_prefix_s and not neid.startswith(site_prefix_s):
                continue
            # Never the primary itself
            if primary_neid_s and neid == primary_neid_s:
                continue
            mgmt = str(dev.get("mgmtIPAddress") or "").strip()
            fallback = str(dev.get("ip") or "").strip()
            ip = mgmt if mgmt else fallback
            if not ip or ip == primary_ip_s or ip in ("0.0.0.0", "-"):
                continue
            parts = ip.split(".")
            if len(parts) != 4:
                continue
            try:
                if not all(0 <= int(p) <= 255 for p in parts):
                    continue
            except (ValueError, TypeError):
                continue
            return ip
        return ""

    def get_down_wan_interfaces(self, wan_data: list) -> list:
        """Return WAN interfaces whose operation-state is not up.

        Fail-safe direction: missing/unknown state is treated as down so a
        problem interface cannot silently pass as up.
        """
        if not isinstance(wan_data, list):
            return []
        down = []
        for i in wan_data:
            if not isinstance(i, dict):
                continue
            state = str(i.get("operation-state", "")).strip().lower()
            if state != "up":
                down.append(i)
        return down

    def was_recent_reboot(self, reboot_history: list, threshold_minutes: int = 120) -> bool:
        """Check if device rebooted within threshold window.

        v27.1 fix: vManage returns `reboot_date_time` in TWO shapes depending
        on version/customer - epoch-milliseconds (int or stringified int)
        AND ISO 8601 (e.g. `2026-10-09T05:40:53+00:00`). Both are now
        accepted. Previously ISO strings fell through to False, which caused
        wawai false-positive auto-close during Oct-09 Viptela→cEdge
        migration (reboot <2h ago but recent_reboot evaluated to False).
        """
        if not isinstance(reboot_history, list) or not reboot_history:
            return False
        threshold_ms = threshold_minutes * 60 * 1000
        now_ms       = int(time.time() * 1000)
        for r in reboot_history:
            if not isinstance(r, dict):
                continue
            raw = r.get("reboot_date_time")
            if raw in (None, ""):
                continue
            ts = self._parse_timestamp_ms(raw)
            if ts and (now_ms - ts) < threshold_ms:
                return True
        return False

    @staticmethod
    def _parse_timestamp_ms(raw):
        """Parse a vManage timestamp value into epoch-milliseconds.

        Accepts:
          * int / float   -> epoch seconds (coerced to ms) or ms
          * numeric str   -> same
          * ISO 8601 str  -> '2026-10-09T05:40:53', '...+00:00', '...Z'
        Returns int ms, or 0 on parse failure.
        """
        if raw is None or raw == "":
            return 0
        # Numeric paths first (fast).
        try:
            ts = int(float(raw))
            if ts and ts < 10_000_000_000:  # seconds → ms
                ts *= 1000
            return ts
        except (ValueError, TypeError):
            pass
        # ISO 8601 fallback.
        try:
            from datetime import datetime, timezone
            s = str(raw).strip()
            if s.endswith("Z"):
                s = s[:-1] + "+00:00"
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return int(dt.timestamp() * 1000)
        except (ValueError, TypeError, ImportError):
            return 0

    # CLI-based TLOC IP parser (MOP [034]-[043])

    def parse_tloc_ips_from_wan_list(self, output: str) -> list:
        """Extract private IPs of UP interfaces from wan-interface-list CLI output."""
        if not isinstance(output, str) or not output.strip():
            return []

        ips: list = []
        for line in output.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            upper = stripped.upper()
            if ("INTERFACE" in upper and "COLOR" in upper) or stripped.startswith("-"):
                continue
            if not re.search(r"\bup\b", stripped, re.IGNORECASE):
                continue
            candidates = re.findall(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", stripped)
            for ip in candidates:
                parts = ip.split(".")
                try:
                    last = int(parts[-1])
                except (ValueError, TypeError):
                    continue
                if last in (0, 255) or ip == "0.0.0.0":
                    continue
                if ip not in ips:
                    ips.append(ip)
                    break
        return ips

    # VRRP / standby VIP parsers (MOP [052]-[055])

    def parse_vrrp_vip_from_cli(self, output: str) -> str:
        """Extract VRRP virtual IP from show vrrp brief/detail output."""
        if not isinstance(output, str) or not output.strip():
            return ""

        for line in output.splitlines():
            if not re.search(r"\b(Master|Backup|Init|MASTER|BACKUP|INIT)\b", line, re.IGNORECASE):
                continue
            candidates = re.findall(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", line)
            for ip in candidates:
                parts = ip.split(".")
                try:
                    last = int(parts[-1])
                except (ValueError, TypeError):
                    continue
                if last not in (0, 255) and ip != "0.0.0.0":
                    return ip
        return ""

    def parse_standby_vip_from_cli(self, output: str) -> str:
        """Extract HSRP standby virtual IP from show standby brief output."""
        if not isinstance(output, str) or not output.strip():
            return ""

        for line in output.splitlines():
            if not re.search(r"\b(Active|Standby|ACTIVE|STANDBY)\b", line, re.IGNORECASE):
                continue
            candidates = re.findall(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", line)
            for ip in candidates:
                parts = ip.split(".")
                try:
                    last = int(parts[-1])
                except (ValueError, TypeError):
                    continue
                if last not in (0, 255) and ip != "0.0.0.0":
                    return ip
        return ""

    # Output formatters

    def format_vmanage_summary(self, data: dict, compact: bool = False) -> str:
        """Format vManage API results into NOC-readable text block."""
        sep   = "=" * 64
        dev   = data.get("device_info", {}) if isinstance(data, dict) else {}

        if compact:
            ctrl = data.get("control_connections", [])
            bfd  = data.get("bfd_sessions", [])
            up   = sum(1 for b in bfd if isinstance(b, dict) and str(b.get("state", "")).lower() == "up")
            return "\n".join([
                sep, "vMANAGE API CROSS-CHECK (summary)", sep,
                "Reachability   : %s" % (dev.get("reachability", "N/A") if isinstance(dev, dict) else "N/A"),
                "Health State   : %s" % (dev.get("state", "N/A") if isinstance(dev, dict) else "N/A"),
                "Control Conns  : %d returned" % len(ctrl),
                "BFD Sessions   : %d/%d up" % (up, len(bfd)),
                "OMP Peers      : %d" % len(data.get("omp_peers", [])),
                "HW Alarms      : %d" % len(data.get("hw_alarms", [])),
                "Active Alarms  : %d" % len(data.get("active_alarms", [])),
                "Control Flaps  : %s | BFD Flaps: %s" % (data.get("control_flap_count", 0),
                                                          data.get("bfd_flap_count", 0)),
                "Recent Reboot  : %s" % data.get("recent_reboot", False),
                sep,
            ])

        lines = [sep, "vMANAGE API DIAGNOSTIC RESULTS", sep]

        if isinstance(dev, dict) and dev:
            lines += [
                f"Hostname           : {dev.get('host-name', 'N/A')}",
                f"System IP          : {dev.get('system-ip', 'N/A')}",
                f"Reachability       : {dev.get('reachability', 'N/A')}",
                f"Health State       : {dev.get('state', 'N/A')}",
                f"Version            : {dev.get('version', 'N/A')}",
                f"BFD Sessions Up    : {dev.get('bfdSessions', 'N/A')}",
                f"Control Conns      : {dev.get('controlConnections', 'N/A')}",
                f"OMP Peers          : {dev.get('ompPeers', 'N/A')}",
                f"Cert Validity      : {dev.get('certificate-validity', 'N/A')}",
            ]

        ctrl = data.get("control_connections", [])
        lines.append(f"\nControl Connections [{len(ctrl)}]:")
        for c in ctrl:
            if isinstance(c, dict):
                lines.append(
                    f"  {c.get('peer-type',''):<10} | {c.get('local-color',''):<16} | "
                    f"state={c.get('state','')} | uptime={c.get('uptime','N/A')}"
                )

        wan = data.get("wan_interfaces", [])
        lines.append(f"\nWAN/TLOC Interfaces [{len(wan)}]:")
        for w in wan:
            if isinstance(w, dict):
                lines.append(
                    f"  {w.get('interface',''):<22} | color={w.get('color',''):<15} | "
                    f"admin={w.get('admin-state','')} | oper={w.get('operation-state','')}"
                )

        bfd    = data.get("bfd_sessions", [])
        bfd_up = sum(1 for b in bfd if isinstance(b, dict) and str(b.get("state", "")).lower() == "up")
        lines.append(f"\nBFD Sessions: {bfd_up}/{len(bfd)} UP")

        omp = data.get("omp_peers", [])
        lines.append(f"\nOMP Peers [{len(omp)}]:")
        for p in omp:
            if isinstance(p, dict):
                lines.append(
                    f"  {p.get('peer',''):<16} type={p.get('type','')} | "
                    f"state={p.get('state','')} | uptime={p.get('up-time','N/A')}"
                )

        reboots = data.get("reboot_history", [])
        if reboots:
            recent = reboots[-3:]
            lines.append(f"\nReboot History (last {len(recent)}):")
            for r in recent:
                if isinstance(r, dict):
                    lines.append(
                        f"  {r.get('reboot_date_time', 'N/A')} | "
                        f"reason: {r.get('reboot_reason', 'N/A')}"
                    )

        hw_alarms = data.get("hw_alarms", [])
        lines.append(f"\nHardware Alarms: {len(hw_alarms)}")
        for a in hw_alarms:
            if isinstance(a, dict):
                lines.append(
                    f"  [{a.get('alarm-category','')}] "
                    f"{a.get('alarm-name','')} - {a.get('alarm-description','')}"
                )

        cpu_mem = data.get("cpu_memory", [])
        if cpu_mem:
            latest = cpu_mem[0] if isinstance(cpu_mem[0], dict) else {}

            def _first(d, keys, default="N/A"):
                for k in keys:
                    if d.get(k) not in (None, ""):
                        return d.get(k)
                return default

            cpu_user   = _first(latest, ["cpu_user", "cpuUser", "cpu_user_new"])
            cpu_system = _first(latest, ["cpu_system", "cpuSystem"])
            cpu_idle   = _first(latest, ["cpu_idle", "cpuIdle"])
            load_avg   = _first(latest, ["cpu_min1_avg", "min1_avg", "load_average_1min"])
            mem_total  = _first(latest, ["mem_total", "memTotal", "total_mem"])
            mem_used   = _first(latest, ["mem_used", "memUsed", "used_mem"])
            mem_free   = _first(latest, ["mem_free", "memFree", "free_mem"])

            lines.append(
                f"\nCPU / Memory (latest):"
                f"\n  CPU user/system/idle : {cpu_user} / {cpu_system} / {cpu_idle} %"
                f"\n  Load avg (1 min)     : {load_avg}"
                f"\n  Mem used / free / total : {mem_used} / {mem_free} / {mem_total} kB"
            )

        ctrl_flaps    = data.get("control_flap_count", 0)
        bfd_flaps     = data.get("bfd_flap_count", 0)
        recent_reboot = data.get("recent_reboot", False)
        lines.append(f"\nFlap Detection: ControlFlaps={ctrl_flaps} | BFDFlaps={bfd_flaps}")
        lines.append(f"Recent Reboot (2h): {recent_reboot}")

        active_alarms = data.get("active_alarms", [])
        lines.append(f"\nActive vManage Alarms: {len(active_alarms)}")
        for a in active_alarms[:5]:
            if isinstance(a, dict):
                lines.append(
                    f"  [{a.get('severity','')}] {a.get('rule_name_display','')} "
                    f"(uuid: {a.get('uuid','N/A')})"
                )

        lines.append(sep)
        return "\n".join(lines)

    def format_cli_summary(self, cli_output: dict, total_budget: int = 15000,
                           per_cmd: int = 1600) -> str:
        """Format CLI diagnostics within a character budget."""
        sep = "=" * 64
        lines = [sep, "CLI DIAGNOSTIC RESULTS (device-local)", sep]

        cmd_labels = {
            "system_status":       "System Status",
            "version":             "Version / Uptime",
            "control_connections": "Control Connections",
            "control_history":     "Control Connection History",
            "wan_interface_list":  "WAN Interface List (TLOC)",
            "bfd_sessions":        "BFD Sessions",
            "omp_peers":           "OMP Peers",
            "tunnel_statistics":   "Tunnel Statistics",
            "cert_validity":       "Certificate Validity",
            "cert_installed":      "Certificate Installed",
            "interfaces_desc":     "Interface Descriptions",
            "ip_int_brief":        "IP Interface Brief",
            "reboot_history":      "Reboot History",
            "vrrp":                "VRRP Status",
            "standby":             "HSRP Standby Status",
            "vrf":                 "VRF Table",
            "logging_control":     "System Logs (control events)",
        }

        if not isinstance(cli_output, dict) or not cli_output:
            lines += ["No CLI output collected.", sep]
            return "\n".join(lines)

        try:
            budget = int(total_budget)
            cap = int(per_cmd)
        except (TypeError, ValueError):
            budget, cap = 15000, 1600

        used = sum(len(x) + 1 for x in lines)
        omitted = []

        for key, label in cmd_labels.items():
            output = cli_output.get(key, "")
            if not output or not isinstance(output, str) or not output.strip():
                continue
            body = self.trim_cli_noise(output).strip()
            if len(body) > cap:
                body = body[:cap] + "\n... (command output trimmed)"
            block = "\n--- %s ---\n%s" % (label, body)
            if used + len(block) > budget:
                omitted.append(label)
                continue
            lines.append(block)
            used += len(block)

        if omitted:
            lines.append("\n[omitted for space, available in output.dat]: "
                         + ", ".join(omitted))
        lines.append(sep)
        return "\n".join(lines)


    # ---------------------------------------------------------------
    # v23 NOC-standard output.dat helpers (presentation only).
    # ---------------------------------------------------------------
    def count_real_outputs(self, d) -> int:
        """Count entries in a CLI dict whose value is non-empty, non-error.

        v27.1.6 symmetric fix (Miss B): share the same first-line /
        short-output heuristic as `clean_cli_dict`. The two filters
        operate on the same CLI dict and must agree on what counts as
        a real response - before, this one used substring-anywhere so
        a long `show logging` capture containing %VDAEMON-3-ERROR: was
        counted as "not real" while clean_cli_dict (post-fix) kept it.
        """
        if not isinstance(d, dict):
            return 0
        n = 0
        for v in d.values():
            if v is None:
                continue
            s = str(v).strip()
            if not s:
                continue
            if self._looks_like_device_error(s):
                continue
            n += 1
        return n

    # Shared helper so clean_cli_dict and count_real_outputs can never
    # drift again (recurring bug family in v27.1.5 / v27.1.6).
    # v27.1.34: added "% Bad IP address" as defense-in-depth. The
    # aecom-london-dc1 NOC capture (2026-10-22) showed that this cEdge
    # rejects `screen-length 0` with TWO error lines:
    #   % Bad IP address or host name
    #   % Unknown command or computer name, or unable to find computer address
    # v27.1.29 `_disable_paging` already prevents us from ever sending
    # `screen-length 0` on an IOS-XE device that accepted `terminal
    # length 0`, so this is not reached today. But if a future device
    # splits the two error lines across TCP chunks and only the first
    # arrives, "Unknown command" would be missed. Adding the first-line
    # token here closes that theoretical gap at zero cost.
    _DEVICE_ERROR_TOKENS = (
        "ERROR:", "% Invalid input", "Invalid input detected",
        "Translating ", "Unknown command", "syntax error",
        "% Bad IP address",
    )

    def _looks_like_device_error(self, s: str) -> bool:
        """True when `s` looks like a device-side rejection response.

        A short (< 500 chars) capture is treated as a rejection when any
        of its first 5 lines STARTS WITH one of the error tokens.

        v27.1.7 fix: the previous "first non-empty line only" heuristic
        missed the common cEdge case where the device echoes the command
        before the error, e.g.:
            show sdwan system status                 <- echo (line 1)
                                                     <- whitespace (line 2)
            % Invalid input detected at '^' marker.  <- real error (line 3)
        Prod ticket 2026101406615 (wawai-s08026-vISR - classic IOS-XE
        box, NOT in SD-WAN controller mode) rendered 8 "% Invalid input"
        blocks in DIAGNOSTIC for exactly this reason.
        """
        if not s:
            return False
        if len(s) >= 500:
            return False
        for line in s.splitlines()[:5]:
            stripped = line.strip()
            if not stripped:
                continue
            if any(stripped.startswith(tok) for tok in self._DEVICE_ERROR_TOKENS):
                return True
        return False

    def trim_to_useful(self, text, keyword: str = "", max_lines: int = 60) -> str:
        """Compact a CLI table around a keyword (e.g. the alarmed TLOC color).
        Keeps header line + lines matching keyword + a bounded tail. Never
        trims below max_lines; returns full text when short enough."""
        if text is None:
            return ""
        s = str(text).rstrip()
        lines = s.splitlines()
        if len(lines) <= max_lines:
            return s
        kw = (keyword or "").strip().lower()
        if not kw:
            keep = lines[:max_lines - 2] + ["... [trimmed; full output in Jenkins build log]"]
            return "\n".join(keep)
        header = lines[:4]
        matches = [ln for ln in lines[4:] if kw in ln.lower()]
        if len(matches) + len(header) <= max_lines:
            return "\n".join(header + matches +
                             ["... [trimmed; full output in Jenkins build log]"])
        return "\n".join(header + matches[:max_lines - len(header) - 1] +
                         ["... [trimmed; full output in Jenkins build log]"])

    def last_lines(self, text, n: int = 15) -> str:
        """Return last n lines; useful for history commands."""
        if text is None:
            return ""
        s = str(text).rstrip()
        lines = s.splitlines()
        if len(lines) <= n:
            return s
        return "\n".join(["... [earlier entries trimmed]"] + lines[-n:])

    def mask_gateway_tokens(self, text) -> str:
        """Redact obvious API tokens / bearer / session cookies accidentally
        rendered into a NOC-visible string."""
        if text is None:
            return ""
        s = str(text)
        s = re.sub(r"(?i)(bearer\s+)[A-Za-z0-9._\-]+", r"\1<redacted>", s)
        s = re.sub(r"(?i)(x-xsrf-token\s*[:=]\s*)[A-Za-z0-9._\-]+",
                   r"\1<redacted>", s)
        s = re.sub(r"(?i)(jsessionid\s*=\s*)[A-Za-z0-9]+",
                   r"\1<redacted>", s)
        return s

    def uptime_to_minutes(self, text) -> int:
        """Parse '142 days 11 hrs 06 min 14 sec' or similar into minutes.
        Returns a very large number on unparseable input (so stability-gate
        never blocks a device whose uptime we can't read).
        """
        if text is None or str(text).strip() == "" or str(text).lower() == "unknown":
            return 10**9
        s = str(text).lower()
        total = 0
        for num, unit in re.findall(r"(\d+)\s*(day|hr|hour|min|sec|wk|week|year|yr)s?", s):
            v = int(num)
            if unit.startswith("year") or unit == "yr":
                total += v * 365 * 24 * 60
            elif unit.startswith("wk") or unit.startswith("week"):
                total += v * 7 * 24 * 60
            elif unit.startswith("day"):
                total += v * 24 * 60
            elif unit.startswith("hr") or unit.startswith("hour"):
                total += v * 60
            elif unit.startswith("min"):
                total += v
            elif unit.startswith("sec"):
                total += 0  # ignore sub-minute
        return total if total > 0 else 10**9

    def minutes_since_last_flap(self, events) -> int:
        """From a list of vManage event dicts (each with
        'entry_time' epoch-ms or ISO 8601), return minutes since the newest.
        Returns a very large number when no flap events are present (so the
        stability gate does NOT block a device with a clean history).
        """
        if not isinstance(events, list) or not events:
            return 10**9
        now_s = time.time()
        newest = 0.0
        for e in events:
            if not isinstance(e, dict):
                continue
            t = e.get("entry_time") or e.get("eventTime") or e.get("time")
            if t is None:
                continue
            try:
                if isinstance(t, (int, float)):
                    ts = float(t) / 1000.0 if float(t) > 1e11 else float(t)
                else:
                    # ISO 8601 e.g. 2026-09-29T10:04:39Z
                    import datetime as _dt
                    ts = _dt.datetime.strptime(
                        str(t)[:19].replace("T", " "), "%Y-%m-%d %H:%M:%S"
                    ).timestamp()
                if ts > newest:
                    newest = ts
            except Exception:
                continue
        if newest <= 0:
            return 10**9
        return max(0, int((now_s - newest) / 60.0))

    def build_router_down_npoa(self, facts) -> list:
        """Build the NEXT PLAN OF ACTION bullet list.

        Rules (locked v23):
          - closure_ready=true -> single success line, no filler.
          - closure_ready=false -> only actionable bullets. Each bullet
            names a specific device/IP/threshold/alarm ID; no filler like
            'engage NOC to manual troubleshooting'.
          - Empty list means NOTHING actionable (NPOA stays empty rather
            than being padded).
        """
        f = facts if isinstance(facts, dict) else {}
        neid        = f.get("neid", "") or ""
        mgmt_ip     = f.get("mgmt_ip", "") or ""
        closure     = bool(f.get("closure_ready", False))
        ssh_ok      = bool(f.get("ssh_ok", False))
        ping_ok     = bool(f.get("ping_ok", False))
        vmgr_up     = bool(f.get("vmanage_reachable", False))
        flapping    = bool(f.get("is_flapping", False))
        flap_count  = int(f.get("flap_count", 0) or 0)
        flap_thresh = int(f.get("flap_threshold", 3) or 3)
        alarm_cleared  = bool(f.get("alarm_cleared", False))
        alarms_present = bool(f.get("alarms_present", False))
        subpath     = str(f.get("closure_subpath", "none") or "none")
        alarm_id    = str(f.get("alarm_id", "") or "")
        sec_name    = f.get("secondary_name", "") or ""
        sec_ip      = f.get("secondary_ip", "") or ""
        sec_up      = bool(f.get("secondary_up", False))
        hw_err      = int(f.get("hw_error_count", 0) or 0)
        bullets = []
        if closure:
            if subpath == "cleared":
                tail = "vManage alarm cleared."
            elif subpath == "stale_alarm":
                tail = "No active alarm on vManage (stale alarm - fast close)."
            else:
                tail = "vManage alarm reconciled."
            bullets.append(
                "Device {0} ({1}) is UP and stable, {2} "
                "No manual NOC action required.".format(neid, mgmt_ip, tail)
            )
            return bullets
        vmg_reach = str(f.get("vmanage_reachability", "unknown") or "unknown")
        if not ping_ok and not ssh_ok and vmgr_up:
            if vmg_reach == "unreachable":
                vmg_tail = "vManage confirms reachability=unreachable"
            elif vmg_reach == "reachable":
                vmg_tail = "vManage says reachability=reachable (possible local path block)"
            else:
                vmg_tail = "vManage reachability=unknown"
            bullets.append(
                "Device {0} ({1}) is unreachable (ICMP 100% loss, SSH port 22 closed); {2} - check WAN circuit and site power."
                .format(neid, mgmt_ip, vmg_tail)
            )
        elif not ping_ok and not ssh_ok and not vmgr_up:
            bullets.append(
                "Device {0} ({1}) is unreachable (ICMP 100% loss, SSH port 22 closed) and vManage was not reachable for cross-check - check WAN circuit, site power, and vManage path."
                .format(neid, mgmt_ip)
            )
        elif not ssh_ok and ping_ok:
            bullets.append(
                "Device {0} ({1}) answers ICMP but SSH login failed - verify SSH is enabled "
                "and the service account has permission; otherwise NOC to login with local creds."
                .format(neid, mgmt_ip)
            )
        if sec_ip and sec_up:
            bullets.append(
                "Secondary router {0} ({1}) is UP - site is not fully down; "
                "investigate primary-only outage."
                .format(sec_name or sec_ip, sec_ip)
            )
        if flapping or (flap_count >= flap_thresh):
            bullets.append(
                "{0} control/BFD down events in the window exceed the {1}-event threshold - "
                "possible flapping; review event timestamps in logs before closing."
                .format(flap_count, flap_thresh)
            )
        # Only emit "alarm remains active" when vManage actually has one open.
        # If alarm_uuids was empty (no active alarms matching this device), the
        # ticket is a stale alarm and no "remains active" bullet should appear.
        if alarm_id and alarms_present and not alarm_cleared:
            bullets.append(
                "vManage alarm {0} remains active (not cleared) - verify after the device is restored."
                .format(alarm_id)
            )
        if hw_err > 0:
            bullets.append(
                "Device reports {0} hardware error(s) - NOC to check device health first "
                "(show sdwan hardware / hardware health summary)."
                .format(hw_err)
            )
        return bullets

    def clean_cli_dict(self, d):
        """Drop empty / error / wrong-platform outputs from a CLI dict so the
        NOC-visible view carries only real command output. Dict-in dict-out
        (preserves keys of valid entries only).

        v27.1.6 fix: these device-side error tokens must only count when
        they are the device's RESPONSE to the command - i.e., appear on
        the FIRST non-empty line and the output is short. On a successful
        `show logging`, real log entries legitimately contain substrings
        like "%VDAEMON-3-ERROR:" or "% Invalid input" (user commands that
        the device logged); the old substring-anywhere match dropped the
        entire capture. Prod ticket 2026101405230 (nykbus build 13286)
        rendered without --- logging_last ---, --- cert_status ---,
        --- omp_peers ---, --- control_local_props --- for exactly this
        reason.
        """
        if not isinstance(d, dict):
            return {}
        out = {}
        for k, v in d.items():
            if v is None:
                continue
            s = str(v).strip()
            if not s:
                continue
            # Shared heuristic - see `_looks_like_device_error`. Routing
            # both filters through one helper prevents the two from
            # drifting again (observed drift was Miss B in v27.1.5).
            if self._looks_like_device_error(s):
                continue
            out[k] = v
        return out

    # --- NOC-facing vManage renderers (A+) -----------------------------------
    #
    # These filters turn vManage REST JSON into readable fixed-column tables
    # and single-line summaries for the NOC-facing output.dat. They are the
    # SSH-blocked-path replacement for CLI DIAGNOSTIC content: SD-WAN edges
    # are commonly SSH-restricted by policy, and vManage is the authoritative
    # source. Every renderer tolerates missing keys and empty input.

    @staticmethod
    def _col(val, width: int) -> str:
        s = "" if val is None else str(val)
        if len(s) > width:
            s = s[: max(0, width - 1)] + "+"
        return s.ljust(width)

    def ctrl_summary_line(self, conns) -> str:
        """One-liner summary of control connections for OBSERVATION.

        v27.1.6 rule (NOC-approved): report ONLY the DOWN count if any
        session is DOWN. If every session is UP, report the short
        'all N UP' form. Avoids spamming the OBSERVATION line with UP
        detail that doesn't help NOC triage.
        """
        if not isinstance(conns, list) or not conns:
            return "no control connections reported"
        total = len(conns)
        down_by_type = {"vsmart": 0, "vmanage": 0, "vbond": 0, "other": 0}
        down_total = 0
        for c in conns:
            if not isinstance(c, dict):
                continue
            state = str(c.get("state", "")).strip().lower()
            if state == "up":
                continue
            t = str(c.get("peer-type", "")).strip().lower()
            down_by_type[t if t in down_by_type else "other"] += 1
            down_total += 1
        if down_total == 0:
            return "all {t} control connections UP".format(t=total)
        parts = []
        for k in ("vsmart", "vmanage", "vbond", "other"):
            if down_by_type[k]:
                parts.append("{n} {k}".format(n=down_by_type[k], k=k))
        return ("{dn} of {tot} control connections DOWN ({parts})"
                .format(dn=down_total, tot=total, parts=", ".join(parts)))

    def bfd_summary_line(self, sessions) -> str:
        """One-liner for BFD session state across TLOCs.

        v27.1.6 rule (NOC-approved): if any session is DOWN, report only
        the DOWN count. If every session is UP, report the short
        'all N UP' form. See ctrl_summary_line for the rationale.
        """
        if not isinstance(sessions, list) or not sessions:
            return "no BFD sessions reported"
        total = len(sessions)
        down = sum(1 for s in sessions
                   if isinstance(s, dict)
                   and str(s.get("state", "")).strip().lower() != "up")
        if down == 0:
            return "all {t} BFD session(s) UP".format(t=total)
        return "{dn} of {tot} BFD session(s) DOWN".format(
            dn=down, tot=total)

    def omp_summary_line(self, peers) -> str:
        """One-liner for OMP peering state.

        v27.1.6 rule (NOC-approved): same DOWN-only treatment as
        ctrl / bfd summaries.
        """
        if not isinstance(peers, list) or not peers:
            return "no OMP peers reported"
        total = len(peers)
        down = sum(1 for p in peers
                   if isinstance(p, dict)
                   and str(p.get("state", "")).strip().lower() != "up")
        if down == 0:
            return "all {t} OMP peer(s) UP".format(t=total)
        return "OMP peering: {dn} of {tot} peer(s) DOWN".format(
            dn=down, tot=total)

    # v27.1.6 symmetric fix: the three vManage-fallback table renderers
    # below were dumping ALL rows, same bug class as Miss A (DOWN-only
    # rule applied on the CLI side but not here). On a healthy SSH-blocked
    # site with 20+ TLOCs the NOC saw a wall of UP rows. Now mirror the
    # DOWN-only / "all N UP; showing 5" rule used by table_down_or_topn_up.

    @staticmethod
    def _row_is_down(entry):
        """Return True when a vManage REST entry's state is not UP (case-
        insensitive). Treats missing / empty state as 'unknown' = not-up
        so the NOC sees it rather than silently suppressing it.
        """
        if not isinstance(entry, dict):
            return False
        return str(entry.get("state", "")).strip().lower() != "up"

    def _render_vmanage_table(self, items, hdr_specs, row_fn, top_n_up=5):
        """Shared renderer: emit header + DOWN rows if any; otherwise
        header + top-N UP rows + 'all N UP; showing N' footer.
        `hdr_specs` is a tuple of (label, width); `row_fn(item)` returns
        a tuple of column values matching hdr_specs.
        """
        if not isinstance(items, list) or not items:
            return "(no rows)"
        header_cells = tuple(self._col(h[0], h[1]) for h in hdr_specs)
        rows = [header_cells]
        total = 0
        down_items, up_items = [], []
        for it in items:
            if not isinstance(it, dict):
                continue
            total += 1
            (down_items if self._row_is_down(it) else up_items).append(it)
        if down_items:
            emitted = down_items
            prefix = "({d} of {t} row(s) DOWN)".format(d=len(down_items), t=total)
        else:
            emitted = up_items[:top_n_up]
            prefix = "(all {t} row(s) UP; showing first {n} for sanity)".format(
                t=total, n=len(emitted))
        for it in emitted:
            vals = row_fn(it)
            rows.append(tuple(
                self._col(vals[i], hdr_specs[i][1]) for i in range(len(hdr_specs))))
        body = "\n".join("  ".join(r) for r in rows)
        return prefix + "\n" + body

    def vmanage_ctrl_table(self, conns) -> str:
        """Readable control-connections table - DOWN-only or top-5 UP."""
        hdr = (("peer-type", 10), ("peer-system-ip", 16), ("state", 7),
               ("uptime", 14), ("private-ip", 18))
        def row(c):
            return (c.get("peer-type", "-"),
                    c.get("peer-system-ip", "-"),
                    c.get("state", "-"),
                    c.get("uptime", "-"),
                    c.get("private-ip", c.get("local-color", "-")))
        return self._render_vmanage_table(conns, hdr, row, top_n_up=5)

    def vmanage_bfd_table(self, sessions) -> str:
        """Readable BFD-sessions table - DOWN-only or top-5 UP."""
        hdr = (("peer-system-ip", 16), ("proto", 6), ("local-color", 14),
               ("remote-color", 14), ("state", 7), ("uptime", 14))
        def row(s):
            return (s.get("system-ip", s.get("src-ip", "-")),
                    s.get("proto", "ipsec"),
                    s.get("local-color", "-"),
                    s.get("color", s.get("remote-color", "-")),
                    s.get("state", "-"),
                    s.get("uptime", "-"))
        return self._render_vmanage_table(sessions, hdr, row, top_n_up=5)

    def vmanage_omp_table(self, peers) -> str:
        """Readable OMP-peers table - DOWN-only or top-5 UP."""
        hdr = (("peer-system-ip", 16), ("type", 8), ("state", 7),
               ("up-count", 10), ("down-count", 10))
        def row(p):
            return (p.get("peer", p.get("peer-system-ip", "-")),
                    p.get("type", "vsmart"),
                    p.get("state", "-"),
                    p.get("up-count", "-"),
                    p.get("down-count", "-"))
        return self._render_vmanage_table(peers, hdr, row, top_n_up=5)

    def vmanage_down_intfs_table(self, interfaces) -> str:
        """Readable table of interfaces whose operational state is NOT up.
        Returns '(all interfaces up)' when nothing is down.
        """
        if not isinstance(interfaces, list) or not interfaces:
            return "(no interface data)"
        down_rows = []
        for i in interfaces:
            if not isinstance(i, dict):
                continue
            oper = str(i.get("if-oper-status", i.get("oper-status", ""))).strip().lower()
            if oper and oper not in ("up", "ready", "lower-layer-down-up"):
                down_rows.append(i)
        if not down_rows:
            return "(all interfaces up)"
        hdr = ("if-name", "admin", "oper", "vpn", "ipv4")
        out = [(self._col(hdr[0], 20), self._col(hdr[1], 7),
                self._col(hdr[2], 7),  self._col(hdr[3], 4),
                self._col(hdr[4], 20))]
        for i in down_rows[:12]:  # keep NOC view short
            out.append((
                self._col(i.get("ifname", i.get("if-name", "-")), 20),
                self._col(i.get("if-admin-status", i.get("admin-status", "-")), 7),
                self._col(i.get("if-oper-status", i.get("oper-status", "-")), 7),
                self._col(i.get("vpn-id", i.get("vpn", "-")), 4),
                self._col(i.get("ip-address", i.get("ipv4", "-")), 20),
            ))
        return "\n".join("  ".join(r) for r in out)

    def vmanage_cpu_mem_line(self, stats) -> str:
        """One-liner for CPU and memory from /device/system/status."""
        if not isinstance(stats, list) or not stats:
            return "cpu/memory not reported"
        row = next((s for s in stats if isinstance(s, dict)), {})
        cpu = row.get("cpu_user", row.get("cpu-user", row.get("cpu_1min", "?")))
        mem_used = row.get("mem_used", row.get("mem-used", "?"))
        mem_total = row.get("mem_total", row.get("mem-total", "?"))
        try:
            pct = int(round(float(mem_used) * 100.0 / float(mem_total)))
            mem = "{p}% ({u}/{t})".format(p=pct, u=mem_used, t=mem_total)
        except (TypeError, ValueError, ZeroDivisionError):
            mem = str(mem_used)
        return "CPU {c}%, memory {m}".format(c=cpu, m=mem)

    def vmanage_last_reboot_line(self, history) -> str:
        """One-liner for the most recent reboot."""
        if not isinstance(history, list) or not history:
            return "no reboot history recorded"
        row = history[0] if isinstance(history[0], dict) else {}
        when = row.get("reboot_date_time", row.get("time", "?"))
        reason = row.get("reboot_reason", row.get("reason", "unknown"))
        return "last reboot {w} - reason: {r}".format(w=when, r=reason)

    def vmanage_hw_alarm_line(self, alarms) -> str:
        """One-liner for hardware alarms."""
        if not isinstance(alarms, list) or not alarms:
            return "no hardware alarms"
        severities = {}
        for a in alarms:
            if not isinstance(a, dict):
                continue
            sev = str(a.get("severity", "")).strip().lower() or "unknown"
            severities[sev] = severities.get(sev, 0) + 1
        parts = ["{n} {s}".format(n=n, s=s) for s, n in sorted(severities.items())]
        return "{tot} hardware alarm(s): {detail}".format(
            tot=len(alarms), detail=", ".join(parts) or "unspecified")

    # ------------------------------------------------------------------
    # v27.1.3: CLI fallbacks for uptime, CPU/memory, last reboot.
    #
    # NOC feedback on auto-closed ticket 2026101302318 (aecom-london-DC,
    # Platform CEDGE, SSH ok): OBSERVATION rendered
    #   "uptime is unknown"
    #   "cpu/memory not reported, no reboot history recorded"
    # even though the DIAGNOSTIC block in the same ticket clearly showed
    # the data from `show version` and `show sdwan system status`. Root
    # cause: `device_uptime` was referenced in write_output.yaml:159 but
    # never set by any task, and vmanage_cpu_mem_line / vmanage_last_reboot_line
    # had no CLI fallback - they returned the "not reported" literal when
    # vManage's /device/system/status or /reboothistory returned empty.
    #
    # These three parsers run against `cli_output` (the SSH-captured dict).
    # They are intentionally forgiving: each returns the vendor-neutral
    # "unknown"/"not reported" string when nothing parseable is found, so
    # downstream rendering never raises. CEDGE and VEDGE idioms are
    # handled in the same regex set.
    # ------------------------------------------------------------------

    _UPTIME_PATTERNS = (
        # cEdge: "aecom-london-dc1-23860719 uptime is 4 weeks, 2 days, 10 hours, 40 minutes"
        re.compile(r"uptime\s+is\s+([^\r\n]+?)(?:\r|\n|$)", re.IGNORECASE),
        # cEdge `show sdwan system status`: "System uptime: 4 days, 03:34:21"
        re.compile(r"system\s+uptime[:\s]+([^\r\n]+?)(?:\r|\n|$)", re.IGNORECASE),
        # vEdge `show system status`: "System uptime 14 days 03 hrs 34 min"
        re.compile(r"System\s+uptime\s+([0-9][^\r\n]+?)(?:\r|\n|$)", re.IGNORECASE),
        # v27.1.21 NOC comment 1 (aecom TASK7069166): some tenants'
        # classic IOS-XE routers only emit "Last reload" or
        # "System restarted at" without an "uptime is" line - add a
        # defensive pattern. The value here is the restart timestamp,
        # not a duration, but NOC still gets a real anchor instead of
        # "unknown".
        re.compile(r"System\s+restarted\s+at\s+([^\r\n]+?)(?:\r|\n|$)", re.IGNORECASE),
        re.compile(r"Last\s+reload[^:]*:\s*([^\r\n]+?)(?:\r|\n|$)", re.IGNORECASE),
    )

    # v27.1.26 REGRESSION FIX (Oct-9 source verified).
    # Oct-9 used `show version | include uptime|System|returned|reload|image`
    # (5 alternations). v27.1.17 "GAP-A" collapsed this to 4 alternations
    # (`uptime|System returned|reload|image`), dropping the "Systems"
    # substring match that pulled in the Copyright lines, and on some
    # Oct-19 wawai cEdges returned empty body entirely.
    # Fix: collect plain `show version` and filter in Python here —
    # deterministic across every IOS-XE build.
    # Keeps MOP step 58's six anchor lines: Cisco IOS version header,
    # Copyright, "uptime is", "System returned to ROM", image file,
    # last reload reason. Any match in the first 60 non-empty lines of
    # show version is retained in capture order (never shuffled).
    _VERSION_KEEP_PATTERNS = (
        re.compile(r"Cisco\s+IOS[- ]XE\s+Software", re.IGNORECASE),
        re.compile(r"Cisco\s+IOS\s+Software", re.IGNORECASE),
        re.compile(r"Copyright\s*\(c\)", re.IGNORECASE),
        re.compile(r"\buptime\s+is\b", re.IGNORECASE),
        re.compile(r"System\s+returned\s+to\s+ROM", re.IGNORECASE),
        re.compile(r"System\s+restarted\s+at", re.IGNORECASE),
        re.compile(r"System\s+image\s+file\s+is", re.IGNORECASE),
        re.compile(r"Last\s+reload", re.IGNORECASE),
        # vEdge (Viptela OS) `show version` is a single-line like
        # "20.6.5.2" with no uptime context — we keep it verbatim.
        re.compile(r"^\s*(\d+\.\d+\.\d+)", re.IGNORECASE),
    )

    def cli_version_filter(self, text) -> str:
        """Keep only MOP step 58 anchor lines from a `show version` capture.

        v27.1.26: replaces the IOS-XE `| include ...` pipe filter whose
        v27.1.17 "GAP-A" form returned empty body on some wawai cEdges.
        Full show-version comes in; up to 8 MOP-anchor lines come out,
        in the order they appeared in the device output. Preserves line
        order so downstream parse_cli_uptime (which keys on the
        "uptime is" line's position) is unaffected.

        Defensive: non-string / empty / None input returns ''.
        """
        if not isinstance(text, str) or not text.strip():
            return ""
        kept = []
        # Scan at most the first 60 non-empty lines — show version on IOS-XE
        # is ~80-120 lines total; everything after the first ~60 is module
        # inventory noise. Hard cap on OUTPUT size: 8 lines (MOP has 6, we
        # allow 2 for duplicate "Cisco IOS Software" lines on dual-image).
        seen = 0
        for raw in text.splitlines():
            line = raw.rstrip()
            if not line.strip():
                continue
            seen += 1
            if seen > 60:
                break
            for pat in self._VERSION_KEEP_PATTERNS:
                if pat.search(line):
                    kept.append(line)
                    break
            if len(kept) >= 8:
                break
        if not kept:
            # Last-resort fallback: keep the first non-empty data line so
            # the DIAG section is not blank. Better a weak anchor than
            # "(no output)" when the device clearly answered the command.
            for raw in text.splitlines():
                if raw.strip():
                    return raw.rstrip()
            return ""
        return "\n".join(kept)

    def safe_truncate_at_line(self, text, max_chars=23000):
        """v27.1.32: truncate text so it fits within `max_chars` AND
        ends at a complete-line boundary.

        Fixes the "mid-line concatenation glitch" seen on Jenkins build
        14966 (hersel-aspen) where the response_msg was sliced at an
        arbitrary character inside a syslog line ("...system-ip:172")
        and the master template's "Clean and Append Engage NOC message"
        task then appended "Engage NOC to manual troubleshooting and
        customer update." directly after the sliced-mid-line point,
        producing an unreadable concatenation. The old main.yaml form
            response_msg: (content | b64decode)[:budget - 2] ~ '\\n\\n'
        used a hard byte slice and relied on the appended "\\n\\n" to
        separate — but when the master template strips trailing
        whitespace before appending its trailer, the "\\n\\n" is lost
        and the mid-line cut becomes visible.

        This filter guarantees the slice ends at the LAST newline
        inside the budget. If the input is already shorter than the
        budget, it is returned unchanged (with a trailing newline added
        if missing, so downstream appends still land on their own line).

        Defensive: non-string input returns ''; max_chars under 500 is
        clamped to 500 so the AVA tag (first ~2 KB) is never cut.
        """
        if not isinstance(text, str) or not text:
            return ""
        try:
            budget = max(500, int(max_chars))
        except (TypeError, ValueError):
            budget = 23000
        if len(text) <= budget:
            # Short enough as-is. Ensure it ends with a newline so any
            # downstream append lands cleanly on its own line.
            if text.endswith("\n"):
                return text
            return text + "\n"
        # Need to truncate. Prefer the LAST newline inside the budget
        # so we end on a complete line. On real response_msg content
        # (prod and SIT) this always finds a newline near the budget
        # boundary — the DIAG section emits a header + body + blank
        # line per section, so any 23000-char slice has hundreds of
        # newlines inside. The soft floor `last_nl > budget // 10`
        # protects against degenerate inputs where the AVA tag at the
        # top is somehow glued into one huge line.
        slice_ = text[:budget]
        last_nl = slice_.rfind("\n")
        if last_nl > 0 and last_nl > budget // 10:
            # Found a late-enough newline — cut there, add a visible
            # marker so NOC knows DIAG was trimmed.
            trimmed = slice_[:last_nl].rstrip()
            return (trimmed
                    + "\n... [DIAG truncated to fit response-msg budget]\n")
        # No usable newline — the content was single-line garbage, or
        # the AVA block runs past the budget. Fall back to a plain hard
        # cut but still append a newline so the master-template trailer
        # doesn't glue onto the last char.
        return slice_.rstrip() + "\n... [DIAG hard-truncated]\n"

    # v27.1.36 — pre-SSH platform hint from vManage.
    _CEDGE_MODEL_PREFIXES = ("c8", "c11", "c83", "c85", "c89", "isr4", "asr")
    _VEDGE_HARDWARE_MODELS = frozenset((
        "vedge-cloud", "vedge-5000", "vedge-2000",
        "vedge-1000", "vedge-100",
    ))

    def derive_platform_from_vmanage(self, vmanage_device_info):
        """Return 'cedge' | 'vedge' | '' from a vManage device-row dict.

        Same logic as device_ssh.yaml task 4045 but reusable as a Jinja
        filter earlier in the role, BEFORE the first SSH connection, so
        the viptela_ssh.py script can be invoked with --platform <hint>
        and skip in-session platform detection on the hot path.

        Decision order (same as task 4045):
          1. version prefix 16.x / 17.x  -> cedge  (IOS-XE SD-WAN)
          2. version prefix 18.x - 22.x  -> vedge  (Viptela OS)
          3. device-model prefix: c8*, c11*, c83*, c85*, c89*, isr4*,
             asr*  -> cedge
          4. device-model exact: vedge-cloud, vedge-5000, vedge-2000,
             vedge-1000, vedge-100  -> vedge
          5. device-model prefix: vedge-isr1100  -> vedge
          6. anything else  -> ""  (unknown; caller falls back to the
             in-session detect_platform() probe)

        vManage's own `device-type` field is always "vedge" regardless
        of underlying OS and `personality` is identical both platforms,
        so neither is usable here. `version` is the primary signal;
        `device-model` is secondary. Note: a CSR1000v running IOS-XE
        SD-WAN carries device-model "vedge-CSR-1000v" (literal
        substring 'vedge' on a cedge device), which is why version is
        checked FIRST.

        Defensive: non-dict input returns "".
        """
        if not isinstance(vmanage_device_info, dict):
            return ""
        ver   = str(vmanage_device_info.get("version", "") or "").strip()
        model = str(vmanage_device_info.get("device-model", "") or "").strip().lower()
        # 1. Version-prefix: cedge (IOS-XE)
        if ver.startswith(("17.", "16.")):
            return "cedge"
        # 2. Version-prefix: vedge (Viptela OS)
        if ver[:3] in ("18.", "19.", "20.", "21.", "22."):
            return "vedge"
        # 3. Model-prefix: cedge
        if any(model.startswith(p) for p in self._CEDGE_MODEL_PREFIXES):
            return "cedge"
        # 4. Model-exact: vedge hardware/cloud
        if model in self._VEDGE_HARDWARE_MODELS:
            return "vedge"
        # 5. Model-prefix: vedge-isr1100 (vEdge-badged ISR)
        if model.startswith("vedge-isr1100"):
            return "vedge"
        return ""

    # v27.1.36 — post-reload grace gate.
    #
    # Rationale (SIT 1150 + prod ticket 2026102300580 unitedbank-
    # kernstown build 15154): on a device that has just cold-booted,
    # SD-WAN daemon takes several minutes to converge. During that
    # window `show sdwan X` can return `% Invalid input` even on a
    # legitimate IOS-XE SD-WAN cEdge, because the vdaemon has not yet
    # loaded. detect_device_mode() classifies this as "autonomous" and
    # the role currently auto-closes the alarm based on SSH + ICMP
    # alone. NOC asked us to NOT auto-close in that case; route to NOC
    # Review so an operator confirms the device is really SD-WAN once
    # convergence completes.
    #
    # Grace windows (empirical from Cisco TAC public guidance and
    # field observation):
    #   cEdge  (IOS-XE SD-WAN): 15 min from first SSH prompt to
    #          "System state: GREEN. All daemons up"
    #   vEdge  (Viptela OS):    10 min, faster userspace
    _GRACE_MINUTES = {"cedge": 15, "vedge": 10}

    def is_post_reload_grace(self, uptime_str, platform, device_mode=""):
        """Return True when (uptime < per-platform grace window) AND
        the device looks like it is still converging post-reload.

        Called from main.yaml after SSH collection; if True, the
        closure gate (`closure_ready`) is forced False and the verdict
        becomes DEFER_FOR_NOC_REVIEW instead of auto-UP.

        Inputs:
          uptime_str   -- human-readable uptime string from CLI, same
                          form parse_cli_uptime returns ("46 minutes",
                          "5 weeks, 3 days, 7 hours, 11 minutes",
                          "0 days 00 hrs 46 min 28 sec").
          platform     -- 'cedge' | 'vedge' | other
          device_mode  -- optional; when 'autonomous' AND platform
                          hint says cedge the grace defer applies
                          more aggressively (that is the exact
                          post-reload-not-converged signature).

        Returns False for unknown platforms, missing uptime, or any
        uptime at or above the grace window. Never raises.
        """
        if not uptime_str or not platform:
            return False
        plat = str(platform).strip().lower()
        if plat not in self._GRACE_MINUTES:
            return False
        total_min = self._parse_uptime_minutes(uptime_str)
        if total_min is None:
            return False
        return total_min < self._GRACE_MINUTES[plat]

    @staticmethod
    def _parse_uptime_minutes(uptime_str):
        """Parse an uptime string into total minutes. Returns None on
        unparseable input, else int minutes.

        Handles the three common Cisco wordings:
          IOS-XE classic:  "46 minutes" / "5 weeks, 3 days, 7 hours"
          IOS-XE SD-WAN:   "46 minutes" / "7 weeks, 2 days, 4 hours, 58 minutes"
          Viptela OS:      "0 days 00 hrs 46 min 28 sec" /
                           "55 days 23 hrs 22 min 32 sec"
        """
        if not uptime_str:
            return None
        s = str(uptime_str).lower()
        total = 0
        found_any = False
        # Weeks
        m = re.search(r"(\d+)\s*week", s)
        if m:
            total += int(m.group(1)) * 7 * 24 * 60; found_any = True
        # Days
        m = re.search(r"(\d+)\s*day", s)
        if m:
            total += int(m.group(1)) * 24 * 60; found_any = True
        # Hours (both "hours" and "hrs")
        m = re.search(r"(\d+)\s*(?:hour|hr)", s)
        if m:
            total += int(m.group(1)) * 60; found_any = True
        # Minutes. Match "N minute(s)" AND "N min" (the Viptela OS short
        # form uses "min"; IOS-XE classic uses "minute(s)"). The leading
        # `\d+\s*` plus the `min` prefix is enough; the trailing word is
        # optional, which also keeps us from double-counting a "min sec"
        # pair since we only sum the first match.
        m = re.search(r"(\d+)\s*minute|(\d+)\s*min(?!\w)", s)
        if m:
            v = next(g for g in m.groups() if g is not None)
            total += int(v); found_any = True
        return total if found_any else None

    def cert_installed_summary(self, text):
        """v27.1.35: condense `show sdwan certificate installed` to the
        three lines NOC actually reads for a Device-Down ticket:
            Issuer:   <CA that issued the device cert>
            Subject:  <PID:... SN:... — chassis / serial correlation>
            Validity: <Not Before> -> <Not After>

        Rationale (aecom-london-dc1 NOC capture, 2026-10-22). The raw
        `show sdwan certificate installed` output on IOS-XE 17.12.x
        cEdges is a 70-line X.509 dump: 16 lines of RSA modulus hex,
        14 lines of signature hex, X509v3 extension blobs, authority
        key identifier bytes. NOC does not use the modulus hex or
        signature hex to triage a Device-Down ticket — they use three
        facts:
          1. Is the cert still valid? -> Not Before / Not After dates
          2. Who issued it? -> Issuer line
          3. Does the chassis / serial match ESP inventory? -> Subject
        This filter extracts those three lines. If any one is missing
        in the capture (older IOS-XE build with a different cert
        format, truncated output, device returned the empty
        "Installed device certificates" placeholder), the filter
        still returns the lines it found. If NONE match, it returns
        the original text up to the filter's hard cap so NOC can at
        least see what the device sent — safer than returning empty.

        vEdge path (Viptela OS `show certificate installed`) emits a
        similar but shorter form. Same extraction regexes work because
        both forms use the OpenSSL text-dump conventions (`Issuer:`,
        `Subject:`, `Not Before:`, `Not After :`).

        Defensive: None / empty input returns an empty string.
        """
        if not isinstance(text, str) or not text.strip():
            return ""
        # OpenSSL text-dump line forms, same on cEdge + vEdge.
        issuer_re  = re.compile(r"^\s*Issuer\s*:\s*(.+?)\s*$",  re.MULTILINE)
        subject_re = re.compile(r"^\s*Subject\s*:\s*(.+?)\s*$", re.MULTILINE)
        nbf_re     = re.compile(r"^\s*Not Before\s*:\s*(.+?)\s*$", re.MULTILINE)
        naf_re     = re.compile(r"^\s*Not After\s*:\s*(.+?)\s*$",  re.MULTILINE)

        m_issuer  = issuer_re.search(text)
        m_subject = subject_re.search(text)
        m_nbf     = nbf_re.search(text)
        m_naf     = naf_re.search(text)

        lines = []
        if m_issuer:
            # Keep issuer short — strip anything past the first comma
            # pair would be too aggressive (removes O=Cisco); keep full
            # but cap length so a pathological cert can't blow DIAG.
            issuer_val = m_issuer.group(1).strip()[:160]
            lines.append("Issuer:  " + issuer_val)
        if m_subject:
            subject_val = m_subject.group(1).strip()[:160]
            lines.append("Subject: " + subject_val)
        if m_nbf and m_naf:
            nbf_val = m_nbf.group(1).strip()[:60]
            naf_val = m_naf.group(1).strip()[:60]
            lines.append("Validity: " + nbf_val + " -> " + naf_val)
        elif m_nbf:
            lines.append("Validity (start only): " + m_nbf.group(1).strip()[:60])
        elif m_naf:
            lines.append("Validity (end only): " + m_naf.group(1).strip()[:60])

        if lines:
            return "\n".join(lines)
        # Last-resort fallback — return first 10 non-empty lines so NOC
        # at least sees SOMETHING on an unexpected cert format, bounded
        # so a pathological capture cannot bloat DIAG. Never return the
        # 70-line raw dump.
        tail = [ln for ln in text.splitlines() if ln.strip()][:10]
        return "\n".join(tail) if tail else "(cert format not recognized)"

    def strip_control_history_legend(self, text):
        """v27.1.35: strip the `Legend for Errors` definition block that
        both Viptela OS and IOS-XE SD-WAN prepend to `show control
        connection-history` / `show sdwan control connection-history`.

        Why this filter exists. The device CLI output always begins with:
            Legend for Errors
            ACSRREJ    - Challenge rejected by peer.    NOVMCFG   - ...
            BDSGVERFL  - Board ID Signature Verify ...  NOZTPEN   - ...
            ... ~28 more rows of two-column abbreviation glossary ...
            EMBARGOFAIL - Embargo check failed
            <blank line>
            <column headers>
            <peer table rows: vbond / vsmart / vmanage>
        The glossary is ~30 lines of text that NOC does NOT read — they
        read the actual teardown/reconnect rows. v27.1.35 SIT 1149
        (deapega) confirmed this: on primary, reboot_history_topn's
        3-header + 7-data cap was fully consumed by legend lines so the
        real peer table never rendered. On partner, trim_to_useful('',
        60) dumped the full legend ahead of 6 real rows that NOC had
        to scroll past.

        Strip rule. If the text contains a line that STARTS WITH
        "Legend for Errors" (case-sensitive — device output is always
        this exact form on both platforms), discard everything from that
        line up to AND INCLUDING the first subsequent blank line. Keep
        everything after. If no "Legend for Errors" line is found,
        return the text unchanged (defensive: future device builds
        might change the preamble format).

        Safe on empty / None input (returns the empty string / original).
        """
        if not isinstance(text, str) or not text.strip():
            return text if isinstance(text, str) else ""
        lines = text.splitlines()
        try:
            start_idx = next(
                i for i, ln in enumerate(lines)
                if ln.lstrip().startswith("Legend for Errors")
            )
        except StopIteration:
            # No legend marker — nothing to strip.
            return text
        # Walk forward to the first blank line after the legend start.
        # Cap the walk at 80 lines so a malformed capture cannot eat
        # the whole output.
        end_idx = start_idx
        for i in range(start_idx + 1, min(len(lines), start_idx + 80)):
            if not lines[i].strip():
                end_idx = i
                break
        else:
            # No blank-line terminator found within 80 lines — safer to
            # leave the text unchanged than to swallow the peer table.
            return text
        # Drop lines[start_idx .. end_idx] inclusive.
        remaining = lines[end_idx + 1:]
        return "\n".join(remaining)

    def tail_lines(self, text, n=30):
        """v27.1.21 NOC comment 6 (admco TASK7050757): return the last `n`
        lines of a raw text blob, unfiltered. Used for the
        `--- logging_last_raw ---` sub-section so NOC can see unfiltered
        syslog tail alongside the ticket-anchored window. Defensive.

        v27.1.29: on vEdge where `show log | nomore` returns only the
        logging-configuration banner (lines like "System logging to disk
        is enabled", "Priority for host logging is set to: emerg", etc.)
        with no actual syslog entries, we emit a single clear note
        instead of 11 lines of config settings. NOC asked for raw
        syslog, not for a repeat of the logging config block they can
        already see in system_status. Detection rule: ALL tail lines
        are config-banner lines AND NONE carry a syslog timestamp."""
        if not isinstance(text, str) or not text.strip():
            return "(no raw log captured)"
        try:
            cap = max(1, int(n))
        except (TypeError, ValueError):
            cap = 30
        lines = text.splitlines()
        tail = lines[-cap:] if len(lines) > cap else lines

        # v27.1.29 config-banner detector. Config-banner lines on
        # Viptela OS are things like:
        #   "System logging to host  in vpn 0 is disabled"
        #   "Priority for host logging is set to: emerg"
        #   "File name for disk logging is set to:  /var/log/vsyslog"
        #   "Syslog facility is set to: all facilities"
        # They never carry a syslog timestamp. A real log line always
        # has one of:
        #   "YYYY-MM-DDTHH:MM:SS"           (ISO 8601, vEdge)
        #   "Mon DD HH:MM:SS"               (classic syslog)
        #   "*Mon DD HH:MM:SS.mmm:"         (IOS-XE)
        banner_markers = (
            "logging to host", "logging to disk", "priority for ",
            "file name for ", "file size for ", "file recycle",
            "syslog facility", "is enabled", "is disabled",
            "is set to", "System logging", "Priority for",
        )
        ts_patterns = (
            re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}"),
            re.compile(r"\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}"),
            re.compile(r"\*(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}"),
        )
        non_empty_tail = [ln for ln in tail if ln.strip()]
        if non_empty_tail:
            has_any_timestamp = any(
                any(p.search(ln) for p in ts_patterns) for ln in non_empty_tail
            )
            all_banner = all(
                any(m.lower() in ln.lower() for m in banner_markers)
                for ln in non_empty_tail
            )
            if (not has_any_timestamp) and all_banner:
                return ("(device returned only the logging-config banner; "
                        "no syslog entries on the device within the "
                        "collection window — see system_status for current "
                        "logging configuration)")

        return "\n".join(tail)

    def wan_intf_down_summary(self, vmanage_wan_interfaces):
        """v27.1.21 NOC comment 5 (admco TLOC bounced on e010): produce a
        short NOC-visible line about WAN interface state when any are
        not UP. Returns '' when all UP or data empty.

        vmanage_wan_interfaces is the JSON list from
        /dataservice/device/control/wan/interfaces or similar.
        Each entry typically has 'interface' / 'admin-state' /
        'oper-state' / 'last-updated' fields; shape varies by API."""
        if not isinstance(vmanage_wan_interfaces, list) or not vmanage_wan_interfaces:
            return ""
        bad = []
        for entry in vmanage_wan_interfaces[:50]:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("interface", "") or entry.get("ifname", "")
                       or entry.get("interfaceName", "")).strip()
            oper = str(entry.get("oper-state", "") or entry.get("operState", "")
                       or entry.get("if-oper-status", "")).strip().lower()
            admin = str(entry.get("admin-state", "") or entry.get("adminState", "")
                        or entry.get("if-admin-status", "")).strip().lower()
            # Treat empty operstate as unknown (don't flag); flag only
            # explicit non-up.
            if oper and oper not in ("up", "operational"):
                bad.append("{n}=oper:{o}/admin:{a}".format(
                    n=name or "unknown", o=oper, a=admin or "?"))
        if not bad:
            return ""
        return ("{n} WAN interface(s) not UP: ".format(n=len(bad)) +
                "; ".join(bad[:5]) +
                (" (+{more} more)".format(more=len(bad) - 5) if len(bad) > 5 else ""))

    def alarm_clear_outcome_line(self, alarm_uuids, alarm_cleared,
                                 alarm_clear_summary, alarm_state_unknown,
                                 vmanage_available):
        """v27.1.21 NOC comment 3 (aecom TASK7069166 - alarm visibility):
        single-line summary of the vManage alarm-clear outcome, so NOC
        can see at a glance whether iAutomate attempted the clear and
        with what result. Returns a short string suitable for an NPOA
        bullet.

        Classifies into one of five states:
          - "no vManage alarms matched this device"
          - "N UUID(s) cleared successfully"
          - "N UUID(s): clear sent but confirm still shows active"
          - "N UUID(s): clear not attempted - alarm state unknown"
          - "N UUID(s): clear not attempted - vManage unavailable"
        """
        try:
            n = len(alarm_uuids) if alarm_uuids is not None else 0
        except TypeError:
            n = 0
        if n == 0:
            return "no vManage alarms matched this device"
        if not vmanage_available:
            return "{n} UUID(s): clear not attempted - vManage unavailable".format(n=n)
        if alarm_state_unknown:
            return "{n} UUID(s): clear not attempted - alarm state unknown".format(n=n)
        if alarm_cleared:
            return "{n} UUID(s) cleared successfully".format(n=n)
        return "{n} UUID(s): clear sent but confirm still shows active - NOC manual clear needed".format(n=n)

    def parse_cli_uptime(self, cli_output):
        """Return a human-readable uptime string parsed from cli_output.
        Falls back to 'unknown' if nothing matches. Never raises.

        v27.1.8: scan EVERY captured command's output (not just
        system_status / version). Classic IOS-XE autonomous devices
        drop `show sdwan system status` entirely but still return
        uptime in `show version`, `show platform`, or even in the
        reboot_history / interfaces_desc banner. Also check less common
        keys so NOC always sees a real uptime when SSH captured anything.
        """
        if not isinstance(cli_output, dict):
            return "unknown"
        preferred = ("system_status", "version", "reboot_history",
                     "interfaces_desc", "ip_route")
        seen = set()
        key_order = [k for k in preferred if k in cli_output] + [
            k for k in cli_output.keys() if k not in preferred]
        for key in key_order:
            if key in seen:
                continue
            seen.add(key)
            blob = cli_output.get(key, "")
            if not isinstance(blob, str) or not blob:
                continue
            for pat in self._UPTIME_PATTERNS:
                m = pat.search(blob)
                if m:
                    val = m.group(1).strip().rstrip(".,;")
                    if 2 < len(val) < 120 and re.search(r"\d", val):
                        return val
        return "unknown"

    _CPU_PATTERNS = (
        # cEdge `show sdwan system status`: "CPU User            12%"
        re.compile(r"CPU\s+User\s+([0-9]{1,3})\s*%", re.IGNORECASE),
        # vEdge: "CPU usage: user 12%, system 3%, idle 85%"
        re.compile(r"CPU\s+usage[:\s]+user\s+([0-9]{1,3})\s*%", re.IGNORECASE),
        # Generic "CPU: 12%" line
        re.compile(r"\bCPU[:\s]+([0-9]{1,3})\s*%", re.IGNORECASE),
    )
    _MEM_USED_PATTERNS = (
        re.compile(r"Memory\s+Used\s+([0-9]{1,3})\s*%", re.IGNORECASE),
        re.compile(r"Memory\s+usage[:\s]+([0-9]{1,3})\s*%", re.IGNORECASE),
        re.compile(r"Mem[:\s]+([0-9]{1,3})\s*%\s*used", re.IGNORECASE),
    )

    def parse_cli_cpu_mem_line(self, cli_output):
        """Return 'CPU X%, memory Y%' parsed from cli_output.system_status.
        Falls back to 'cpu/memory not reported' if nothing matches.
        """
        if not isinstance(cli_output, dict):
            return "cpu/memory not reported"
        blob = cli_output.get("system_status", "")
        if not isinstance(blob, str) or not blob:
            return "cpu/memory not reported"
        cpu = None
        mem = None
        for pat in self._CPU_PATTERNS:
            m = pat.search(blob)
            if m:
                cpu = m.group(1)
                break
        for pat in self._MEM_USED_PATTERNS:
            m = pat.search(blob)
            if m:
                mem = m.group(1)
                break
        if cpu is None and mem is None:
            return "cpu/memory not reported"
        parts = []
        if cpu is not None:
            parts.append("CPU {c}%".format(c=cpu))
        if mem is not None:
            parts.append("memory {m}%".format(m=mem))
        return ", ".join(parts)

    _REBOOT_PATTERNS = (
        # cEdge `show version`: "Last reload reason: Image Install"
        re.compile(r"Last\s+reload\s+reason[:\s]+([^\r\n]+?)(?:\r|\n|$)", re.IGNORECASE),
        # cEdge `show version`: "System restarted at 22:24:57 UTC Sat Sep 12 2026"
        re.compile(r"System\s+restarted\s+at\s+([^\r\n]+?)(?:\r|\n|$)", re.IGNORECASE),
        # cEdge `show sdwan system status`: "Last reboot: user requested"
        re.compile(r"Last\s+reboot[:\s]+([^\r\n]+?)(?:\r|\n|$)", re.IGNORECASE),
    )

    def parse_cli_last_reboot_line(self, cli_output):
        """Return a one-line summary of the device's last reboot parsed
        from cli_output. Falls back to 'no reboot history recorded'.
        """
        if not isinstance(cli_output, dict):
            return "no reboot history recorded"
        pieces = []
        for key in ("version", "system_status", "reboot_history"):
            blob = cli_output.get(key, "")
            if not isinstance(blob, str) or not blob:
                continue
            for pat in self._REBOOT_PATTERNS:
                m = pat.search(blob)
                if m:
                    val = m.group(1).strip().rstrip(".,;")
                    if 2 < len(val) < 200:
                        pieces.append(val)
                        break
            if pieces:
                break
        if not pieces:
            return "no reboot history recorded"
        return "last reboot - " + " / ".join(pieces[:2])

    # ------------------------------------------------------------------
    # v27.1.8 - Device-mode detection + symmetric DIAG rendering fallbacks.
    #
    # Problem: inventory tags many classic IOS-XE "virtual ISR" boxes
    # (hostname pattern "*-vISR-*") as CEDGE. These devices run plain
    # IOS-XE autonomous mode, NOT SD-WAN controller mode. Every
    # `show sdwan ...` command returns "% Invalid input detected at
    # '^' marker" and is correctly dropped by clean_cli_dict. The result
    # was that NOC saw sparse / empty DIAG blocks with no explanation
    # (hydroalu 13226, wawai-s08534 build 13510, grhampkg 13518, etc).
    #
    # `detect_device_mode(cli_output)` returns one of:
    #   - "sdwan"       - `show sdwan system status` returned real content
    #   - "autonomous"  - all `show sdwan ...` keys missing / rejected while
    #                     `show version` returned real IOS-XE content
    #   - "unknown"     - insufficient data to decide
    #
    # `diag_fallback_text(key, platform, mode)` returns a short literal
    # explaining why a section header carries no device output, so NOC
    # always sees the full 10-section structure.
    # ------------------------------------------------------------------

    _SDWAN_ONLY_KEYS = frozenset((
        "system_status", "control_connections", "control_local_props",
        "control_history", "bfd_sessions", "bfd_history", "omp_peers",
        "cert_status", "cert_validity", "cert_installed",
        "tunnel_statistics", "wan_interface_list",
    ))

    # v27.1.32: Viptela OS error syntax markers (match the Python-side
    # list in viptela_ssh.py — kept in both places so neither drifts).
    # These phrases are emitted ONLY by Viptela OS vEdges when the CLI
    # parser rejects a command. IOS-XE cEdges reject with
    # `% Invalid input detected at '^' marker.` — a different form.
    _VEDGE_ERROR_MARKERS = (
        "syntax error: missing display group",
        "syntax error: incomplete path",
        "syntax error: unknown argument",
        "syntax error: element does not exist",
        "syntax error: expecting",
    )

    def detect_device_mode(self, cli_output):
        """Infer whether a cEdge-tagged device is actually in SD-WAN
        controller mode, classic IOS-XE autonomous mode, or a Viptela
        OS vEdge mistagged as CEDGE in inventory.

        Returns 'sdwan' | 'autonomous' | 'vedge' | 'unknown'. Defensive:
        non-dict input returns 'unknown'.

        v27.1.39 FIX — MULTI-SIGNAL (matches _probe_sdwan_mode in
        viptela_ssh.py). The v27.1.31-38 version relied on a single
        signal — `cli_output.system_status` content — and classified
        every cEdge whose `show sdwan system status` returned
        `% Invalid input` as "autonomous". But many real SD-WAN
        cEdges reject that one specific command while every OTHER
        SD-WAN signal is positive:
          - `show version` carries "Router operating mode: Controller-
            Managed" AND "Technology Package License Information:
            Controller-managed"
          - `show ip interface brief` and `show interfaces description`
            carry the Sdwan-intf / Sdwan-system-intf / vmanage_system
            interfaces (vdaemon control-plane interfaces, present
            only when SD-WAN daemon is loaded)
          - `show sdwan control connections` returns real vsmart/
            vmanage/vbond peer rows
          - `show sdwan bfd sessions` returns real BFD session rows
        konecr-addison-11949377e005 (build 16458) is the canonical
        example — all four other signals positive, only
        `show sdwan system status` rejected, device is 100% SD-WAN,
        but v27.1.38's filter still returned "autonomous" and the
        DIAG rendered 7 "(not available - classic IOS-XE autonomous)"
        fallback lines. NOC read it as autonomous and asked us to
        fix.

        v27.1.39 multi-signal order (SD-WAN by default — 95%+ of
        fleet):
          Signal V (vEdge syntax — kept from v27.1.32): Viptela-OS
            parser error in system_status → 'vedge' (overrides all
            SD-WAN signals; this is for genuinely-mistagged vEdges).
          Signal W (bare Viptela semver — kept from v27.1.32):
            version string matches 18-22.X.Y with no IOS-XE marker
            → 'vedge'.
          Signal A: version has "Controller-Managed" OR "operating
            mode: controller" → 'sdwan' (authoritative; this banner
            is set at boot on every controller-managed cEdge).
          Signal B: SD-WAN system interfaces present in
            interfaces_desc OR ip_int_brief (Sdwan-intf, Sdwan-
            system-intf, vmanage_system) → 'sdwan'.
          Signal C: control_connections contains real vsmart /
            vmanage / vbond rows (dtls or tls transport) → 'sdwan'.
          Signal D: bfd_sessions contains real BFD rows (SYSTEM IP +
            STATE pattern) → 'sdwan'.
          Signal E: system_status is a clean Viptela banner
            (System state, Controller Compatibility, Personality,
            vmanaged:) with no rejection token → 'sdwan'.

        Autonomous rule (only when ALL SD-WAN signals negative):
          System_status explicitly rejected AND version has
          "Cisco IOS XE" AND no SD-WAN signal matched anywhere →
          'autonomous'. Genuine 5% case.

        Default when SD-WAN markers all absent but device looks
        healthy IOS-XE (version has "Cisco IOS XE", no sys_status
        rejection either) → 'sdwan' (safer; matches
        _probe_sdwan_mode).
        """
        if not isinstance(cli_output, dict):
            return "unknown"

        sys_status = str(cli_output.get("system_status", "") or "").strip()
        version    = str(cli_output.get("version", "") or "").strip()
        interfaces = str(cli_output.get("interfaces_desc", "") or "")
        ip_int     = str(cli_output.get("ip_int_brief", "") or "")
        control    = str(cli_output.get("control_connections", "") or "")
        bfd        = str(cli_output.get("bfd_sessions", "") or "")
        sys_status_low = sys_status.lower()
        version_low    = version.lower()
        interfaces_low = interfaces.lower()
        ip_int_low     = ip_int.lower()

        # ---- Signal V: Viptela-OS error syntax wins outright ----
        # Preserved from v27.1.32. 53bank-RB046418A1 produced
        # "syntax error: missing display group" on every show sdwan X;
        # device is Viptela OS vEdge mistagged as CEDGE in inventory.
        if any(m in sys_status_low for m in self._VEDGE_ERROR_MARKERS):
            return "vedge"

        # ---- Signal W: bare Viptela OS semver with no IOS-XE marker ----
        # Preserved from v27.1.32. 53bank version was "20.9.7".
        if (version
                and re.match(r"^(18|19|20|21|22)\.\d+\.\d+(\.\d+)?$", version)
                and "ios" not in version_low):
            return "vedge"

        # ---- Signal A: Controller-Managed banner in show version ----
        # Authoritative — set at boot on every SD-WAN cEdge.
        # Matches v27.1.38 _probe_sdwan_mode Signal 1.
        if ("controller-managed" in version_low
                or "operating mode: controller" in version_low):
            return "sdwan"

        # ---- Signal B: SD-WAN system interfaces present ----
        # Matches v27.1.38 _probe_sdwan_mode Signal 2. Sdwan-intf /
        # Sdwan-system-intf / vmanage_system exist ONLY when vdaemon
        # has loaded its control-plane interfaces.
        for src_low in (interfaces_low, ip_int_low):
            if ("sdwan-intf" in src_low
                    or "sdwan-system-intf" in src_low
                    or "vmanage_system" in src_low):
                return "sdwan"

        # ---- Signal C: real control-plane peer rows ----
        # On an SD-WAN cEdge, show sdwan control connections returns
        # vsmart/vmanage/vbond rows with dtls or tls transport. On an
        # autonomous device the command errors and this field is empty
        # or just the "% Invalid input" line.
        if re.search(r"\b(vsmart|vmanage|vbond)\s+(dtls|tls)\b",
                     control, re.IGNORECASE):
            return "sdwan"

        # ---- Signal D: real BFD session rows ----
        # On SD-WAN cEdge, show sdwan bfd sessions returns
        # "<system-ip> <site-id> <state> <color> <color> ...".
        if re.search(r"\d+\.\d+\.\d+\.\d+\s+\d+\s+(up|down)\s+\S+\s+\S+",
                     bfd, re.IGNORECASE):
            return "sdwan"

        # ---- Signal E: clean Viptela banner in system_status ----
        if (sys_status_low
                and any(m in sys_status_low for m in (
                    "system state", "controller compatibility",
                    "vmanaged:", "personality:"))
                and not any(stripped.startswith(tok)
                            for stripped in (ln.strip() for ln in sys_status.splitlines()[:5])
                            for tok in self._DEVICE_ERROR_TOKENS
                            if stripped)):
            return "sdwan"

        # ---- Autonomous (only when ALL SD-WAN signals negative) ----
        # system_status explicitly rejected AND version has Cisco IOS XE
        # AND no SD-WAN signal matched anywhere above.
        sys_rejected = False
        if sys_status:
            for line in sys_status.splitlines()[:5]:
                stripped = line.strip()
                if not stripped:
                    continue
                if any(stripped.startswith(tok)
                       for tok in self._DEVICE_ERROR_TOKENS):
                    sys_rejected = True
                    break

        if sys_rejected and ("ios-xe" in version_low or "ios xe" in version_low):
            # Last check: does ANY SD-WAN cEdge signal exist in the
            # fuller capture that didn't match the earlier regex?
            # If we see "sdwan" literally in interfaces or routes
            # output as a last-chance safety net, lean SD-WAN.
            if ("sdwan" in interfaces_low or "sdwan" in ip_int_low):
                return "sdwan"
            return "autonomous"

        # ---- Default: SD-WAN (95%+ field assumption) ----
        # If version has IOS-XE marker but no SD-WAN signal matched
        # and no rejection either, default to sdwan (safer; aligns
        # with _probe_sdwan_mode's SD-WAN default behavior).
        if "cisco ios xe" in version_low or "ios-xe" in version_low:
            return "sdwan"

        return "unknown"

    # v27.1.30 — NOC-friendly per-section fallback texts for the
    # "legitimately empty" case (device returned no data for this query,
    # as distinct from "device rejected the command"). The old generic
    # "command rejected by device, SSH session may not have reached this
    # command, or output was empty" conflated three states and NOC read
    # "command rejected" even when SSH was fine and the device simply
    # had nothing to say (e.g. an unprovisioned partner vEdge has no
    # BFD sessions, no OMP peers, no BFD history — those are facts, not
    # errors). Each entry below is section-specific truth.
    _EMPTY_FALLBACK = {
        "bfd_sessions":
            "(no BFD sessions established on this device)",
        "omp_peers":
            "(no OMP peers established on this device)",
        "bfd_history":
            "(no BFD session history recorded on this device)",
        "control_history":
            "(no control connection history recorded)",
        "control_connections":
            "(no control connections established on this device)",
        "control_local_props":
            "(control local-properties returned empty)",
        "cert_status":
            "(certificate status returned empty - see control_local_props "
            "for cert install state and validity)",
        "cert_validity":
            "(certificate validity returned empty - see control_local_props)",
        "cert_installed":
            "(installed certificate list returned empty - see "
            "control_local_props)",
        "system_status":
            "(system status returned empty)",
        "reboot_history":
            "(no reboot history recorded)",
        "version":
            "(version query returned empty)",
        "interfaces_desc":
            "(no interface descriptions reported)",
        "ip_int_brief":
            "(no IP interfaces reported)",
        "wan_interface_list":
            "(no WAN interface list reported)",
        "tunnel_statistics":
            "(no tunnel statistics - device may have no active tunnels)",
    }

    def diag_fallback_text(self, key, platform="cedge", mode="unknown",
                           raw_value=None):
        """Return the short literal shown under a DIAG section header
        when the device returned no usable output for that command.
        Mode-aware: on autonomous IOS-XE, SD-WAN-specific sections get
        a specific explanation; otherwise the message tries to reflect
        what actually happened.

        v27.1.30: when `raw_value` is supplied (the pre-clean capture
        from cli_output), inspect it to distinguish three real states:
          - truly empty: device returned no body → section-specific
            "no X established on this device" message (NOC can trust
            the device state read)
          - rejected: capture starts with an error token (`% Invalid
            input`, `syntax error`, etc.) → keep "command rejected"
            wording (NOC knows the role sent a command the device
            didn't accept)
          - unknown (raw_value is None → caller didn't pass it):
            generic fallback (back-compat with pre-v27.1.30 callers)

        `None` is the explicit "no information" sentinel. An empty
        string `""` means the caller IS telling us "the device returned
        empty" and gets the friendly section-specific text.
        """
        key = str(key or "")
        mode = str(mode or "unknown").lower()
        plat = str(platform or "").lower()

        # Autonomous-mode specific message overrides everything else —
        # NOC needs to see the whole-device explanation once, not per
        # section, for autonomous cEdges.
        if mode == "autonomous" and key in self._SDWAN_ONLY_KEYS:
            return ("(not available - device is running classic IOS-XE "
                    "autonomous mode; `show sdwan ...` commands are "
                    "rejected; see `show version` + logging below)")
        # v27.1.32: vedge-mistag mode — ESP inventory tagged this device
        # as CEDGE but the device is actually a Viptela OS vEdge
        # (version string like "20.9.7"; every `show sdwan ...` command
        # rejected with Viptela syntax). The role's SSH recovery path
        # (run_primary() in viptela_ssh.py) re-runs with VEDGE_COMMANDS
        # when this is detected mid-run, but if the recovery didn't
        # fire (e.g. Ansible-level platform override), NOC sees empty
        # SDWAN-only sections. Explain once, per section.
        if mode == "vedge" and key in self._SDWAN_ONLY_KEYS:
            return ("(not available - device is a Viptela OS vEdge, not "
                    "cEdge; `show sdwan ...` commands do not apply here; "
                    "see system_status / arp / ip_route / vrrp_detail "
                    "blocks for vEdge-native data)")
        if plat == "vedge" and key in ("ip_int_brief", "ip_route", "arp",
                                       "logging_control"):
            return ("(not captured on vEdge - Viptela OS uses a different "
                    "command set; see system_status / version blocks)")

        # Legacy caller path: raw_value is None (not passed at all).
        # Preserve the pre-v27.1.30 wording exactly.
        if raw_value is None:
            if key == "logging_last":
                return ("(no syslog captured - SSH session may not have "
                        "returned any priority events)")
            if key == "tunnel_statistics":
                return ("(no tunnel statistics captured - device may be "
                        "autonomous mode or the command returned empty)")
            return ("(no output - command rejected by device, SSH session "
                    "may not have reached this command, or output was empty)")

        # v27.1.30 inspection path: raw_value was supplied.
        raw = raw_value
        if not isinstance(raw, str):
            raw = str(raw)
        raw = raw.strip()

        is_rejected = False
        if raw:
            for line in raw.splitlines()[:5]:
                stripped = line.strip()
                if not stripped:
                    continue
                if any(stripped.startswith(tok)
                       for tok in self._DEVICE_ERROR_TOKENS):
                    is_rejected = True
                    break
        is_empty = (len(raw) == 0)

        if is_rejected:
            return ("(command rejected by device - see Jenkins build log "
                    "task 7020 for the raw capture)")

        if is_empty and key in self._EMPTY_FALLBACK:
            return self._EMPTY_FALLBACK[key]

        # Supplied-but-unmapped (non-empty raw that wasn't an error, OR
        # an empty raw for a key not in _EMPTY_FALLBACK) → legacy wording
        # as a safe default.
        if key == "logging_last":
            return ("(no syslog captured - SSH session may not have "
                    "returned any priority events)")
        if key == "tunnel_statistics":
            return ("(no tunnel statistics captured - device may be "
                    "autonomous mode or the command returned empty)")
        return ("(no output - command rejected by device, SSH session "
                "may not have reached this command, or output was empty)")

    # ------------------------------------------------------------------
    # v27.1.5 - NOC-driven DIAGNOSTIC-block render rules.
    # Every filter below is defensive: unexpected inputs return a sane
    # literal, never raise. Hundreds of these calls run on every ticket;
    # one exception would blow up write_output.yaml and fall into rescue.
    # ------------------------------------------------------------------

    # IOS-XE / Viptela OS syslog header: `Oct 14 10:19:34.112:` or
    # `*Oct 14 10:19:34:` or `Oct 14 10:19:34`.
    _SYSLOG_TS_RE = re.compile(
        r"^\*?([A-Z][a-z]{2})\s+(\d{1,2})\s+(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?"
    )
    _MONTH_IDX = {m: i + 1 for i, m in enumerate(
        ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])}

    # Priority facilities (anything else is dropped as noise).
    _PRIORITY_FACILITIES = (
        "BFD", "TLOC", "OMP", "VDAEMON", "LINK", "SYS", "CONTROL",
        "LINEPROTO", "DAPI", "VSMART", "VBOND", "VMANAGE",
    )
    # Tier-1 (down / error / reload) markers. Use SPECIFIC phrases, not
    # bare "DOWN" - the facility name %LINK-3-UPDOWN contains "DOWN" as
    # a substring and would misclassify every state-change line as tier 1.
    _DOWN_MARKERS = (
        "went down", "changed state to down", "is down",
        "SESS_DOWN", "TLOC_DOWN", "CONTROL_DOWN", "PEER_DOWN",
        "FAIL", "ERROR", "RELOAD", "LOST", "TIMEOUT",
    )
    _UP_MARKERS = (
        "went up", "changed state to up", "is up",
        "SESS_UP", "TLOC_UP", "CONTROL_UP", "PEER_UP",
        "RECOVERY", "RESTORED",
    )

    def _parse_ticket_ts(self, incident_start_time):
        """Parse an ETMS incident_start_time string into a naive UTC
        datetime. Accepts common forms seen in Device-Down tickets.
        Returns None if nothing parses.
        """
        if not isinstance(incident_start_time, str):
            return None
        s = incident_start_time.strip()
        if not s or s.upper() in ("N/A", "NA", "UNKNOWN"):
            return None
        for fmt in (
            "%m/%d/%Y %H:%M:%S",       # 10/14/2026 10:19:51
            "%m/%d/%Y %H:%M",          # 10/14/2026 10:19
            "%Y-%m-%d %H:%M:%S",       # 2026-10-14 10:19:51
            "%Y-%m-%dT%H:%M:%S",       # 2026-10-14T10:19:51
            "%d-%b-%Y %H:%M:%S",       # 14-Oct-2026 10:19:51
        ):
            try:
                return datetime.strptime(s[:len(fmt) + 4], fmt)
            except (ValueError, TypeError):
                pass
        return None

    def _parse_log_ts(self, line, year_hint):
        """Extract a datetime from the first syslog header on `line`.
        Returns None if no header. `year_hint` fills in the missing year.
        """
        m = self._SYSLOG_TS_RE.match(line)
        if not m:
            return None
        mon = self._MONTH_IDX.get(m.group(1))
        if not mon:
            return None
        try:
            return datetime(
                year_hint, mon, int(m.group(2)),
                int(m.group(3)), int(m.group(4)), int(m.group(5)))
        except (ValueError, TypeError):
            return None

    def _log_body_key(self, line):
        """Return a dedup key for `line`: the message body with timestamp,
        sequence number, and ephemeral fields normalized. Lines with the
        same semantic content but different session-level identifiers
        collapse to a single `(xN)` entry.

        v27.1.33: normalize ephemeral fields that vary per-session but
        don't change the semantic message identity. Without this, 29
        back-to-back `%DMI-5-AUTH_PASSED: ... from 1.1.1.1:53928 ...`
        lines (seen on SIT 1146) remained 29 distinct dedup keys
        because the TCP source port changes every connection.

        Normalizations applied to the KEY only (the displayed `sample`
        line in the output still carries its real original text):
          - leading `*Mon DD HH:MM:SS[.ms]: ` header stripped
          - IOS-XE sequence numbers `000123: ` stripped
          - any `IP:port` → `IP:*`
          - whitespace collapsed
        """
        # Strip leading optional `*` + "Mon DD HH:MM:SS[.ms]: " header
        stripped = self._SYSLOG_TS_RE.sub("", line, count=1).lstrip(": ").strip()
        # Also strip IOS-XE sequence numbers like "000123: "
        stripped = re.sub(r"^\d{3,}:\s*", "", stripped)
        # v27.1.33: normalize IPv4:port ephemeral fields. Catches TCP
        # source ports in DMI auth logs ("1.1.1.1:53928" → "1.1.1.1:*"),
        # NTP connections, syslog relay sessions, etc. The IP itself is
        # kept because it carries real identity (who's talking).
        stripped = re.sub(
            r'(\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):\d+\b',
            r'\1:*', stripped)
        # Collapse whitespace
        stripped = re.sub(r"\s+", " ", stripped)
        return stripped

    def _log_facility_ok(self, body):
        """True if the message body carries a facility we care about."""
        # Facility is between the first `%` and the first `-` on the body
        m = re.search(r"%([A-Z][A-Z0-9_]*)-", body)
        if m:
            fac = m.group(1).upper()
            # Match if any priority facility is a prefix (`%BFD-6-...` → BFD)
            return any(fac.startswith(p) for p in self._PRIORITY_FACILITIES)
        # Non-facility informational lines are kept only if they clearly
        # describe a state transition.
        low = body.lower()
        return any(
            k.lower() in low for k in (self._DOWN_MARKERS + self._UP_MARKERS)
        )

    def _log_tier(self, body):
        """1 = down/error, 2 = up/recovery, 3 = other priority."""
        up_body = body.upper()
        for mk in self._DOWN_MARKERS:
            if mk.upper() in up_body:
                return 1
        for mk in self._UP_MARKERS:
            if mk.upper() in up_body:
                return 2
        return 3

    def _collect_log_buckets(self, log_text, year, win_start, win_end,
                             include_all_facilities=False, buckets=None):
        """Walk log_text, group matching lines into tiered buckets.
        Returns (buckets, in_window_count). `buckets` keys = (tier, body),
        values = {"count", "last_ts", "sample"}.

        v27.1.33 changes:
          - `include_all_facilities=False` (default) keeps the priority-
            facility filter — behavior identical to pre-v27.1.33.
          - `include_all_facilities=True` keeps EVERY syslog line that
            has a valid timestamp, regardless of facility. Used by the
            progressive-widening stages in logging_filter_window to
            reach the NOC-mandated 30-unique-line target on quiet
            devices.
          - `buckets` can be a pre-seeded dict so a second pass with
            relaxed facility matching extends the same bucket set
            (preserves dedup across stages — if the same (tier, body)
            key appears in two passes, counts combine). Lines without
            a timestamp are always skipped so we never pull in config-
            banner noise.
        """
        if buckets is None:
            buckets = {}
        in_window = 0
        for raw in log_text.splitlines():
            raw = raw.rstrip()
            if not raw:
                continue
            ts = self._parse_log_ts(raw, year)
            if ts is None or ts < win_start or ts > win_end:
                continue
            in_window += 1
            body = self._log_body_key(raw)
            if not body:
                continue
            if (not include_all_facilities) and (not self._log_facility_ok(body)):
                continue
            tier = self._log_tier(body)
            key = (tier, body)
            entry = buckets.get(key)
            if entry is None:
                buckets[key] = {"count": 1, "last_ts": ts, "sample": raw}
            else:
                entry["count"] += 1
                if ts > entry["last_ts"]:
                    entry["last_ts"] = ts
                    entry["sample"] = raw
        return buckets, in_window

    def logging_filter_window(self, log_text, incident_start_time,
                              before_min=5, after_min=None, max_lines=40,
                              device_uptime=None):
        """Filter captured `show logging` output to a ticket-anchored
        window, dedupe repeats with `(xN)`, order by tier (DOWN/ERROR,
        UP/recovery, other), and cap at `max_lines`.

        v27.1.7 window change (approved by Aadarsh):
          start = incident_start_time - `before_min` minutes (default 5)
          end   = NOW (current UTC) when `after_min` is None (default)
                  -- the playbook runs after the alarm, so "now" captures
                  everything from pre-alarm through recovery.
          end   = incident_start_time + `after_min` minutes (back-compat)

        v27.1.7 empty-window fallback: when the ticket-anchored window
        produces zero priority events, fall through to the top-`max_lines`
        priority events from the ENTIRE capture (last ~200 lines on
        device) so the NOC never gets an empty DIAGNOSTIC block.
        """
        if not isinstance(log_text, str) or not log_text.strip():
            return "(no syslog captured from device)"

        anchor = self._parse_ticket_ts(incident_start_time)
        if anchor is None:
            # No usable ticket timestamp - fall back to last-30 raw tail.
            tail = log_text.strip().splitlines()[-30:]
            return "\n".join(tail) if tail else "(no syslog captured)"

        try:
            before = int(before_min)
        except (TypeError, ValueError):
            before = 5
        try:
            cap = int(max_lines)
        except (TypeError, ValueError):
            cap = 40

        win_start = anchor - timedelta(minutes=before)
        if after_min is None or after_min == "" or after_min == "null":
            # NOW - current UTC. Add 1 minute slack so a log line
            # timestamped "right at this instant" is not excluded.
            # v27.1.11: tz-aware form to future-proof against Py3.12+
            # DeprecationWarning on datetime.utcnow(). Drop tzinfo so
            # comparison with the naive log timestamps (parsed without
            # tz) stays consistent.
            win_end = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(minutes=1)
            window_desc = "ticket window {s} UTC -> NOW".format(
                s=win_start.strftime("%Y-%m-%d %H:%M"))
        else:
            try:
                after = int(after_min)
            except (TypeError, ValueError):
                after = 15
            win_end = anchor + timedelta(minutes=after)
            window_desc = "ticket window {s} UTC -> {e} UTC".format(
                s=win_start.strftime("%Y-%m-%d %H:%M"),
                e=win_end.strftime("%Y-%m-%d %H:%M"))
        year = anchor.year

        # v27.1.33 PROGRESSIVE WIDENING. NOC requirement: show 30 unique
        # lines after (xN) dedup, every ticket. The old code had just two
        # stages (ticket window + priority) → (entire capture + priority)
        # and bailed if both produced < cap lines, leaving NOC with 2-3
        # lines on quiet devices (SIT 1146 showed 2 priority events in a
        # 9-month window). We now walk THREE INDEPENDENT passes and
        # pick the TIGHTEST pass that reaches `cap`:
        #
        #   Pass 1 — ticket-anchored window + priority facility filter
        #   Pass 2 — entire capture + priority facility filter
        #   Pass 3 — entire capture + ALL facilities with a syslog
        #            timestamp (NEW — catches quiet devices whose only
        #            chatter is DMI auth / vmanage heartbeat that
        #            doesn't match the DOWN/UP tier markers).
        #
        # Each pass is an independent run of _collect_log_buckets()
        # against the FULL log text — no bucket sharing between passes.
        # This guarantees counts are correct and lines are never double-
        # counted when a message matches both the window AND the broader
        # capture. The selection logic picks the first pass whose
        # bucket count reaches `cap`; otherwise it uses the broadest
        # pass with content.
        very_wide_start = datetime(1970, 1, 1)
        very_wide_end = datetime(2099, 12, 31)

        buckets_window, in_window = self._collect_log_buckets(
            log_text, year, win_start, win_end)
        buckets_capture, _ = self._collect_log_buckets(
            log_text, year, very_wide_start, very_wide_end)
        buckets_allfac, _ = self._collect_log_buckets(
            log_text, year, very_wide_start, very_wide_end,
            include_all_facilities=True)

        # Pick the tightest pass that gives us `cap` unique bucket keys,
        # or the broadest pass with content if none hits `cap`.
        if len(buckets_window) >= cap:
            buckets = buckets_window
            provenance = "window"
        elif len(buckets_capture) >= cap:
            buckets = buckets_capture
            provenance = "capture"
        elif len(buckets_allfac) > 0:
            buckets = buckets_allfac
            provenance = "allfac"
        elif len(buckets_capture) > 0:
            buckets = buckets_capture
            provenance = "capture"
        elif len(buckets_window) > 0:
            buckets = buckets_window
            provenance = "window"
        else:
            return ("(no syslog events anywhere in capture; "
                    + window_desc + ", {n} in-window line(s))".format(
                        n=in_window))

        # Order: tier asc, then newest first within tier.
        items = sorted(
            buckets.items(),
            key=lambda kv: (kv[0][0], -kv[1]["last_ts"].timestamp()),
        )[:cap]

        lines = []
        for (_tier, _body), e in items:
            prefix = "(x{n}) ".format(n=e["count"]) if e["count"] > 1 else ""
            lines.append(prefix + e["sample"])

        # Compose fallback_note so NOC knows the data provenance.
        fallback_note = ""
        if provenance == "allfac":
            fallback_note = (
                " [BROADENED to all syslog lines - priority events alone "
                "did not reach {} unique]".format(cap))
        elif provenance == "capture" and len(buckets_window) < cap:
            fallback_note = (
                " [BROADENED beyond ticket window - showing most-recent "
                "priority events from entire capture]")
        # v27.1.14 E7: recent-reboot context prefix. When device uptime is
        # under 2 hours, the on-device log buffer may be sparse by nature.
        # Make this explicit so NOC does not interpret minimal logs as an
        # iAutomate collection gap. device_uptime looks like
        # "0 days 00 hrs 14 min 28 sec" (SD-WAN) or "5 weeks, 3 days, 7
        # hours, 11 minutes" (classic IOS-XE); be defensive about both.
        reboot_note = ""
        if device_uptime:
            try:
                ut = str(device_uptime).lower()
                total_min = 0
                m = re.search(r"(\d+)\s*day", ut)
                if m: total_min += int(m.group(1)) * 1440
                m = re.search(r"(\d+)\s*week", ut)
                if m: total_min += int(m.group(1)) * 7 * 1440
                m = re.search(r"(\d+)\s*hr|(\d+)\s*hour", ut)
                if m: total_min += int(m.group(1) or m.group(2) or 0) * 60
                m = re.search(r"(\d+)\s*min", ut)
                if m: total_min += int(m.group(1))
                if 0 < total_min < 120:
                    reboot_note = (
                        " [device uptime {u} min - syslog buffer limited "
                        "since last reboot]").format(u=total_min)
            except (TypeError, ValueError, AttributeError):
                pass

        header = (
            "("
            + window_desc
            + ", {} unique priority event(s){}{})".format(
                len(buckets), fallback_note, reboot_note)
        )
        return header + "\n" + "\n".join(lines)

    def table_down_or_topn_up(self, table_text, state_match="down",
                              topn_up=5):
        """Parse a flat `show ...` table (control connections, bfd sessions)
        and return either:
          - the header + all rows whose state matches `state_match`, OR
          - if there are no matching rows, the header + the top-N rows
            that look like data rows.

        The function hunts for a header line containing the word
        'STATE' (case-insensitive) and uses it as the first anchor. All
        separator lines starting with `-` are preserved.
        """
        if not isinstance(table_text, str) or not table_text.strip():
            return "(no output returned by device for this command)"

        lines = table_text.splitlines()
        header_idx = None
        for i, ln in enumerate(lines):
            if re.search(r"\bSTATE\b", ln, re.IGNORECASE):
                header_idx = i
                break

        if header_idx is None:
            # Table shape didn't match - return the raw text unchanged.
            return table_text

        try:
            cap = int(topn_up)
        except (TypeError, ValueError):
            cap = 5

        header_block = lines[: header_idx + 1]
        # Keep up to 2 following separator / sub-header lines
        tail_start = header_idx + 1
        while tail_start < len(lines) and (
            lines[tail_start].startswith("-")
            or lines[tail_start].strip() == ""
        ):
            header_block.append(lines[tail_start])
            tail_start += 1

        data_rows = [ln for ln in lines[tail_start:] if ln.strip()]
        match_lower = (state_match or "down").strip().lower()
        down_rows = [
            r for r in data_rows
            if re.search(r"\b" + re.escape(match_lower) + r"\b", r.lower())
        ]
        if down_rows:
            total = len(data_rows)
            return (
                "(" + str(len(down_rows))
                + " "
                + match_lower.upper()
                + " row(s) of "
                + str(total)
                + " total)\n"
                + "\n".join(header_block + down_rows)
            )
        # No DOWN rows → show top N UP rows (newest / first N in device order)
        up_rows = data_rows[:cap]
        total = len(data_rows)
        return (
            "(all " + str(total) + " row(s) UP; showing first "
            + str(len(up_rows)) + " for sanity)\n"
            + "\n".join(header_block + up_rows)
        )

    def reboot_history_topn(self, text, n=7):
        """Return the latest N reboot entries from the captured text,
        with identical repeat reasons collapsed to `(xN)` lines. Keeps
        the header lines so the NOC still sees the column layout.
        """
        if not isinstance(text, str) or not text.strip():
            return "(no reboot history captured)"
        try:
            cap = int(n)
        except (TypeError, ValueError):
            cap = 7

        lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]
        # Keep leading non-data lines (header + separator) as context,
        # at most 3.
        header, data = [], []
        for ln in lines:
            if (not data) and (
                ln.startswith("-")
                or re.search(r"[A-Za-z]", ln)
                and not re.match(r"^\s*\d", ln)
            ):
                if len(header) < 3:
                    header.append(ln)
                    continue
            data.append(ln)

        if not data:
            # Fallback: show first `cap` raw lines so we never return empty.
            return "\n".join(lines[:cap])

        # Dedupe by trailing "reason" substring (last meaningful word group)
        counts = {}
        order = []
        for row in data:
            # Reason key: lower-cased collapsed whitespace after first 10 chars
            tail = re.sub(r"\s+", " ", row[10:]).strip().lower()
            if tail not in counts:
                counts[tail] = {"count": 1, "sample": row}
                order.append(tail)
            else:
                counts[tail]["count"] += 1

        # Keep most recent (device output is newest-first for both platforms)
        latest = order[:cap]
        out_rows = []
        for key in latest:
            c = counts[key]["count"]
            s = counts[key]["sample"]
            out_rows.append(("(x{}) ".format(c) if c > 1 else "") + s)
        return "\n".join(header + out_rows)

    # v27.1.30 — verbose per-tunnel format parser.
    # CSR1000V / IOS-XE 17.3.x cEdges return `show sdwan tunnel statistics`
    # in a per-tunnel key-value block form rather than the column-based
    # table used on vEdge and newer cEdge:
    #
    #   tunnel stats ipsec 172.16.10.21 172.16.10.19 12406 12386
    #    system-ip            1.20.0.0
    #    local-color          biz-internet
    #    remote-color         biz-internet
    #    tunnel-mtu           1442
    #    tx_pkts              2774095
    #    tx_octets            244652929
    #    rx_pkts              2774095
    #    rx_octets            323902294
    #    tcp-mss-adjust       1362
    #    ipv6_tx_pkts         0
    #    ...
    #   tunnel stats ipsec 172.16.10.21 172.16.10.20 12406 6668
    #    ...
    #
    # tunnel_stats_relevant used to hit the "unknown shape" code path on
    # this format and truncate to budget, dumping ~500 chars per tunnel
    # x many tunnels into DIAG. v27.1.30 parses it into blocks, filters
    # down to overlay tunnels with real traffic (same rules as the
    # tabular path), and renders a condensed one-liner per surviving
    # tunnel so NOC can scan it at a glance.
    _VERBOSE_HEADER_RE = re.compile(r"^tunnel stats\s+(\S+)\s+(\S+)\s+(\S+)"
                                    r"\s+(\d+)\s+(\d+)\s*$")

    @staticmethod
    def _is_verbose_tunnel_format(text):
        """Detect the per-tunnel key-value format."""
        if not isinstance(text, str) or not text:
            return False
        # Signatures: at least one "tunnel stats ipsec ..." header AND at
        # least one " tx_pkts " underscore-form field (the tabular format
        # uses "tx-pkts" with hyphen).
        has_header = bool(re.search(r"^tunnel stats\s+\S+\s+\S+\s+\S+",
                                    text, re.MULTILINE))
        has_underscore_field = bool(re.search(r"^\s+tx_pkts\s+\d",
                                              text, re.MULTILINE))
        return has_header and has_underscore_field

    def _parse_verbose_tunnel_blocks(self, text):
        """Return list of (header_match_dict, fields_dict). Non-matching
        lines are ignored defensively."""
        blocks = []
        current_hdr = None
        current = {}

        def _flush():
            if current_hdr is not None:
                blocks.append((current_hdr, dict(current)))

        for line in text.splitlines():
            m = self._VERBOSE_HEADER_RE.match(line)
            if m:
                _flush()
                current_hdr = {
                    "proto": m.group(1),
                    "src":   m.group(2),
                    "dst":   m.group(3),
                    "sport": m.group(4),
                    "dport": m.group(5),
                }
                current = {}
                continue
            if current_hdr is None:
                continue
            # Field line: leading spaces, key (word/dash/underscore), value.
            fm = re.match(r"\s+([A-Za-z][A-Za-z0-9_-]*)\s+(.+)$", line)
            if fm:
                current[fm.group(1).strip()] = fm.group(2).strip()
        _flush()
        return blocks

    def _render_verbose_tunnel_block(self, hdr, fields):
        """One-line condensed per-tunnel summary for the DIAG section.
        Columns chosen to match what NOC reads first on the tabular
        format: direction endpoints, system-ip, colors, tx/rx packet
        counts."""
        sysip  = fields.get("system-ip", "-")
        lcolor = fields.get("local-color", "-")
        rcolor = fields.get("remote-color", "-")
        tx     = fields.get("tx_pkts", "0")
        rx     = fields.get("rx_pkts", "0")
        return ("{proto}  {src:>15} -> {dst:<15}  :{sport}/{dport}"
                "  sys={sysip:<10} {lc}->{rc}  tx={tx}  rx={rx}").format(
            proto=hdr["proto"], src=hdr["src"], dst=hdr["dst"],
            sport=hdr["sport"], dport=hdr["dport"],
            sysip=sysip, lc=lcolor, rc=rcolor, tx=tx, rx=rx,
        )

    @staticmethod
    def _tunnel_block_is_relevant(fields):
        """Keep rules for verbose blocks, matching the tabular path:
          - drop Umbrella / SIG / NAT-keepalive (system-ip == "-")
          - drop zero-traffic rows (both tx_pkts and rx_pkts == 0)
        """
        if fields.get("system-ip", "").strip() in ("-", ""):
            return False
        try:
            tx = int(fields.get("tx_pkts", "0") or "0")
            rx = int(fields.get("rx_pkts", "0") or "0")
        except (TypeError, ValueError):
            return True  # unparseable: keep it rather than hide it
        return (tx > 0) or (rx > 0)

    def tunnel_stats_relevant(self, table_text, max_chars=2500):
        """Trim a `show (sdwan) tunnel statistics` capture to the most
        operationally relevant rows that fit within `max_chars`:
          1. Rows whose STATE column is not 'up' (down / building / idle)
          2. Rows whose tx-pkts or rx-pkts counter is non-zero
          3. Idle UP rows with zero traffic are dropped as noise.
          4. v27.1.29: NAT-keepalive / cloud-DNS tunnels (Umbrella /
             SIG) are dropped. These rows have SYSTEM-IP == "-" (no
             SD-WAN peer) and LOCAL/REMOTE COLOR == "-" because they
             are not part of the overlay. From a NOC perspective they
             are noise — a cEdge forwarding to Umbrella 146.112.99.x
             over port 4500 is working as designed; it is not an
             overlay tunnel and does not belong in the triage view.
        Keeps the header. Returns a short literal if nothing fits.
        """
        if not isinstance(table_text, str) or not table_text.strip():
            return "(no tunnel statistics captured)"
        try:
            budget = int(max_chars)
        except (TypeError, ValueError):
            budget = 2500
        if budget < 200:
            # No room - one-liner summary only.
            total = sum(1 for _ in table_text.splitlines())
            return (
                "(tunnel statistics captured - ~" + str(total)
                + " rows; full output in Jenkins build log)"
            )

        # v27.1.30: dispatch to verbose per-tunnel format if detected
        # (CSR1000V / IOS-XE 17.3.x cEdge). The tabular path below still
        # handles vEdge and newer cEdge.
        if self._is_verbose_tunnel_format(table_text):
            blocks = self._parse_verbose_tunnel_blocks(table_text)
            if not blocks:
                return table_text[:budget]
            relevant = [(h, f) for h, f in blocks
                        if self._tunnel_block_is_relevant(f)]
            total = len(blocks)
            kept = len(relevant)
            dropped = total - kept
            header_line = ("(verbose format - showing {k} active overlay "
                           "tunnel(s) of {t} total; dropped {d} idle / "
                           "umbrella / NAT-keepalive)").format(
                               k=kept, t=total, d=dropped)
            if kept == 0:
                return header_line
            out_lines = [header_line]
            used = len(header_line) + 1
            trimmed_count = 0
            for h, fields in relevant:
                row = self._render_verbose_tunnel_block(h, fields)
                if used + len(row) + 1 > budget:
                    trimmed_count = kept - (len(out_lines) - 1)
                    break
                out_lines.append(row)
                used += len(row) + 1
            if trimmed_count:
                out_lines.append("... ({} more; see Jenkins build log)".format(
                    trimmed_count))
            return "\n".join(out_lines)

        lines = table_text.splitlines()

        # Find header
        header_idx = None
        for i, ln in enumerate(lines):
            if re.search(r"\b(state|tx-pkts|rx-pkts)\b", ln, re.IGNORECASE):
                header_idx = i
                break
        if header_idx is None:
            # Unknown shape - just truncate to budget.
            return table_text[:budget]

        header_block = lines[: header_idx + 1]
        tail_start = header_idx + 1
        while tail_start < len(lines) and (
            lines[tail_start].startswith("-") or lines[tail_start].strip() == ""
        ):
            header_block.append(lines[tail_start])
            tail_start += 1

        data_rows = [ln for ln in lines[tail_start:] if ln.strip()]

        def is_down(row):
            # Look for " down " token on the row - covers 'state=down'
            # and generic down flags.
            return bool(re.search(r"\bdown\b", row.lower()))

        def has_traffic(row):
            # If any multi-digit non-zero integer appears late in the row,
            # we take it as traffic. Heuristic - intentionally forgiving.
            nums = re.findall(r"\b([0-9][0-9,]+)\b", row)
            for n in nums:
                try:
                    if int(n.replace(",", "")) > 0:
                        return True
                except ValueError:
                    continue
            return False

        def is_umbrella_or_nat_keepalive(row):
            """v27.1.29: True when this row is an Umbrella/SIG DNS
            tunnel or a plain NAT keepalive, not an SD-WAN overlay
            tunnel. Signatures seen in prod SIT output:

              ipsec  172.16.10.19  13.11.11.11      4500  4500  -  -  -  1418  0  0  0  0  1338
              ipsec  172.16.10.19  146.112.99.101   4500  4500  -  -  -  1418  0  0  0  0  1338
              ipsec  172.16.10.19  146.112.99.102   4500  4500  -  -  -  1446  0  0  0  0  1366

            Signals (all must hold; keep conservative so a real overlay
            tunnel is never dropped):
              - SOURCE and DEST PORT are both 4500 (IPsec NAT-T; real
                SD-WAN tunnels use 12346/12366/12406 or 12846)
              - The SYSTEM-IP column renders as "-" (no overlay peer)
              - Both tx-pkts and rx-pkts are zero (fresh NAT state or
                management-plane only)
              - Destination IP is in a public cloud-DNS/SIG range
                (146.112.0.0/16 is Umbrella; 13.11.11.11 is a seen
                SIG probe) OR the local-color column is "-"
            From NOC's perspective these rows are not actionable; they
            represent cloud-security integration, not overlay health.
            """
            # Must have both ports == 4500 to be NAT-T (not SD-WAN)
            if not re.search(r"\b4500\s+4500\b", row):
                return False
            # SYSTEM-IP column must be "-" (not a real system-ip like 1.20.0.0)
            # Pattern: port port system_ip local_color — "4500  4500  -"
            if not re.search(r"\b4500\s+4500\s+-\s", row):
                return False
            # tx-pkts and rx-pkts must be zero. We check for " 0 " appearing
            # at least 3 times in the row (tx-pkts, tx-octets, rx-pkts, rx-octets).
            if row.count(" 0 ") < 3 and not re.search(r"\s0\s+0\s+0\s+0\s", row):
                return False
            return True

        # Drop Umbrella / NAT-keepalive rows FIRST — never surface them.
        data_rows = [r for r in data_rows if not is_umbrella_or_nat_keepalive(r)]

        down_rows = [r for r in data_rows if is_down(r)]
        active_rows = [r for r in data_rows if (not is_down(r)) and has_traffic(r)]
        # Preserve device order within each group
        selected = down_rows + active_rows

        # Fit as many rows as the budget allows (header always included)
        out = list(header_block)
        used = sum(len(x) + 1 for x in out)
        trimmed = 0
        for row in selected:
            if used + len(row) + 1 > budget:
                trimmed = len(selected) - (len(out) - len(header_block))
                break
            out.append(row)
            used += len(row) + 1

        footer_bits = []
        total = len(data_rows)
        kept = len(out) - len(header_block)
        dropped_noise = total - len(selected)
        if dropped_noise > 0:
            footer_bits.append(
                str(dropped_noise) + " idle-UP tunnel(s) hidden"
            )
        if trimmed > 0:
            footer_bits.append(
                str(trimmed) + " more relevant row(s) trimmed to fit; "
                + "full output in Jenkins build log"
            )
        if kept == 0:
            # Nothing survived - tell the NOC clearly.
            return (
                "(all " + str(total)
                + " tunnel(s) idle-UP with zero traffic; "
                + "no DOWN / active row to highlight)"
            )
        if footer_bits:
            out.append("(" + "; ".join(footer_bits) + ")")
        return "\n".join(out)

    def normalize_credentials(self, credentials):
        """Flatten any supported `credentials` shape into a list of
        {username,password} dicts suitable for the login loop.

        Accepts (prod + SIT observed):
          * list of dicts     [{username,password,type?}, ...]
          * dict of dicts     {cinfo_3:{username,password}, cinfo_4:...}
          * dict of lists     {cinfo_3:[{...}], cinfo_4:[{...}]}
          * mixed nesting     {cinfo_3:[{username,password}]}
          * None / empty      -> []
        Returns a stable [{username,password}, ...] with falsy / incomplete
        entries removed. Never raises on unexpected input.
        """
        def take(entry):
            if not isinstance(entry, dict):
                return None
            u = entry.get("username")
            p = entry.get("password")
            if not u or not p:
                return None
            return {"username": str(u), "password": str(p)}

        out = []
        if credentials is None:
            return out
        if isinstance(credentials, list):
            for e in credentials:
                row = take(e)
                if row is not None:
                    out.append(row)
            return out
        if isinstance(credentials, dict):
            for _k, v in credentials.items():
                if isinstance(v, dict):
                    row = take(v)
                    if row is not None:
                        out.append(row)
                elif isinstance(v, list):
                    for e in v:
                        row = take(e)
                        if row is not None:
                            out.append(row)
            return out
        return out

    _MASTER_TRIGGER_SUBS = (
        (re.compile(r"authentication\s+failed", re.I),       "auth rejected"),
        (re.compile(r"destination\s+host\s+unreachable", re.I),"dest host unreachable"),
        (re.compile(r"100%\s+packet\s+loss", re.I),           "100% loss"),
    )

    def scrub_master_triggers(self, text):
        """Replace master-template `is_failed` trigger substrings with
        equivalent phrases so free-text passed through to response_msg
        (CLI dumps, vManage error rows) cannot accidentally flip the
        role's success-path run to NOC. The three substrings mirror the
        master's regex: `100% packet loss | authentication failed |
        destination host unreachable`. Non-string input is returned as-is.
        """
        if text is None:
            return ""
        if not isinstance(text, str):
            try:
                text = str(text)
            except Exception:
                return ""
        for pat, repl in self._MASTER_TRIGGER_SUBS:
            text = pat.sub(repl, text)
        return text

    # ===========================================================================
    # v27.1.40 F5+F6 — Secondary-router MOP evidence helpers.
    # Mirror legacy Cisco-Router-Device-Down task 1253 (dying-gasp check)
    # and task 1262M (secondary-side MOP probe) which are prod-proven on
    # the legacy router role. Added here so the Viptela role surfaces the
    # same MOP evidence to NOC when both two-hops to the primary fail.
    # ===========================================================================

    def parse_dying_gasp_from_logs(self, log_text):
        """Scan secondary's syslog for a dying-gasp line attributable to
        the primary. Legacy Cisco-Router-Device-Down check: a line
        containing 'dying' (case-insensitive) that is NOT the role's own
        "no dying-gasp entries" placeholder. Returns:
            {"seen": bool, "evidence": str}
        where `evidence` is the FIRST matching line (trimmed to 240 chars)
        so write_output can quote it to NOC without renders exploding.
        """
        if not log_text or not isinstance(log_text, str):
            return {"seen": False, "evidence": ""}
        low = log_text.lower()
        if "no dying-gasp entries" in low:
            return {"seen": False, "evidence": ""}
        if "dying" not in low:
            return {"seen": False, "evidence": ""}
        for line in log_text.splitlines():
            if "dying" in line.lower():
                return {"seen": True, "evidence": line.strip()[:240]}
        return {"seen": False, "evidence": ""}

    def summarize_secondary_mop(self, secondary_cli_output):
        """Summarize the dying-gasp + reload log evidence from the
        secondary's CLI output. Called by write_output.yaml OBSERVATION
        when both two-hops to the primary failed. Returns a dict:
            {"dying_gasp_seen": bool,
             "dying_gasp_line": str,
             "reload_lines":    str,
             "summary":         str}
        Non-dict input returns an empty-evidence skeleton. The `summary`
        is a one-line human sentence suitable for the OBSERVATION bullet.
        """
        if not isinstance(secondary_cli_output, dict):
            return {"dying_gasp_seen": False, "dying_gasp_line": "",
                    "reload_lines": "", "summary":
                    "no secondary CLI available to probe for MOP evidence"}
        dg_raw = secondary_cli_output.get("dying_gasp_log") or ""
        rl_raw = secondary_cli_output.get("reload_log") or ""
        dg = self.parse_dying_gasp_from_logs(dg_raw)
        # Reload lines: keep up to last 3 lines, each trimmed to 240 chars.
        rl_lines = []
        for line in (rl_raw.splitlines() if isinstance(rl_raw, str) else []):
            s = line.strip()
            if s and "reload" in s.lower():
                rl_lines.append(s[:240])
        rl_lines = rl_lines[-3:]
        rl_text = " | ".join(rl_lines) if rl_lines else ""
        if dg["seen"]:
            summary = ("DYING-GASP from primary seen in secondary syslog "
                       "(power loss likely)")
        elif rl_text:
            summary = ("No dying-gasp; secondary syslog shows reload "
                       "line(s) attributable to primary - review for "
                       "crash/panic")
        else:
            summary = ("No dying-gasp and no reload evidence in secondary "
                       "syslog - power loss not confirmed")
        return {"dying_gasp_seen": dg["seen"],
                "dying_gasp_line": dg["evidence"],
                "reload_lines":    rl_text,
                "summary":         summary}
