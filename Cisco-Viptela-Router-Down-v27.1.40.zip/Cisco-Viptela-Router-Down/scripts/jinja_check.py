#!/usr/bin/env python3
"""Pre-commit / CI gate: Jinja structural parse check for every YAML task
file in the role. Exits non-zero if any Jinja fragment inside a `content:`,
`msg:`, `set_fact:` or similar block is structurally invalid.

v27.1.14 E11 — added after v27.1.9 shipped an orphan {% endif %} in
write_output.yaml that only tripped at render time (per host, per task).
Ansible 2.9 does not surface this at play-start, so the role would deploy,
run through phases 1-5, and die at task 7010 with "Encountered unknown
tag 'endif'". A one-line structural parse here would have caught it in
50 ms.

Usage:
  python3 scripts/jinja_check.py            # check all tasks/*.yaml
  python3 scripts/jinja_check.py tasks/write_output.yaml

Return:
  0 — all templates parse cleanly
  1 — one or more templates have Jinja syntax errors; stderr lists them

To wire into CI (Jenkins / GitHub Actions / pre-commit):
  python3 scripts/jinja_check.py || exit 1
"""
import glob
import os
import re
import sys

try:
    from jinja2 import Environment
    from jinja2.exceptions import TemplateSyntaxError
except ImportError:
    print("ERROR: jinja2 not installed. `pip3 install --break-system-packages jinja2`",
          file=sys.stderr)
    sys.exit(2)


# v27.1.18: BROADENED. Previously only matched `content|msg|data|body|argv`,
# which missed the `set_fact:` scalar form (`is_flapping: >-`) where the
# v27.1.14 E5 bug hid for three revisions. Now matches ANY YAML key whose
# value starts with `|` or `>` and whose content contains Jinja — which
# includes `set_fact: FACT_NAME: >-` after we descend one level.
_CONTENT_START = re.compile(
    r'^\s*([A-Za-z_][A-Za-z_0-9]*)\s*:\s*[|>]-?\s*$')
_INLINE_JINJA  = re.compile(r'{%|{{')
# Patterns the Jinja parser doesn't catch cleanly for folded scalars but
# which NOC bugs reliably take: `#` comment inside a `{{ ... }}` block.
# Jinja comments are `{# ... #}`; a bare `#` inside an expression is a
# syntax error that only fires at render time, per host, per task.
_HASH_INSIDE_EXPR = re.compile(r'{{[^{}]*?#.*?}}', re.DOTALL)


def _extract_jinja_blocks(path):
    """Yield (line_number, text) for each Jinja-bearing block in a file.

    - Multi-line YAML scalars started by `key: |` or `key: >` are collected
      as one block starting at the opening line.
    - Single-line Jinja expressions (containing `{{` or `{%`) are returned
      individually.
    """
    with open(path, encoding='utf-8') as f:
        lines = f.readlines()

    i = 0
    while i < len(lines):
        ln = lines[i]
        if _CONTENT_START.match(ln):
            # Multi-line scalar: collect until dedent
            start = i + 1
            indent = None
            buf = []
            j = i + 1
            while j < len(lines):
                nxt = lines[j]
                if nxt.strip() == '':
                    buf.append('')
                    j += 1
                    continue
                stripped_indent = len(nxt) - len(nxt.lstrip())
                if indent is None:
                    indent = stripped_indent
                if stripped_indent < indent:
                    break
                buf.append(nxt[indent:].rstrip('\n'))
                j += 1
            # Check multi-line scalars that contain either:
            #   (a) {% ... %} block tags — the orphan-endif / orphan-endfor
            #       class of bug that hit v27.1.9
            #   (b) a `{{` opening expression — v27.1.14 E5 class of bug
            #       (bare `#` inside, or missing `}}` because the folded
            #       scalar swallowed it into a `# comment`)
            if buf and any(
                re.search(r'{%\s*(if|for|elif|else|endif|endfor)\b', b)
                or ('{{' in b)
                for b in buf
            ):
                yield (start, '\n'.join(buf))
            i = j
            continue
        i += 1


def check(paths):
    env = Environment()
    # Register placeholders for custom filters so parse succeeds without
    # importing the plugin. Jinja parse does NOT require the filters to
    # exist — only render does — but we add them for safety across Jinja
    # versions.
    env.filters['_stub'] = lambda v, *a, **kw: v
    bad = 0
    for path in paths:
        if not os.path.exists(path):
            print(f"[warn] {path}: not found", file=sys.stderr)
            continue
        for line, block in _extract_jinja_blocks(path):
            # Catch v27.1.14 E5 class: `#` inside `{{ ... }}` or an
            # unclosed `{{` whose closing `}}` got swallowed by a
            # comment. Jinja parse ALONE misses this if the folded
            # scalar form elides newlines before parsing.
            if _HASH_INSIDE_EXPR.search(block):
                print(f"[FAIL] {path}:{line}: `#` comment found inside a "
                      f"{{{{ ... }}}} expression — Jinja comments must "
                      f"use {{# ... #}} form, and `#` is not valid inside"
                      f" an expression. Move the comment ABOVE the task.",
                      file=sys.stderr)
                bad += 1
                continue
            # Also catch an opening `{{` with no closing `}}` on the
            # same block — the folded `>-` form will concatenate lines
            # and if the comments ate the close, the parser error is
            # cryptic. Pre-check cleanly.
            if block.count('{{') != block.count('}}'):
                print(f"[FAIL] {path}:{line}: unbalanced {{{{ vs }}}} "
                      f"in block ({block.count('{{')} opens, "
                      f"{block.count('}}')} closes) — likely a `#` "
                      f"comment ate the closing brace in a folded "
                      f"`>-` scalar.", file=sys.stderr)
                bad += 1
                continue
            try:
                env.parse(block)
            except TemplateSyntaxError as e:
                abs_line = line + (e.lineno or 1) - 1
                print(f"[FAIL] {path}:{abs_line}: {e.message}", file=sys.stderr)
                bad += 1
    if bad == 0:
        print(f"[OK] {len(paths)} file(s) — all Jinja blocks parse cleanly")
        return 0
    print(f"[FAIL] {bad} Jinja syntax error(s)", file=sys.stderr)
    return 1


def main():
    if len(sys.argv) > 1:
        paths = sys.argv[1:]
    else:
        here = os.path.dirname(os.path.abspath(__file__))
        role = os.path.dirname(here)
        paths = sorted(glob.glob(os.path.join(role, 'tasks', '*.yaml')) +
                       glob.glob(os.path.join(role, 'tasks', '*.yml')))
    sys.exit(check(paths))


if __name__ == '__main__':
    main()
