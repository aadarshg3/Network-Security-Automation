#!/usr/bin/env python3
"""SSH collection and remediation script for BGP-Router-Up-Down-Viptela.

Supports Cisco Viptela SD-WAN vEdge (Viptela OS) and cEdge (IOS-XE SD-WAN).
Emits a single JSON object to stdout for Ansible to branch on `success`.

Modes:
  primary      - platform detect + BGP/health diagnostic bundle
  recheck      - re-read BGP session state after a change
  device_ping  - device-sourced ping to the BGP peer (VPN/VRF aware)
  clear        - clear the stuck BGP session(s), then re-read state
  bounce       - shut/no-shut a LAN interface (dual commit), then verify
  evidence     - collect route/ARP/BGP-neighbor/CPU/memory when peer unreachable
  sibling      - v3.13: read-only transport view of the partner router

Security: the SSH password is NEVER read from argv (which is visible in
/proc/<pid>/cmdline). It is taken from the VIPTELA_SSH_PASSWORD environment
variable, an optional --password-file, or stdin. Only non-secret call
parameters (host, platform, peer IP, VPN id, interface) are passed on argv.

Target runtime is /usr/bin/python3.12 on the PROD automation host (paramiko
installed there); syntax stays 3.6-compatible as a safety margin. Do NOT add
`from __future__ import annotations` (PEP 563 requires 3.7+). The annotations
used here are 3.6-compatible.
"""

import argparse
import getpass
import json
import logging
import os
import re
import socket
import sys
import time
from typing import Dict, List, Optional

try:
    import paramiko
except ImportError:
    print(json.dumps({"success": False, "error": "paramiko not installed",
                      "outputs": {}, "errors": {}, "platform": ""}))
    sys.exit(0)

logging.basicConfig(level=logging.WARNING, stream=sys.stderr,
                    format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)


def cedge_primary_commands(peer_ip: str, vpn_id: str) -> Dict[str, str]:
    """cEdge (IOS-XE SD-WAN) diagnostic bundle. Command spellings follow the
    provided device reference (Cedge.docx) and the MOP."""
    cmds = {
        # platform + template detection
        "system_status":      "show sdwan system status",
        "version":            "show version",
        # health / transport context
        "control_connections": "show sdwan control connections",
        "control_history":    "show sdwan control connection-history",
        "wan_interface_list": "show sdwan control local-properties wan-interface-list",
        "bfd_sessions":       "show sdwan bfd sessions",
        "interfaces_desc":    "show interfaces description",
        "ip_int_brief":       "show ip interface brief",
        # v3.13 (prod 2614): interface subnets, to find the interface towards
        # the BGP peer even when that link is down (tunnels included).
        "ip_int_addr":        "show ip interface | include line protocol|Internet address",
        "arp":                "show arp",
        "vrf":                "show ip vrf",
        # BGP state (MOP + prod review): 'show ip bgp all summary' spans EVERY
        # address family / VRF, so cEdge service-VPN peers (which tunnel to the
        # customer FW/PIP and are invisible to the default-VRF 'show ip bgp
        # summary') are captured. 'vpnv4 all' is kept as corroboration. Using
        # the default-VRF summary alone was why cEdge pulled the wrong/absent
        # peer in prod.
        "bgp_summary":        "show ip bgp all summary",
        "bgp_summary_vpnv4":  "show ip bgp vpnv4 all summary",
        "bgp_neighbors":      "show ip bgp neighbors",
        "bgp_config":         "show running-config | section bgp",
        "logging_bgp":        "show logging | include BGP",
        # NOC runs this on every BGP ticket (Sep 2026 ticket review); the
        # vEdge bundle already had it.
        "omp_peers":          "show sdwan omp peers",
        # v3.14 (prod 20821): the device rejected the SD-WAN and log commands
        # for the automation login; the privilege level is read so the ticket
        # can state it as a fact. Read-only.
        "privilege":          "show privilege",
        # v3.15 (MOP review 14-Oct-2026): the MOP Tier-2 list (show processes
        # cpu / memory / platform health) on EVERY ticket, not only on the
        # neighbor-unreachable path. One-line filters keep the reads short;
        # IOS-XE 'show platform resources' is used for 'platform health'.
        "cpu_util":           "show processes cpu | include CPU utilization",
        "mem_pool":           "show processes memory | include Pool Total",
        "platform_res":       "show platform resources",
    }
    # Service-VPN alarm (alarm TEXT ends in a VPN number other than 0): read
    # that VRF's BGP table explicitly, because 'show ip bgp all summary' does
    # not say which VRF a VPNv4 neighbor belongs to. Read-only command.
    if vpn_id and str(vpn_id).strip() not in ("0", "", "global"):
        cmds["bgp_summary_vrf"] = "show ip bgp vpnv4 vrf {vpn} summary".format(
            vpn=str(vpn_id).strip())
        # v3.15 (MOP: 'show bgp vpnv4 vrf neighbors' - state, hold/keepalive
        # timers, last reset) for the alarm VRF on every path. Read-only.
        cmds["bgp_neighbors_vrf"] = "show ip bgp vpnv4 vrf {vpn} neighbors".format(
            vpn=str(vpn_id).strip())
    if peer_ip:
        cmds["bgp_neighbor_peer"] = "show ip bgp neighbors {ip}".format(ip=peer_ip)
        cmds["bgp_vpnv4_peer"] = "show ip bgp vpnv4 all neighbors {ip}".format(ip=peer_ip)
        cmds["ip_route_peer"] = "show ip route {ip}".format(ip=peer_ip)
    return cmds


def vedge_primary_commands(peer_ip: str, vpn_id: str) -> Dict[str, str]:
    """vEdge (Viptela OS) diagnostic bundle. Command spellings follow the
    provided device reference (Vedge.docx) and the MOP."""
    v = vpn_id if (vpn_id and vpn_id not in ("0", "", "global")) else "0"
    cmds = {
        "system_status":      "show system status",
        "version":            "show version",
        "control_connections": "show control connections",
        "control_history":    "show control connections history",
        "wan_interface_list": "show control local-properties wan-interface-list",
        "bfd_sessions":       "show bfd sessions",
        "interfaces_desc":    "show interface description",
        "omp_peers":          "show omp peers",
        "arp":                "show arp vpn {vpn}".format(vpn=v),
        # BGP state (MOP)
        "bgp_summary":        "show bgp summary",
        "bgp_neighbor":       "show bgp neighbor",
        "bgp_config":         "show running-config vpn {vpn} router bgp".format(vpn=v),
        # Viptela vEdge log command is 'show log' (MOP: 'show log | i BGP');
        # 'show logging' is IOS-XE/cEdge syntax and errors on vEdge.
        "logging_bgp":        "show log | include BGP",
    }
    if v != "0":
        cmds["ip_routes_vpn"] = "show ip routes vpn {vpn}".format(vpn=v)
    else:
        cmds["ip_routes"] = "show ip routes"
    return cmds


def cedge_evidence_commands(peer_ip: str, vpn_id: str) -> Dict[str, str]:
    """cEdge neighbor-unreachable evidence (read-only)."""
    cmds = {
        "route_to_peer":  "show ip route {ip}".format(ip=peer_ip),
        "arp_peer":       "show arp | include {ip}".format(ip=peer_ip),
        "bgp_neighbor":   "show ip bgp neighbors {ip}".format(ip=peer_ip),
        "logging_bgp":    "show logging | include BGP",
        "cpu":            "show processes cpu sorted",
        "memory":         "show processes memory sorted",
        "platform_res":   "show platform resources",
    }
    # v3.9: service-VPN peer -> the VRF table (SD-WAN cEdge VRF name = VPN
    # number, e.g. prod log 'neighbor 10.33.28.114 vpn vrf 1'; Tier-2 used
    # 'ping vrf 1 <peer>'). Global-table lookups alone were misleading.
    v = str(vpn_id or "").strip()
    if v and v not in ("0", "global"):
        cmds["route_to_peer_vrf"] = "show ip route vrf {v} {ip}".format(v=v, ip=peer_ip)
        cmds["arp_peer_vrf"] = "show ip arp vrf {v} | include {ip}".format(v=v, ip=peer_ip)
        # v3.13 (prod 2614): 'show ip bgp neighbors <ip>' answers '% No such
        # neighbor' for a VRF peer; the VRF form returns its detail.
        cmds["bgp_neighbor_vrf"] = "show ip bgp vpnv4 vrf {v} neighbors {ip}".format(v=v, ip=peer_ip)
    return cmds


def sibling_commands(platform: str) -> Dict[str, str]:
    """v3.13: read-only transport view of the PARTNER router at a dual-router
    site (same spellings as the primary bundles): TLOC/WAN list with public
    and private IP, BFD sessions, control connections, interface status and
    descriptions. Same check as BFD-TLOC-VIPTELA-TRIAGE redundant_router."""
    if platform == "cedge":
        return {
            "wan_interface_list":  "show sdwan control local-properties wan-interface-list",
            "bfd_sessions":        "show sdwan bfd sessions",
            "control_connections": "show sdwan control connections",
            "interfaces_desc":     "show interfaces description",
            "ip_int_brief":        "show ip interface brief",
        }
    return {
        "wan_interface_list":  "show control local-properties wan-interface-list",
        "bfd_sessions":        "show bfd sessions",
        "control_connections": "show control connections",
        "interfaces_desc":     "show interface description",
    }


def vedge_evidence_commands(peer_ip: str, vpn_id: str) -> Dict[str, str]:
    """vEdge neighbor-unreachable evidence (read-only)."""
    v = vpn_id if (vpn_id and vpn_id not in ("0", "", "global")) else "0"
    return {
        "routes":         "show ip routes vpn {vpn}".format(vpn=v),
        "arp_peer":       "show arp vpn {vpn} | include {ip}".format(vpn=v, ip=peer_ip),
        "bgp_neighbor":   "show bgp neighbor",
        "logging_bgp":    "show log | include BGP",
        "sys_status":     "show system status",
    }


class ViptelaSSH:
    """Paramiko-based interactive SSH session for Viptela SD-WAN devices.

    Paramiko (not netmiko) is used deliberately: on vEdge, netmiko's
    cisco_ios driver sends 'terminal length 0', which the Viptela CLI does not
    accept and which causes paging hangs. A raw interactive shell lets us send
    all three paging-disable variants and drive config/commit sequences.
    """

    _RECV_CHUNK          = 65535
    _MAX_OUTPUT_BYTES    = 4_000_000
    _MAX_COMMAND_SECONDS = 120.0
    _KEEPALIVE_SECONDS   = 30
    # v3.11 prompt-based read (see send_command). Prod cEdge 'show sdwan ...'
    # replies can start later than the 2-3 s idle window, which made the reply
    # land in the NEXT command's buffer (tickets 2026100802150 / 02152).
    _SHELL_WAIT_SECONDS = 20.0       # v3.13: max wait for the first shell byte
    _PROMPT_SILENCE_SECONDS = 20.0   # silence after real output, no prompt
    _PROMPT_WAIT_SECONDS    = 45.0   # no output at all after the echo
    _PROMPT_MAX_MISSES      = 2      # then fall back to idle-wait reads

    def __init__(self, host, username, password, port=22, timeout=30,
                 known_hosts_path=None, allow_unknown_hosts=False):
        self.host = host
        self.username = username
        self.password = password
        self.port = port
        self.timeout = max(1, int(timeout))
        self.known_hosts_path = known_hosts_path
        self.allow_unknown_hosts = allow_unknown_hosts
        self._client = None       # type: Optional[paramiko.SSHClient]
        self._channel = None      # type: Optional[paramiko.Channel]
        self._transport = None    # type: Optional[paramiko.Transport]
        # v3.11: per-session read state (instance attributes, no globals).
        # BGP_SSH_READ_MODE=idle restores the v3.10 idle-wait reads exactly.
        self.read_mode = (os.environ.get("BGP_SSH_READ_MODE", "prompt") or "prompt").strip().lower()
        self._prompt_re = None    # learned device prompt (compiled regex)
        self._prompt_misses = 0
        self.timings = {}         # type: Dict[str, Dict[str, object]]
        self.probe_summary = {}   # type: Dict[str, str]

    def connect(self):
        """Open the SSH connection and an interactive shell with paging off."""
        self._client = paramiko.SSHClient()
        if self.known_hosts_path and os.path.exists(self.known_hosts_path):
            try:
                self._client.load_host_keys(self.known_hosts_path)
            except (OSError, paramiko.SSHException):
                pass
        if self.allow_unknown_hosts:
            self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        else:
            self._client.set_missing_host_key_policy(paramiko.RejectPolicy())

        try:
            self._client.connect(
                hostname=self.host, port=self.port, username=self.username,
                password=self.password, timeout=self.timeout,
                auth_timeout=self.timeout, look_for_keys=False,
                allow_agent=False, banner_timeout=30,
            )
        except paramiko.AuthenticationException:
            # Some Viptela builds advertise keyboard-interactive only.
            transport = paramiko.Transport((self.host, self.port))
            transport.banner_timeout = 30
            try:
                transport.start_client(timeout=self.timeout)
                if not self.allow_unknown_hosts:
                    remote_key = transport.get_remote_server_key()
                    host_keys = self._client.get_host_keys()
                    known = host_keys.lookup(self.host) or {}
                    stored = known.get(remote_key.get_name())
                    if stored is None or stored.asbytes() != remote_key.asbytes():
                        raise paramiko.SSHException(
                            "Server '%s' host key not in known_hosts "
                            "(keyboard-interactive fallback)" % self.host)
                try:
                    transport.auth_interactive(
                        self.username,
                        lambda title, instr, prompts: [self.password] * len(prompts),
                    )
                except paramiko.SSHException as exc:
                    raise paramiko.AuthenticationException(str(exc))
            except (paramiko.SSHException, OSError):
                try:
                    transport.close()
                except (paramiko.SSHException, OSError):
                    pass
                raise
            self._transport = transport
            self._client._transport = transport  # noqa: SLF001

        try:
            t = self._client.get_transport()
            if t is not None:
                t.set_keepalive(self._KEEPALIVE_SECONDS)
        except Exception:
            pass

        self._channel = self._client.invoke_shell(width=250, height=200)
        self._wait_for_shell()
        time.sleep(1.0)
        self._drain()
        self._disable_paging()
        time.sleep(1.5)
        self._drain()
        self._learn_prompt()

    def _wait_for_shell(self):
        """v3.13 (prod 2026101202106, build 20594): login succeeded but the
        shell sent NOTHING - no banner, prompt or echo - for every probe
        (0 chars, prompt not learned), seen on an ISR1100 running Viptela OS
        17.12. Wait (bounded) for the first byte of the shell, nudging with
        a newline, before paging-off / prompt learning. Returns at once on a
        device that answers immediately; adds at most _SHELL_WAIT_SECONDS."""
        if self._channel is None:
            return
        start = time.time()
        nudged = start
        try:
            while time.time() - start < self._SHELL_WAIT_SECONDS:
                if self._channel.recv_ready():
                    break
                if time.time() - nudged >= 5.0:
                    self._channel.sendall(b"\n")
                    nudged = time.time()
                time.sleep(0.2)
            ready = bool(self._channel.recv_ready())
        except (paramiko.SSHException, OSError):
            ready = False
        self.timings["(shell start)"] = {"s": round(time.time() - start, 1), "output": ready}

    def _learn_prompt(self):
        """v3.11: read the exec prompt once (e.g. 'HOST#', 'host# ') so each
        command is read until the prompt returns. Config-mode prompts
        ('HOST(config)#', 'host(config-vpn-0)#') match the same pattern.
        No prompt learned -> idle-wait reads (v3.10 behaviour)."""
        if self._channel is None or self.read_mode == "idle":
            return
        try:
            self._channel.sendall(b"\n")
        except (paramiko.SSHException, OSError):
            return
        time.sleep(0.8)
        text = self._drain()
        lines = [ln.strip() for ln in text.replace("\r", "\n").split("\n") if ln.strip()]
        if not lines:
            logger.info("prompt not learned on %s (no output)", self.host)
            return
        m = re.match(r"^([A-Za-z0-9][A-Za-z0-9_.:/@-]*?)(\([^)]*\))?\s*([#>])$", lines[-1])
        if not m:
            logger.info("prompt not learned on %s (last line not a prompt)", self.host)
            return
        self._prompt_re = re.compile(r"^" + re.escape(m.group(1)) + r"(\([^)]*\))?\s*[#>]$")

    def _prompt_mode(self):
        return (self.read_mode != "idle" and self._prompt_re is not None
                and self._prompt_misses < self._PROMPT_MAX_MISSES)

    def _ends_with_prompt(self, output):
        if self._prompt_re is None or not output:
            return False
        tail = output[-300:].decode("utf-8", errors="replace").replace("\r", "\n")
        last = tail.split("\n")[-1].strip()
        return bool(last) and self._prompt_re.match(last) is not None

    @staticmethod
    def _has_body(output, command):
        """True when anything other than the echoed command was received."""
        text = output.decode("utf-8", errors="replace").replace("\r", "\n")
        lines = [ln.strip() for ln in text.split("\n") if ln.strip()]
        if lines and lines[0].endswith(command.strip()):
            lines = lines[1:]
        return bool(lines)

    def _quick_drain(self):
        """Discard anything already waiting (late output of an earlier
        command) so it is never attributed to the next command."""
        out = b""
        try:
            while self._channel is not None and self._channel.recv_ready():
                chunk = self._channel.recv(self._RECV_CHUNK)
                if not chunk:
                    break
                out += chunk
                time.sleep(0.05)
        except (paramiko.SSHException, OSError):
            pass
        return out.decode("utf-8", errors="replace")

    def _drain(self):
        if self._channel is None:
            return ""
        output = b""
        deadline = time.time() + 3.0
        try:
            while time.time() < deadline:
                if self._channel.recv_ready():
                    chunk = self._channel.recv(self._RECV_CHUNK)
                    if not chunk:
                        break
                    output += chunk
                    deadline = time.time() + 0.5
                else:
                    time.sleep(0.1)
        except (paramiko.SSHException, OSError):
            return output.decode("utf-8", errors="replace")
        return output.decode("utf-8", errors="replace")

    def _disable_paging(self):
        if self._channel is None:
            return
        for cmd in ("terminal length 0", "paginate false", "screen-length 0"):
            try:
                self._channel.sendall((cmd + "\n").encode("utf-8"))
                time.sleep(0.4)
                self._drain()
            except (paramiko.SSHException, OSError):
                logger.debug("paging command %r not accepted on %s", cmd, self.host)

    def send_command(self, command, idle_wait=2.0):
        """Send one command and collect its output.

        v3.11: when the device prompt is known, read until the prompt comes
        back (bounded by _PROMPT_* limits) instead of stopping after
        `idle_wait` seconds of silence. Two prompt misses in one session ->
        idle-wait reads for the rest of it (v3.10 behaviour)."""
        if self._channel is None:
            raise RuntimeError("channel not open")
        stale = self._quick_drain()
        if stale.strip():
            logger.info("discarded %d chars of late output before %r on %s",
                        len(stale), command, self.host)
        use_prompt = self._prompt_mode()
        self._channel.sendall((command + "\n").encode("utf-8"))
        time.sleep(0.3)
        output = b""
        last_recv = time.time()
        started = time.time()
        truncated = False
        prompt_seen = False
        while True:
            try:
                if self._channel.recv_ready():
                    chunk = self._channel.recv(self._RECV_CHUNK)
                    if not chunk:
                        break
                    output += chunk
                    last_recv = time.time()
                    tail = output[-32:].lower()
                    if b"--more--" in tail:
                        try:
                            self._channel.sendall(b"q")
                        except (paramiko.SSHException, OSError):
                            pass
                    if len(output) >= self._MAX_OUTPUT_BYTES:
                        truncated = True
                        logger.warning("Output cap hit for %r on %s", command, self.host)
                        break
                    if use_prompt and self._ends_with_prompt(output):
                        prompt_seen = True
                        break
                    continue
                now = time.time()
                if now - started > self._MAX_COMMAND_SECONDS:
                    truncated = True
                    logger.warning("Command %r exceeded %.0fs on %s",
                                   command, self._MAX_COMMAND_SECONDS, self.host)
                    break
                if use_prompt:
                    if self._has_body(output, command):
                        if now - last_recv > self._PROMPT_SILENCE_SECONDS:
                            break
                    elif now - started > self._PROMPT_WAIT_SECONDS:
                        break
                elif now - last_recv > idle_wait:
                    break
                time.sleep(0.05)
            except (paramiko.SSHException, OSError) as exc:
                logger.warning("recv failed on %s: %s", self.host, exc)
                break
        if use_prompt and not prompt_seen and not truncated:
            self._prompt_misses += 1
            logger.warning("prompt not seen after %r on %s (miss %d)",
                           command, self.host, self._prompt_misses)
        self.timings[command] = {"s": round(time.time() - started, 1),
                                 "prompt": prompt_seen}
        cleaned = self._clean_output(output.decode("utf-8", errors="replace"), command)
        if truncated:
            cleaned += "\n... (output truncated by collection limits) [TRUNCATED]"
        return cleaned

    def _clean_output(self, raw, command):
        lines = raw.splitlines()
        cleaned = []
        echo_seen = False
        cmd_full = command.strip()
        for line in lines:
            if not echo_seen and line.strip():
                if line.rstrip().endswith(cmd_full):
                    echo_seen = True
                    continue
                echo_seen = True
                cleaned.append(line)
                continue
            cleaned.append(line)
        while cleaned:
            last = cleaned[-1].rstrip()
            if last and re.match(r"\S+[#>$]\s*$", last):
                cleaned.pop()
            else:
                break
        return "\n".join(cleaned)

    @staticmethod
    def _is_invalid_command(lower_output):
        markers = ("invalid input", "% invalid", "syntax error", "unknown command",
                   "% unrecognized", "incomplete command", "% ambiguous",
                   "command not found")
        return any(m in lower_output for m in markers)

    def detect_platform(self):
        """Auto-detect cedge/vedge. Returns '' (unknown) so the caller escalates
        rather than sending the wrong platform's CLI.

        v3.11: every probe's text is kept, including one that also carries an
        error line. A late reply can share a buffer with the next probe's
        '% Invalid input' line; v3.10 discarded the whole buffer, so a slow
        cEdge ended as PlatformDetectionFailed (ticket 2026100802150). Error
        text holds no platform marker, so keeping it cannot mis-detect."""
        combined = ""
        self.probe_summary = {}
        for cmd in ("show sdwan system status", "show system status", "show version"):
            try:
                out = self.send_command(cmd, idle_wait=3.0)
            except Exception as exc:
                self.probe_summary[cmd] = "error: %s" % type(exc).__name__
                logger.debug("%s probe failed on %s: %s", cmd, self.host, exc)
                continue
            first = next((ln.strip() for ln in out.splitlines() if ln.strip()), "")
            self.probe_summary[cmd] = "%d chars%s; first line: %s" % (
                len(out), " (has error line)" if self._is_invalid_command(out.lower()) else "",
                first[:80])
            combined += out + "\n"
            low = combined.lower()
            if re.search(r"device role\s*:\s*(cedge|sdwan\s+edge)", low) or "cedge-sdwan" in low:
                return "cedge"

        lower = combined.lower()
        if not lower.strip():
            return ""
        if "controller-managed" in lower or "cisco ios xe" in lower or "ios-xe" in lower:
            return "cedge"
        # vEdge model marker before the ISR/CSR hardware heuristic: a vEdge on
        # ISR-class hardware reports 'Model name: vedge-ISR1100-...'.
        if re.search(r"\bmodel\s*name\s*:\s*vedge", lower):
            return "vedge"
        if re.search(r"\b(csr1000v|csr\d+|c8[0-9]{3}|isr\d+|asr\d+|c11\d{2})\b", lower):
            return "cedge"
        cs = len(re.findall(r"\b17\.\d|\b16\.\d|\bxe software\b|\bsdwan-enabled\b", lower))
        vs = len(re.findall(r"\b18\.\d|\b19\.\d|\b20\.\d|\b21\.\d|\b22\.\d", lower))
        if cs == 0 and vs == 0:
            return ""
        return "cedge" if cs > vs else "vedge"

    def run_commands(self, commands):
        """Run a {name: command} dict; return {name: {ok, output, error}}."""
        results = {}
        for name, cmd in commands.items():
            if not cmd:
                continue
            try:
                out = self.send_command(cmd)
                results[name] = {"ok": True, "output": out, "error": ""}
            except Exception as exc:
                results[name] = {"ok": False, "output": "", "error": str(exc)}
                logger.warning("Command %r failed on %s: %s", cmd, self.host, exc)
        return results

    def config_bounce(self, platform, interface, vpn_id):
        """Shut then no-shut a LAN interface with a DUAL commit.

        Candidate-config systems need two separate commits (shut+commit, wait,
        no-shut+commit); a single commit that both shuts and un-shuts is a
        zero net diff. cEdge uses config-transaction; vEdge uses config with a
        vpn context.
        Returns the combined transcript string.
        """
        out = []
        v = vpn_id if (vpn_id and str(vpn_id).strip()) else "0"
        try:
            if platform == "cedge":
                shut_seq = ["config-transaction", "interface %s" % interface,
                            "shutdown", "commit", "end"]
                noshut_seq = ["config-transaction", "interface %s" % interface,
                              "no shutdown", "commit", "end"]
                verify = "show ip interface brief | include %s" % interface
            else:
                shut_seq = ["config", "vpn %s" % v, "interface %s" % interface,
                            "shutdown", "commit", "end"]
                noshut_seq = ["config", "vpn %s" % v, "interface %s" % interface,
                              "no shutdown", "commit", "end"]
                verify = "show interface vpn %s | include %s" % (v, interface)
            for c in shut_seq:
                out.append("+ %s\n%s" % (c, self.send_command(c, idle_wait=4.0)))
            time.sleep(10)
            for c in noshut_seq:
                out.append("+ %s\n%s" % (c, self.send_command(c, idle_wait=4.0)))
            time.sleep(3)
            out.append("+ %s\n%s" % (verify, self.send_command(verify, idle_wait=4.0)))
        except Exception as exc:
            out.append("ERROR during config bounce: %s" % exc)
        return "\n".join(out)

    def disconnect(self):
        for closer in (self._channel, self._client, self._transport):
            try:
                if closer is not None:
                    closer.close()
            except (paramiko.SSHException, OSError):
                pass

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *_):
        self.disconnect()


def _flatten(results):
    flat = {}
    for name, entry in (results or {}).items():
        flat[name] = entry.get("output", "") if isinstance(entry, dict) else str(entry)
    return flat


def _errors_of(results):
    errs = {}
    for name, entry in (results or {}).items():
        if isinstance(entry, dict) and not entry.get("ok", True) and entry.get("error"):
            errs[name] = entry["error"]
    return errs


def _resolve_platform(ssh, platform):
    if not platform or platform not in ("cedge", "vedge"):
        platform = ssh.detect_platform()
    return platform


def _read_info(ssh):
    """v3.11: non-secret read diagnostics for the Jenkins log (command names,
    seconds, prompt seen, probe first lines). Never outputs or credentials."""
    return {"read_mode": "prompt" if ssh._prompt_re is not None and ssh.read_mode != "idle" else "idle",
            "prompt_misses": ssh._prompt_misses,
            "timings": ssh.timings, "probe": ssh.probe_summary}


def run_primary(host, username, password, platform, timeout, peer_ip, vpn_id, **kw):
    with ViptelaSSH(host, username, password, timeout=timeout, **kw) as ssh:
        platform = _resolve_platform(ssh, platform)
        if platform not in ("cedge", "vedge"):
            return {"success": False, "platform": "", "outputs": {}, "errors": {},
                    "error": "PlatformDetectionFailed", "read_info": _read_info(ssh)}
        cmds = (cedge_primary_commands(peer_ip, vpn_id) if platform == "cedge"
                else vedge_primary_commands(peer_ip, vpn_id))
        structured = ssh.run_commands(cmds)
        any_good = any(e.get("ok") and (e.get("output") or "").strip()
                       for e in structured.values())
        return {"success": bool(any_good), "platform": platform,
                "outputs": _flatten(structured), "errors": _errors_of(structured),
                "error": None, "read_info": _read_info(ssh)}


def run_recheck(host, username, password, platform, timeout, peer_ip, vpn_id, **kw):
    with ViptelaSSH(host, username, password, timeout=timeout, **kw) as ssh:
        platform = _resolve_platform(ssh, platform)
        if platform not in ("cedge", "vedge"):
            return {"success": False, "platform": "", "outputs": {}, "errors": {},
                    "error": "PlatformDetectionFailed"}
        if platform == "cedge":
            cmds = {"bgp_summary": "show ip bgp all summary",
                    "bgp_neighbors": "show ip bgp neighbors"}
        else:
            cmds = {"bgp_summary": "show bgp summary"}
        structured = ssh.run_commands(cmds)
        any_good = any(e.get("ok") and (e.get("output") or "").strip()
                       for e in structured.values())
        return {"success": bool(any_good), "platform": platform,
                "outputs": _flatten(structured), "errors": _errors_of(structured),
                "error": None}


def run_device_ping(host, username, password, platform, timeout, peer_ip, vpn_id, **kw):
    if not peer_ip:
        return {"success": False, "platform": platform, "outputs": {}, "errors": {},
                "error": "DevicePingMissingPeer"}
    with ViptelaSSH(host, username, password, timeout=timeout, **kw) as ssh:
        platform = _resolve_platform(ssh, platform)
        v = vpn_id if (vpn_id and str(vpn_id).strip()) else "0"
        if platform == "vedge":
            cmds = {"ping_vpn": "ping %s vpn %s count 5" % (peer_ip, v),
                    "ping": "ping %s count 5" % peer_ip}
        else:
            # cEdge: plain IOS ping, plus (v3.9) a VRF ping for a service-VPN
            # peer - on SD-WAN cEdge the VRF name is the VPN number (prod:
            # 'neighbor 10.33.28.114 vpn vrf 1', Tier-2 'ping vrf 1 <peer>').
            cmds = {"ping": "ping %s repeat 5" % peer_ip}
            if v not in ("0", "global"):
                cmds["ping_vrf"] = "ping vrf %s %s repeat 5" % (v, peer_ip)
        structured = ssh.run_commands(cmds)
        any_good = any(e.get("ok") and (e.get("output") or "").strip()
                       for e in structured.values())
        return {"success": bool(any_good), "platform": platform,
                "outputs": _flatten(structured), "errors": _errors_of(structured),
                "error": None}


def run_clear(host, username, password, platform, timeout, peer_ip, vpn_id,
              clear_commands, **kw):
    """Send one or more BGP clear commands, then re-read BGP summary."""
    with ViptelaSSH(host, username, password, timeout=timeout, **kw) as ssh:
        platform = _resolve_platform(ssh, platform)
        if platform not in ("cedge", "vedge"):
            return {"success": False, "platform": "", "outputs": {}, "errors": {},
                    "error": "PlatformDetectionFailed"}
        structured = {}
        for idx, cmd in enumerate(clear_commands or []):
            try:
                out = ssh.send_command(cmd, idle_wait=5.0)
                structured["clear_%d" % idx] = {"ok": True, "output": out, "error": ""}
            except Exception as exc:
                structured["clear_%d" % idx] = {"ok": False, "output": "", "error": str(exc)}
        time.sleep(8)
        recheck_cmd = "show bgp summary" if platform == "vedge" else "show ip bgp all summary"
        try:
            structured["bgp_summary"] = {"ok": True,
                                         "output": ssh.send_command(recheck_cmd, idle_wait=4.0),
                                         "error": ""}
        except Exception as exc:
            structured["bgp_summary"] = {"ok": False, "output": "", "error": str(exc)}
        any_clear_ok = any(v.get("ok") for k, v in structured.items() if k.startswith("clear_"))
        return {"success": bool(any_clear_ok), "platform": platform,
                "outputs": _flatten(structured), "errors": _errors_of(structured),
                "error": None}


def run_bounce(host, username, password, platform, timeout, interface, vpn_id, **kw):
    """Interface shut/no-shut (dual commit) then verify + BGP recheck."""
    if not interface:
        return {"success": False, "platform": platform, "outputs": {}, "errors": {},
                "error": "BounceMissingInterface"}
    with ViptelaSSH(host, username, password, timeout=timeout, **kw) as ssh:
        platform = _resolve_platform(ssh, platform)
        if platform not in ("cedge", "vedge"):
            return {"success": False, "platform": "", "outputs": {}, "errors": {},
                    "error": "PlatformDetectionFailed"}
        transcript = ssh.config_bounce(platform, interface, vpn_id)
        recheck_cmd = "show bgp summary" if platform == "vedge" else "show ip bgp all summary"
        try:
            bgp = ssh.send_command(recheck_cmd, idle_wait=4.0)
        except Exception as exc:
            bgp = "ERROR: %s" % exc
        low = transcript.lower()
        failed = ("error during config" in low or "% invalid" in low
                  or "aborted" in low or "failure" in low)
        return {"success": not failed, "platform": platform,
                "outputs": {"bounce_transcript": transcript, "bgp_summary": bgp},
                "errors": {}, "error": None}


def run_evidence(host, username, password, platform, timeout, peer_ip, vpn_id, **kw):
    with ViptelaSSH(host, username, password, timeout=timeout, **kw) as ssh:
        platform = _resolve_platform(ssh, platform)
        if platform not in ("cedge", "vedge"):
            return {"success": False, "platform": "", "outputs": {}, "errors": {},
                    "error": "PlatformDetectionFailed"}
        cmds = (cedge_evidence_commands(peer_ip, vpn_id) if platform == "cedge"
                else vedge_evidence_commands(peer_ip, vpn_id))
        structured = ssh.run_commands(cmds)
        any_good = any(e.get("ok") and (e.get("output") or "").strip()
                       for e in structured.values())
        return {"success": bool(any_good), "platform": platform,
                "outputs": _flatten(structured), "errors": _errors_of(structured),
                "error": None}


def run_sibling(host, username, password, platform, timeout, **kw):
    """v3.13: partner-router transport view (read-only show commands only)."""
    with ViptelaSSH(host, username, password, timeout=timeout, **kw) as ssh:
        platform = _resolve_platform(ssh, platform)
        if platform not in ("cedge", "vedge"):
            return {"success": False, "platform": "", "outputs": {}, "errors": {},
                    "error": "PlatformDetectionFailed"}
        structured = ssh.run_commands(sibling_commands(platform))
        any_good = any(e.get("ok") and (e.get("output") or "").strip()
                       for e in structured.values())
        return {"success": bool(any_good), "platform": platform,
                "outputs": _flatten(structured), "errors": _errors_of(structured),
                "error": None}


def _read_password(args):
    if args.password_env:
        val = os.environ.get(args.password_env, "")
        if val:
            return val
    if args.password_file:
        try:
            with open(args.password_file, "r", encoding="utf-8") as fh:
                return fh.read().rstrip("\r\n")
        except OSError as exc:
            raise SystemExit("unable to read --password-file: %s" % exc)
    if not sys.stdin.isatty():
        return sys.stdin.read().rstrip("\r\n")
    return getpass.getpass("password: ")


def parse_args():
    p = argparse.ArgumentParser(description="BGP-Router-Up-Down-Viptela SSH")
    p.add_argument("--host", required=True)
    p.add_argument("--user", required=True)
    p.add_argument("--password-env", default="VIPTELA_SSH_PASSWORD")
    p.add_argument("--password-file", default="")
    p.add_argument("--platform", default="", help="cedge|vedge (auto if empty)")
    p.add_argument("--mode", default="primary",
                   choices=["primary", "recheck", "device_ping", "clear",
                            "bounce", "evidence", "sibling"])
    p.add_argument("--timeout", default=30, type=int)
    p.add_argument("--peer", default="", help="BGP peer system-IP")
    p.add_argument("--vpn", default="0", help="VPN / VRF id")
    p.add_argument("--interface", default="", help="interface to bounce")
    p.add_argument("--clear-commands", default="",
                   help="JSON list of clear commands (clear mode)")
    p.add_argument("--allow-unknown-hosts", action="store_true")
    p.add_argument("--known-hosts", default="")
    return p.parse_args()


def _sanitize(text, secret):
    if not secret:
        return text
    try:
        return text.replace(secret, "***")
    except Exception:
        return text


def main():
    args = parse_args()
    try:
        password = _read_password(args)
    except SystemExit as exc:
        print(json.dumps({"success": False, "platform": args.platform,
                          "outputs": {}, "errors": {},
                          "error": "CredentialInputError: %s" % exc}))
        sys.exit(0)

    kwargs = dict(allow_unknown_hosts=args.allow_unknown_hosts,
                  known_hosts_path=(args.known_hosts or None))

    def _fail(kind, exc):
        return {"success": False, "platform": args.platform, "outputs": {},
                "errors": {}, "error": "%s: %s" % (kind, _sanitize(str(exc), password))}

    try:
        if args.mode == "recheck":
            result = run_recheck(args.host, args.user, password, args.platform,
                                 args.timeout, args.peer, args.vpn, **kwargs)
        elif args.mode == "device_ping":
            result = run_device_ping(args.host, args.user, password, args.platform,
                                     args.timeout, args.peer, args.vpn, **kwargs)
        elif args.mode == "clear":
            try:
                clear_cmds = json.loads(args.clear_commands) if args.clear_commands else []
            except ValueError:
                clear_cmds = []
            if not isinstance(clear_cmds, list):
                clear_cmds = []
            result = run_clear(args.host, args.user, password, args.platform,
                               args.timeout, args.peer, args.vpn, clear_cmds, **kwargs)
        elif args.mode == "bounce":
            result = run_bounce(args.host, args.user, password, args.platform,
                                args.timeout, args.interface, args.vpn, **kwargs)
        elif args.mode == "evidence":
            result = run_evidence(args.host, args.user, password, args.platform,
                                  args.timeout, args.peer, args.vpn, **kwargs)
        elif args.mode == "sibling":
            result = run_sibling(args.host, args.user, password, args.platform,
                                 args.timeout, **kwargs)
        else:
            result = run_primary(args.host, args.user, password, args.platform,
                                 args.timeout, args.peer, args.vpn, **kwargs)
    except paramiko.AuthenticationException as exc:
        result = _fail("AuthenticationFailed", exc)
    except paramiko.SSHException as exc:
        result = _fail("SSHException", exc)
    except (socket.timeout, TimeoutError) as exc:
        result = _fail("ConnectionTimeout", exc)
    except OSError as exc:
        result = _fail("NetworkError", exc)
    except Exception as exc:  # noqa: BLE001 — always emit JSON
        result = _fail("UnexpectedError", exc)

    print(json.dumps(result))
    sys.exit(0)


if __name__ == "__main__":
    main()
