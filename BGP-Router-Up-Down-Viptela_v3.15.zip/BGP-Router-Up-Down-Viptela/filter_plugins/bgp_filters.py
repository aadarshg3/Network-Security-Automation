"""Filter plugins for BGP-Router-Up-Down-Viptela (Basic-Triage) processing.

Target runtime: Python 3.12 (PROD Jenkins agents; the SSH script runs on
/usr/bin/python3.12). Syntax is kept 3.6-compatible only as a safety margin
(PEP 3107 annotations only, no `from __future__ import annotations`); the Ansible interpreter version on the PROD
agents (pdcd03/pdcd11) is not guaranteed to match SIT's. Only plain
str/int/list/dict annotations are used, so nothing here needs 3.7+.

All parsers are tolerant: on unparseable or unexpected input they return an
empty / safe value and never raise into the play. Every public function is
registered in FilterModule.filters().
"""

import io
import json
import re
import time

try:  # optional dependency; regex fallback is used when absent
    import textfsm  # type: ignore
    _HAS_TEXTFSM = True
except ImportError:  # pragma: no cover - depends on the agent
    textfsm = None  # type: ignore
    _HAS_TEXTFSM = False


class FilterModule:
    """BGP-Router-Up-Down-Viptela Ansible filter plugins."""

    def filters(self) -> dict:
        return {
            # incident parsing
            "normalize_description":     self.normalize_description,
            "extract_peer_sysip_from_text": self.extract_peer_sysip_from_text,
            "extract_interface_from_text": self.extract_interface_from_text,
            "extract_all_ips_from_text": self.extract_all_ips_from_text,
            "extract_repeated_ip_from_text": self.extract_repeated_ip_from_text,
            "pick_device_peer":          self.pick_device_peer,
            "extract_vpn_from_text":     self.extract_vpn_from_text,
            # platform / template
            "detect_platform":           self.detect_platform,
            "is_vmanaged":               self.is_vmanaged,
            # reachability
            "parse_ping_loss_pct":       self.parse_ping_loss_pct,
            "is_control_healthy":        self.is_control_healthy,
            "is_cli_control_healthy":    self.is_cli_control_healthy,
            # BGP state
            "parse_bgp_summary_cedge":   self.parse_bgp_summary_cedge,
            "parse_bgp_summary_vedge":   self.parse_bgp_summary_vedge,
            "parse_bgp_neighbors_cedge": self.parse_bgp_neighbors_cedge,
            "parse_vmanage_bgp_summary": self.parse_vmanage_bgp_summary,
            "get_stuck_neighbors":       self.get_stuck_neighbors,
            "admin_down_neighbors":      self.admin_down_neighbors,
            "bgp_class_alarms":          self.bgp_class_alarms,
            "classify_bgp_alarms":       self.classify_bgp_alarms,
            "alarm_field_summary":       self.alarm_field_summary,
            "route_to_peer_fact":        self.route_to_peer_fact,
            # v3.9: NOC command evidence (MOP-driven, trimmed)
            "noc_command_evidence":      self.noc_command_evidence,
            "trim_bgp_summary":          self.trim_bgp_summary,
            "peer_update_source":        self.peer_update_source,
            "peer_reset_summary":        self.peer_reset_summary,
            "noc_tier2_evidence":        self.noc_tier2_evidence,
            "get_bgp_state_diagnosis":   self.get_bgp_state_diagnosis,
            "build_clear_commands_cedge": self.build_clear_commands_cedge,
            "build_clear_commands_vedge": self.build_clear_commands_vedge,
            "bgp_session_up_from_output": self.bgp_session_up_from_output,
            # interface
            "parse_interface_list_cedge": self.parse_interface_list_cedge,
            "parse_interface_list_vedge": self.parse_interface_list_vedge,
            "select_lan_down_interfaces": self.select_lan_down_interfaces,
            "get_wan_interface_from_wan_list": self.get_wan_interface_from_wan_list,
            "device_ping_ok_from_output": self.device_ping_ok_from_output,
            "device_ping_ran_from_output": self.device_ping_ran_from_output,
            # flap counters
            "count_control_flaps":       self.count_control_flaps,
            "count_bfd_flaps":           self.count_bfd_flaps,
            # output helpers
            "cap_text":                  self.cap_text,
            "trim_cli_noise":            self.trim_cli_noise,
            "strip_invalid_commands":    self.strip_invalid_commands,
            "trim_proc_output":          self.trim_proc_output,
            "format_vmanage_bgp_summary": self.format_vmanage_bgp_summary,
            "format_cli_summary":        self.format_cli_summary,
            # --- Sep 2026 NOC ticket-review fixes (additive) ---
            "extract_vpn_scope_from_text": self.extract_vpn_scope_from_text,
            "extract_hostname_from_description": self.extract_hostname_from_description,
            "parse_bgp_cedge_scoped":    self.parse_bgp_cedge_scoped,
            "scope_bgp_neighbors":       self.scope_bgp_neighbors,
            # v3.4 (NOC review Oct 2026): device-wide review for
            # "All BGP peering sessions are down" + vManage match by system-IP.
            "is_all_sessions_alarm":     self.is_all_sessions_alarm,
            "parse_bgp_cedge_all":       self.parse_bgp_cedge_all,
            "neighbors_in_vpn":          self.neighbors_in_vpn,
            "neighbors_outside_vpn":     self.neighbors_outside_vpn,
            "neighbor_vrf":              self.neighbor_vrf,
            # v3.6: standard NOC header (INCIDENT INFORMATION) + cosmetics
            "desc_field":                self.desc_field,
            "fmt_run_time":              self.fmt_run_time,
            "clean_reason":              self.clean_reason,
            # v3.11 (prod tickets 2026100802150 / 02152)
            "ssh_read_info":             self.ssh_read_info,
            "noc_ssh_reason":            self.noc_ssh_reason,
            "ssh_login_ok_unreadable":   self.ssh_login_ok_unreadable,
            "norm_vpn":                  self.norm_vpn,
            # v3.12 (prod tickets 12-Oct-2026)
            "arp_peer_state":            self.arp_peer_state,
            "cli_vmanage_control":       self.cli_vmanage_control,
            # v3.13 (NOC feedback 13-Oct-2026)
            "alarm_vpn_split":           self.alarm_vpn_split,
            "bgp_peer_log_line":         self.bgp_peer_log_line,
            "recent_recoveries":         self.recent_recoveries,
            "peer_interface_by_subnet":  self.peer_interface_by_subnet,
            "transport_health":          self.transport_health,
            "transport_lines":           self.transport_lines,
            "peer_transport_color":      self.peer_transport_color,
            "select_sibling_router":     self.select_sibling_router,
            "transport_findings":        self.transport_findings,
            "bgp_state_hint":            self.bgp_state_hint,
            "partner_command_evidence":  self.partner_command_evidence,
            # v3.14 (prod 20821, 13-Oct-2026)
            "cmd_rejected":              self.cmd_rejected,
            "rejected_commands":         self.rejected_commands,
            "privilege_level":           self.privilege_level,
            "parse_version_uptime":      self.parse_version_uptime,
            "bfd_flap_detail":           self.bfd_flap_detail,
            "other_alarm_summary":       self.other_alarm_summary,
            # v3.7: NOC / Domain for INCIDENT INFORMATION (same source and
            # logic as BFD-TLOC-VIPTELA-TRIAGE PROD)
            "esp_customer_details":      self.esp_customer_details,
            "domain_number":             self.domain_number,
            "fmt_alarm_time":            self.fmt_alarm_time,
            "parse_system_uptime":       self.parse_system_uptime,
            "wan_peer_facts":            self.wan_peer_facts,
            "format_bgp_table":          self.format_bgp_table,
            "format_vmanage_data":       self.format_vmanage_data,
            "ascii_safe":                self.ascii_safe,
            "ssh_failure_reason":        self.ssh_failure_reason,
            "ssh_failure_reasons_from_loop": self.ssh_failure_reasons_from_loop,
            "dcd_domain_from_fqdn":      self.dcd_domain_from_fqdn,
            "mask_secrets":              self.mask_secrets,
            "key_evidence":              self.key_evidence,
            "bgp_crosscheck":            self.bgp_crosscheck,
        }

    # ------------------------------------------------------------------ #
    # Incident parsing
    # ------------------------------------------------------------------ #

    def normalize_description(self, desc: str) -> str:
        """Normalize the iAutomate Description across delivery formats.

        Jenkins passes '\\n' as a literal backslash-n and sometimes '\\r';
        field order and spacing vary. Fold escape sequences to real newlines
        and insert a newline before each known label so downstream line-based
        regex extraction is reliable. Bare backslashes are left intact so a
        Windows path in the alarm text is not corrupted.
        """
        if not isinstance(desc, str) or not desc.strip():
            return ""
        d = desc.replace("\r", "")
        d = d.replace("\\r", "")
        d = d.replace("\\n", "\n")
        d = d.replace("\\ ", "\n")
        labels = [
            "INCIDENT START TIME:", "NEID:", "HOSTNAME:", "IP ADDRESS:",
            "PRODUCT TYPE:", "EQUIPMENT TYPE:", "INCIDENT TYPE:",
            "ASSURE1 ALARM ID:", "TEXT:", "AID:",
        ]
        for lbl in labels:
            pat = re.compile(r"\s+(" + re.escape(lbl) + ")", re.IGNORECASE)
            d = pat.sub("\n" + r"\1", d)
        return d

    def extract_peer_sysip_from_text(self, alarm_text: str) -> str:
        """Extract the BGP peer IP from the BGPRouterUpDown alarm TEXT field.

        DEPRECATED — NOT used for peer selection and must not be. The BGP
        neighbor is taken only from the device BGP summary (pick_device_peer).
        Kept registered only so an older playbook that references it does not
        fail on an undefined filter.

        Verified TEXT shape (SIT ASSURE1, BGPRouterUpDown — build 661):
          'The BGPRouterUpDown oper-state changed to down- {NEID} {interface}
           {peer_ip} {vpn}'
        There is exactly ONE dotted IPv4 in this TEXT and it IS the BGP peer
        (e.g. '10.10.10.1'). The alerting device's own management IP is NOT in
        the TEXT — it arrives in the ticket 'IP ADDRESS' field — and the token
        before the peer IP is an interface name (e.g. 'ge0/2'), not an IP.

        Selection rule (robust across variants):
          - Take the LAST valid dotted IPv4 in the TEXT as the peer. With a
            single IP (the BGPRouterUpDown case) this returns that IP; with a
            hypothetical '{mgmt_ip} {peer_ip} {vpn}' variant it still returns
            the peer (the address nearest the trailing VPN token), never the
            leading management IP.
          - Non-dotted numeric tokens (a trailing VPN id, or a numeric TLOC id
            such as '10009956') never match the dotted-quad regex, so they are
            not mistaken for the peer.
          - Returns "" when no dotted IPv4 is present so the caller escalates
            rather than self-peering.
        """
        if not isinstance(alarm_text, str) or not alarm_text.strip():
            return ""
        ips = re.findall(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", alarm_text)
        valid = []
        for ip in ips:
            octets = ip.split(".")
            try:
                if all(0 <= int(o) <= 255 for o in octets) and ip != "0.0.0.0":
                    valid.append(ip)
            except (ValueError, TypeError):
                continue
        return valid[-1] if valid else ""

    def extract_interface_from_text(self, alarm_text: str) -> str:
        """Extract the local interface token from the BGPRouterUpDown TEXT field.

        In the verified TEXT shape the token immediately before the peer IP is
        the local interface the BGP session runs over (e.g. 'ge0/2' on vEdge,
        'GigabitEthernet0/0/1' on cEdge). It is used by the interface-check
        phase; the alarm hands it to us directly, so parsing it here avoids a
        later 'show ip interface brief' next-hop lookup.

        The pattern requires a recognised interface prefix followed by digits
        and at least one '/' slot, which never matches a NEID/hostname token
        (those contain no slash) or a bare VPN integer. Returns "" when no
        interface-like token is present.
        """
        if not isinstance(alarm_text, str) or not alarm_text.strip():
            return ""
        m = re.search(
            r"(?i)\b((?:ge|gi|te|fo|hu|twe|fi|fa|eth|ethernet|gigabitethernet|"
            r"tengigabitethernet|fortygigabitethernet|fastethernet|cellular)"
            r"\d+(?:/\d+)+(?:\.\d+)?)\b",
            alarm_text,
        )
        return m.group(1) if m else ""

    def _valid_ips_in_order(self, text: str) -> list:
        """Ordered, de-duplicated list of valid non-zero IPv4s in `text`."""
        out = []
        if not isinstance(text, str):
            return out
        for ip in re.findall(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", text):
            try:
                if all(0 <= int(o) <= 255 for o in ip.split(".")) and ip != "0.0.0.0":
                    if ip not in out:
                        out.append(ip)
            except (ValueError, TypeError):
                continue
        return out

    def extract_all_ips_from_text(self, alarm_text: str) -> list:
        """Every distinct valid IPv4 in the alarm TEXT, in order."""
        return self._valid_ips_in_order(alarm_text)

    def extract_repeated_ip_from_text(self, alarm_text: str) -> str:
        """The IP that appears 2+ times in the alarm TEXT.

        The production BGPRouterUpDown alarm is
          'All BGP peering sessions are down- <host> <sysip> <sysip> <vpn>'
        where the device's OWN system-IP is repeated. That repeated IP is the
        DEVICE, never a BGP neighbor. Returns '' when no IP repeats (e.g. the
        SIT '... <neid> <iface> <neighbor> <vpn>' shape), so the caller does
        not mistake a single neighbor IP for the device.
        """
        if not isinstance(alarm_text, str):
            return ""
        found = re.findall(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", alarm_text)
        for ip in found:
            if found.count(ip) >= 2 and ip != "0.0.0.0":
                return ip
        return ""

    def pick_device_peer(self, neighbors, stuck_neighbors,
                         exclude_ips=None, fallback_ips=None) -> str:
        """Choose the BGP peer to act on from the DEVICE's BGP table.

        The alarm never carries a reliable neighbor (prod repeats the device's
        own system-IP), so the neighbor is taken from 'show ip bgp all summary'
        (cEdge) / 'show bgp summary' (vEdge). Order:
          1. a stuck/down neighbor from the device table, else
          2. any neighbor from the device table, else
          3. '' -> caller reports "no neighbor in device BGP summary" and
             escalates.
        Device-own IPs in `exclude_ips` (system-IP, mgmt IP, repeated alarm IP)
        are never returned as a peer.

        `fallback_ips` is accepted for call-signature compatibility ONLY and
        is deliberately IGNORED. It previously let a ticket/alarm IP become the
        peer whenever the device BGP table was empty (SSH failed, VPN filter
        dropped every row, or the parser missed the table). NOC review
        (Sep 2026): the neighbor must come from the device BGP summary, never
        from the ticket. Do not re-introduce a ticket fallback here.
        """
        ex = set()
        for i in (exclude_ips or []):
            s = str(i or "").strip()
            if s:
                ex.add(s)

        def ip_of(n):
            if isinstance(n, dict):
                return str(n.get("neighbor", "")).strip()
            return str(n or "").strip()

        def clean(lst):
            seen = []
            for n in (lst or []):
                ip = ip_of(n)
                if ip and ip not in ex and ip not in seen:
                    seen.append(ip)
            return seen

        stuck = clean(stuck_neighbors)
        if stuck:
            return stuck[0]
        alln = clean(neighbors)
        if alln:
            return alln[0]
        # No ticket/alarm fallback (see docstring): empty device table -> ''.
        return ""

    def extract_vpn_from_text(self, alarm_text: str) -> str:
        """Extract the VPN/VRF ID from the alarm TEXT field.

        The trailing integer token is the VPN ID. Defaults to '0' (global /
        transport VPN) when no trailing integer is present.
        """
        if not isinstance(alarm_text, str) or not alarm_text.strip():
            return "0"
        tokens = alarm_text.strip().split()
        if tokens and re.match(r"^\d+$", tokens[-1]):
            return tokens[-1]
        # Explicit: prod alarms end in 'Default' for the global / transport
        # table (VPN 0). Any other non-numeric token also falls back to '0'
        # for command building; scoping uses extract_vpn_scope_from_text.
        if tokens and tokens[-1].lower() in ("default", "global"):
            return "0"
        return "0"

    # ------------------------------------------------------------------ #
    # Platform / template detection
    # ------------------------------------------------------------------ #

    def detect_platform(self, output: str) -> str:
        """Detect device platform from 'show [sdwan] system status' + version.

        Ground truth (Vedge.docx / Cedge.docx):
          cEdge  'show sdwan system status' -> 'Device role: cEdge-SDWAN'
                 (NOTE: 'Personality: vedge' appears on BOTH platforms and is
                  never used as a discriminator)
          vEdge  'show system status' -> 'Personality: vedge' + 'Model name:
                 vedge-...' with no cEdge markers.
        Returns '' (unknown) so the caller escalates rather than sending the
        wrong platform's CLI.
        """
        if not isinstance(output, str) or not output.strip():
            return ""
        lower = output.lower()

        # Definitive cEdge markers.
        if "cedge-sdwan" in lower:
            return "cedge"
        if "device role:" in lower and "cedge" in lower.split("device role:", 1)[-1][:40]:
            return "cedge"
        if "controller-managed" in lower:
            return "cedge"
        if "cisco ios xe" in lower or "ios-xe" in lower:
            return "cedge"

        # vEdge model marker is checked BEFORE the ISR/CSR/C8000 hardware
        # heuristic: a vEdge on ISR-class hardware reports
        # 'Model name: vedge-ISR1100-4GLTE' (ground truth, Vedge.docx), so the
        # bare 'isr\d+' token would otherwise misclassify it as cEdge.
        if re.search(r"\bmodel\s*name\s*:\s*vedge", lower) or re.search(r"\bmodel\s*:\s*vedge\b", lower):
            return "vedge"
        if re.search(r"\b(csr1000v|csr\d+|c8[0-9]{3}|isr\d+|asr\d+|c11\d{2})\b", lower):
            return "cedge"

        # 'viptela' / 'vedge Operating System' is NOT a definitive vEdge marker:
        # the same header string appears on cEdge 'show sdwan system status'
        # (Cedge.docx). Fall through to version-token scoring instead.
        cedge_kw = (r"\b17\.\d", r"\b16\.\d", r"\bsdwan-enabled\b", r"\bxe software\b")
        vedge_kw = (r"\b18\.\d", r"\b19\.\d", r"\b20\.\d", r"\b21\.\d", r"\b22\.\d")
        cedge_score = sum(1 for pat in cedge_kw if re.search(pat, lower))
        vedge_score = sum(1 for pat in vedge_kw if re.search(pat, lower))
        if cedge_score == 0 and vedge_score == 0:
            return ""
        return "cedge" if cedge_score > vedge_score else "vedge"

    def is_vmanaged(self, output: str, version_output: str = "") -> bool:
        """Detect whether the device is under vManage template/controller control.

        Checked by VALUE, not keyword presence (ground truth from device docs):
          vEdge  'show system status'  -> 'vManaged: true'
          vEdge  'show system status'  -> 'Configuration template: <name>'
                 (None / '-' / N/A means NOT managed)
          cEdge  'show sdwan system status' -> 'vManaged: true' /
                 'Configuration template: <name>' (Device role also present)
          cEdge  'show version' -> 'Router operating mode: Controller-Managed'
        A template-managed device must NOT be CLI-remediated.
        """
        not_managed = {"none", "n/a", "-", "false", "", "not applicable"}
        if isinstance(output, str) and output.strip():
            for line in output.splitlines():
                if re.match(r"\s*vmanaged\s*:", line, re.IGNORECASE):
                    if line.split(":", 1)[-1].strip().lower() == "true":
                        return True
                if "configuration template:" in line.lower():
                    if line.split(":", 1)[-1].strip().lower() not in not_managed:
                        return True
        if isinstance(version_output, str) and version_output.strip():
            for line in version_output.splitlines():
                if re.match(r"\s*router operating mode\s*:", line, re.IGNORECASE):
                    if "controller-managed" in line.split(":", 1)[-1].strip().lower():
                        return True
        return False

    # ------------------------------------------------------------------ #
    # Reachability
    # ------------------------------------------------------------------ #

    def parse_ping_loss_pct(self, output: str) -> int:
        """Extract packet-loss percentage from Linux ping output.

        Returns 100 when no figure is parseable, so an unparseable result is
        treated as no-response rather than silently as success.
        """
        if not isinstance(output, str) or not output.strip():
            return 100
        m = re.search(r"([0-9]+(?:[.,][0-9]+)?)%\s*packet loss", output, re.I)
        if not m:
            return 100
        try:
            return int(round(float(m.group(1).replace(",", "."))))
        except (ValueError, TypeError):
            return 100

    def is_control_healthy(self, connections: list) -> bool:
        """True when all vsmart/vmanage control connections (vManage API) are up."""
        if not isinstance(connections, list) or not connections:
            return False
        critical = [
            c for c in connections
            if isinstance(c, dict) and c.get("peer-type") in ("vsmart", "vmanage")
        ]
        if not critical:
            return False
        return all(str(c.get("state", "")).strip().lower() == "up" for c in critical)

    def is_cli_control_healthy(self, output: str) -> bool:
        """True when CLI control-connection output shows a vsmart/vmanage up row."""
        if not isinstance(output, str) or not output.strip():
            return False
        for line in output.splitlines():
            low = line.lower()
            tokens = low.split()
            if len(tokens) >= 2 and tokens[0] == "peer" and tokens[1] == "type":
                continue
            if line.strip().startswith("-"):
                continue
            if ("vsmart" in low or "vmanage" in low) and re.search(r"\bup\b", low):
                return True
        return False

    # ------------------------------------------------------------------ #
    # BGP state parsing
    #
    # NOTE: real BGP command outputs were not provided in the reference
    # material (the device docs cover control-plane health only). These
    # parsers follow the standard Cisco IOS-XE and Viptela vEdge 20.x
    # 'show bgp summary' / 'show ip bgp summary' / 'show ip bgp neighbors'
    # layouts and are deliberately tolerant. VERIFY against a live SIT device
    # before production (see the understanding doc, open item BGP-1).
    # ------------------------------------------------------------------ #

    # BGP session states that are NOT established (i.e. stuck / down).
    _STUCK_STATES = {"idle", "active", "connect", "opensent", "openconfirm"}

    def parse_bgp_summary_cedge(self, output_text: str, vpn_id: str = "0") -> list:
        """Parse cEdge 'show ip bgp [vpnv4 ...] summary' output.

        Standard IOS-XE table (last column is State/PfxRcd):
          Neighbor  V  AS  MsgRcvd  MsgSent  TblVer  InQ  OutQ  Up/Down  State/PfxRcd
        A numeric last column = Established (that many prefixes received);
        a word last column (Idle/Active/...) = that state.
        """
        neighbors = []
        if not isinstance(output_text, str) or not output_text.strip():
            return neighbors
        for line in output_text.splitlines():
            parts = line.split()
            if len(parts) < 5:
                continue
            if not re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", parts[0]):
                continue
            # Version column is typically '4'; require it to reduce false rows.
            last = parts[-1]
            remote_as = parts[2] if len(parts) > 2 else ""
            if re.match(r"^\d+$", last):
                state = "established"
            else:
                state = last.lower()
            neighbors.append({
                "neighbor": parts[0],
                "remote_as": remote_as,
                "vrf": str(vpn_id),
                "state": state,
            })
        return neighbors

    def parse_bgp_neighbors_cedge(self, output_text: str) -> list:
        """Parse cEdge 'show ip bgp neighbors' detail output.

        Reads paired lines:
          BGP neighbor is 172.28.240.96, vrf 10, remote AS 65534, external link
          BGP state = Established, up for 2d09h
        """
        neighbors = []
        if not isinstance(output_text, str) or not output_text.strip():
            return neighbors
        current = {}
        for raw in output_text.splitlines():
            line = raw.strip()
            m = re.search(
                r"BGP neighbor is\s+([^,\s]+)"
                r"(?:,\s*vrf\s+([^,\s]+))?"
                r"(?:,\s*remote AS\s+(\d+))?",
                line, re.IGNORECASE,
            )
            if m:
                if current.get("neighbor"):
                    neighbors.append(current)
                current = {
                    "neighbor": m.group(1).rstrip(","),
                    "vrf": (m.group(2) or "default").rstrip(","),
                    "remote_as": m.group(3) or "",
                    "state": "unknown",
                }
                continue
            sm = re.search(r"BGP state\s*=\s*(\w+)", line, re.IGNORECASE)
            if sm and current:
                current["state"] = sm.group(1).lower()
        if current.get("neighbor"):
            neighbors.append(current)
        return neighbors

    def parse_bgp_summary_vedge(self, output_text: str, vpn_id: str = "0") -> list:
        """Parse vEdge 'show bgp summary' output.

        vEdge 20.x prints one section per VPN, each with a NEIGHBOR..STATE
        table; STATE is always the last token on a data row. When vpn_id is a
        specific (non-'0') value, only that VPN's neighbors are returned.
        """
        neighbors = []
        if not isinstance(output_text, str) or not output_text.strip():
            return neighbors
        current_vpn = "0"
        in_table = False
        for raw in output_text.splitlines():
            stripped = raw.strip()
            if not stripped:
                continue
            vpn_m = re.match(r"^vpn\s+(\d+)\s*$", stripped, re.IGNORECASE)
            if vpn_m:
                current_vpn = vpn_m.group(1)
                in_table = False
                continue
            if re.match(r"^NEIGHBOR\b.*\bSTATE\b\s*$", stripped, re.IGNORECASE):
                in_table = True
                continue
            if not in_table:
                continue
            if re.match(r"^-+$", stripped):
                continue
            parts = stripped.split()
            if not parts or not re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", parts[0]):
                continue
            state = parts[-1].lower()
            remote_as = parts[1] if len(parts) > 1 else ""
            if str(vpn_id) not in ("0", "") and current_vpn != str(vpn_id):
                continue
            neighbors.append({
                "neighbor": parts[0],
                "remote_as": remote_as,
                "vrf": current_vpn,
                "state": state,
            })
        return neighbors

    def parse_vmanage_bgp_summary(self, data: list, vpn_id: str = "0") -> list:
        """Normalize vManage GET /dataservice/device/bgp/summary rows.

        vManage returns records with fields such as: peer-addr, as, state,
        vpn-id (field names vary slightly by vManage release). Reads them
        defensively and returns the same {neighbor,remote_as,vrf,state} shape
        as the CLI parsers so downstream logic is source-agnostic.
        """
        neighbors = []
        if not isinstance(data, list):
            return neighbors
        for row in data:
            if not isinstance(row, dict):
                continue
            neigh = (row.get("peer-addr") or row.get("neighbor")
                     or row.get("peer-address") or "")
            if not neigh:
                continue
            vrf = str(row.get("vpn-id", row.get("vpn", "0")))
            if str(vpn_id) not in ("0", "") and vrf != str(vpn_id):
                continue
            neighbors.append({
                "neighbor": str(neigh),
                "remote_as": str(row.get("as", row.get("remote-as", ""))),
                "vrf": vrf,
                "state": str(row.get("state", "")).lower() or "unknown",
            })
        return neighbors

    def get_stuck_neighbors(self, neighbors: list) -> list:
        """Return neighbors in a non-Established (stuck) state.

        Stuck = idle | active | connect | opensent | openconfirm. Never
        includes established sessions. Unknown state is treated as stuck so
        an unparseable session is escalated, not silently ignored.
        """
        if not isinstance(neighbors, list):
            return []
        out = []
        for n in neighbors:
            if not isinstance(n, dict):
                continue
            st = str(n.get("state", "")).lower()
            # v3.8: admin shutdown ('Idle (Admin)') is intentional, not a
            # fault -> never stuck. Any other non-Established state (incl.
            # 'NoNeg', unknown or unparsed values) IS stuck, so a session that
            # is not up can never be read as healthy.
            if "admin" in st:
                continue
            if st in self._STUCK_STATES or st == "unknown" or st != "established":
                out.append(n)
        return out

    def route_to_peer_fact(self, cli_output, evidence, platform: str = "",
                           peer: str = "", vrf: str = "") -> dict:
        """Route towards the BGP peer, read from device output only.
        Returns {'state': 'present'|'absent'|'', 'prefix', 'proto'}; ''
        when the output needed to decide is not available (no line printed).
        vEdge: longest matching prefix in 'show ip routes [vpn n]' rows of
        the peer's VPN. cEdge: 'show ip route <peer>' (global table, so only
        used for a VPN 0 peer)."""
        import ipaddress
        none = {"state": "", "prefix": "", "proto": ""}
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        plat = str(platform or "").lower()
        v = self._norm_vrf(vrf)
        try:
            ip = ipaddress.ip_address(str(peer or "").strip())
        except ValueError:
            return none
        if plat == "vedge":
            if not v or v == "?":
                return none
            text = ""
            for t in (ev.get("routes", ""), co.get("ip_routes_vpn", ""), co.get("ip_routes", "")):
                if isinstance(t, str) and "PREFIX" in t.upper():
                    text = t
                    break
            if not text:
                return none
            best = None
            for line in text.splitlines():
                m = re.match(r"^\s*(\d+)\s+(\d{1,3}(?:\.\d{1,3}){3}/\d{1,2})\s+(\S+)", line)
                if not m or self._norm_vrf(m.group(1)) != v:
                    continue
                try:
                    net = ipaddress.ip_network(m.group(2), strict=False)
                except ValueError:
                    continue
                if ip in net and (best is None or net.prefixlen > best[0].prefixlen):
                    best = (net, m.group(3))
            if best is None:
                return {"state": "absent", "prefix": "", "proto": ""}
            return {"state": "present", "prefix": str(best[0]), "proto": best[1]}
        if plat == "cedge":
            if v == "0":
                text = ev.get("route_to_peer", "")
            elif v and v != "?":
                # v3.9: VRF-aware evidence ('show ip route vrf <n> <peer>')
                text = ev.get("route_to_peer_vrf", "")
            else:
                return none
            if not isinstance(text, str) or not text.strip():
                return none
            if re.search(r"%\s*(Network|Subnet) not in table", text, re.IGNORECASE):
                return {"state": "absent", "prefix": "", "proto": ""}
            m = re.search(r"Routing entry for (\S+)", text)
            if m:
                p = re.search(r'Known via "([^"\s]+)', text)
                return {"state": "present", "prefix": m.group(1),
                        "proto": p.group(1) if p else ""}
        return none

    # ------------------------------------------------------------------ #
    # v3.9 - NOC command evidence: MOP-driven selection, trimmed per command
    # ------------------------------------------------------------------ #

    _IP_RE = r"\d{1,3}(?:\.\d{1,3}){3}"

    @staticmethod
    def _lines(text):
        return text.splitlines() if isinstance(text, str) else []

    @staticmethod
    def _usable(text) -> bool:
        if not isinstance(text, str) or not text.strip():
            return False
        low = text.lower()
        return not any(mk in low for mk in ("% invalid input", "syntax error",
                                             "unknown command", "% incomplete command"))

    def trim_bgp_summary(self, text, platform: str = "") -> str:
        """Neighbor tables only. cEdge 'show ip bgp all summary': keep the
        address-family line, router-id/local-AS line, table header and the
        neighbor rows (memory / table-version / activity lines dropped; an
        address family without neighbors is dropped). vEdge 'show bgp
        summary': keep vpn, router-id, local-as, total-peers, table header
        and rows (rib/peer memory and SoO lines dropped)."""
        if not self._usable(text):
            return ""
        out = []
        if str(platform).lower() == "vedge":
            for ln in self._lines(text):
                s = ln.strip()
                if re.match(r"^(vpn|bgp-router-identifier|local-as|total-peers)\b", s, re.I):
                    out.append(s)
                elif re.search(r"\bNEIGHBOR\b.*\bSTATE\b", s) or re.match(r"^MSG\b", s) or re.match(r"^-{10,}$", s):
                    out.append(ln.rstrip())
                elif re.match(r"^" + self._IP_RE + r"\s", s):
                    out.append(ln.rstrip())
            return "\n".join(out)
        block, has_rows = [], False

        def flush():
            if has_rows:
                out.extend(block)
        for ln in self._lines(text):
            s = ln.strip()
            if re.match(r"^For address family:", s, re.I):
                flush()
                block, has_rows = [s], False
            elif re.match(r"^BGP router identifier", s, re.I):
                block.append(s)
            elif re.match(r"^Neighbor\s+V\s+AS\b", s):
                block.append(ln.rstrip())
            elif re.match(r"^" + self._IP_RE + r"\s+\d", s):
                block.append(ln.rstrip())
                has_rows = True
        flush()
        return "\n".join(out)

    _NBR_KEY_RE = re.compile(
        r"^(BGP neighbor is|Description:|BGP state =|Last read .*hold time|"
        r"Configured hold time|Last reset|Connections established|"
        r"Interface associated|External BGP neighbor|Internal BGP neighbor|"
        r"Local host:|Foreign host:|Route to peer address reachability|"
        r"Prefixes Current|Last notification|No active TCP connection|"
        r"BGP version 4, remote router ID)", re.I)

    def trim_bgp_neighbor(self, text, peer: str, platform: str = "") -> str:
        """cEdge 'show ip bgp neighbors [<peer>]': only the block of <peer>
        and only the lines NOC needs (state, hold/keepalive timers, last
        reset reason, connections established/dropped, interface, TCP
        hosts). vEdge 'show bgp neighbor': header + rows of <peer>."""
        if not self._usable(text) or not peer:
            return ""
        lines = self._lines(text)
        if str(platform).lower() == "vedge":
            out = [ln.rstrip() for ln in lines
                   if re.search(r"\bPEER ADDR\b|\bMSG\b|^-{10,}", ln.strip())
                   or re.search(r"(^|\s)" + re.escape(peer) + r"(\s|$)", ln)]
            return "\n".join(out) if any(peer in ln for ln in out) else ""
        out, inside = [], False
        for ln in lines:
            s = ln.strip()
            if s.startswith("BGP neighbor is"):
                inside = re.match(r"^BGP neighbor is " + re.escape(peer) + r"\b", s) is not None
            if inside and self._NBR_KEY_RE.match(s):
                out.append(s)
        return "\n".join(out[:20])

    def trim_bgp_config(self, text, peer: str) -> str:
        """BGP config lines relevant to <peer>: router bgp / router-id /
        timers / address-family headers, every 'neighbor <peer> ...' line
        (cEdge) or the 'neighbor <peer>' block (vEdge, indented). Secrets
        masked."""
        if not self._usable(text) or not peer:
            return ""
        out, blk_indent = [], None
        hdr = re.compile(r"^(router bgp|bgp router-id|timers bgp|address-family|vpn \d+|router$|bgp \d+|router-id|timers)\b", re.I)
        for ln in self._lines(text):
            s = ln.strip()
            ind = len(ln) - len(ln.lstrip())
            if blk_indent is not None:
                if s and ind > blk_indent:
                    out.append(ln.rstrip())
                    continue
                blk_indent = None
            if re.match(r"^neighbor " + re.escape(peer) + r"(\s|$)", s):
                out.append(ln.rstrip())
                if s == "neighbor " + peer:
                    blk_indent = ind
            elif hdr.match(s):
                out.append(ln.rstrip())
        if not any(peer in ln for ln in out):
            return ""
        # drop address-family headers that carry no line for the peer
        res = []
        for i, ln in enumerate(out):
            if ln.strip().lower().startswith("address-family"):
                nxt = out[i + 1:]
                k = next((j for j, x in enumerate(nxt) if x.strip().lower().startswith("address-family")), len(nxt))
                if not any(peer in x for x in nxt[:k]):
                    continue
            res.append(ln)
        return self.mask_secrets("\n".join(res))

    def peer_reset_summary(self, cli_output, evidence, peer: str, platform: str = "") -> str:
        """One plain line from device output: why the session to <peer> last
        reset (cEdge 'Last reset ..., due to ...' + connections dropped) and
        the latest BGP NOTIFICATION reason from the log (e.g. hold time
        expired). '' when the device output does not say."""
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        if not peer:
            return ""
        bits = []
        if str(platform).lower() == "cedge":
            nb = self.trim_bgp_neighbor(self._peer_nbr_text(co, ev, peer) or ev.get("bgp_neighbor")
                                        or co.get("bgp_neighbor_peer") or co.get("bgp_neighbors", ""),
                                        peer, "cedge")
            m = re.search(r"Last reset ([^,\n]+), due to ([^\n]+)", nb or "")
            if m and m.group(1).strip().lower() != "never":
                bits.append("last reset %s ago, due to %s" % (m.group(1).strip(), m.group(2).strip().rstrip(".")))
            c = re.search(r"Connections established (\d+); dropped (\d+)", nb or "")
            if c and int(c.group(2)) > 0:
                bits.append("%s connection(s) dropped" % c.group(2))
        log = self.trim_bgp_log(ev.get("logging_bgp") or co.get("logging_bgp", ""), peer)
        notes = [ln for ln in self._lines(log) if peer in ln
                 and re.search(r"%BGP-\d-NOTIFICATION|NOTIFICATION:", ln, re.I)
                 and re.search(r"\([^)]+\)", ln)]
        if notes:
            r = re.search(r"\(([^)]+)\)", notes[-1])
            if r:
                bits.append("latest BGP notification: %s" % r.group(1))
        # v3.11: ',' not ';' - the ETMS update path strips ';' (prod 2152)
        return ", ".join(bits)

    def trim_bgp_log(self, text, peer: str, max_lines: int = 10) -> str:
        """Latest BGP log lines about <peer> (ADJCHANGE / NOTIFICATION /
        hold time / reset); falls back to the latest BGP lines."""
        if not self._usable(text):
            return ""
        lines = [ln.rstrip() for ln in self._lines(text) if "bgp" in ln.lower()]
        mine = [ln for ln in lines if peer and peer in ln]
        pick = mine if mine else lines
        return "\n".join(pick[-max_lines:])

    def peer_update_source(self, config_text, peer: str) -> str:
        """Interface named by 'neighbor <peer> update-source <if>' (cEdge) or
        'update-source <if>' inside the vEdge neighbor block."""
        if not isinstance(config_text, str) or not peer:
            return ""
        m = re.search(r"neighbor " + re.escape(peer) + r"\s+update-source\s+(\S+)", config_text)
        if m:
            return m.group(1)
        blk = self.trim_bgp_config(config_text, peer)
        m = re.search(r"update-source\s+(\S+)", blk or "")
        return m.group(1) if m else ""

    def trim_interface_lines(self, cli_output, iface: str) -> str:
        """Lines for <iface> from 'show ip interface brief' and 'show
        interface(s) description' (full and short names)."""
        co = cli_output if isinstance(cli_output, dict) else {}
        if not iface:
            return ""
        names = {iface.lower(), self._short_if(iface)}
        out = []
        for key in ("ip_int_brief", "interfaces_desc"):
            for ln in self._lines(co.get(key, "")):
                first = (ln.split() or [""])[0].lower()
                if first in names or self._short_if(first) in names:
                    out.append(ln.rstrip())
        return "\n".join(out)

    def trim_route(self, cli_output, evidence, platform: str, peer: str, vrf: str) -> str:
        """Route towards <peer> only. cEdge: first lines of 'show ip route
        [vrf n] <peer>'. vEdge: route-table header + the row(s) covering
        <peer> in its VPN (never the whole table)."""
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        plat = str(platform).lower()
        if plat == "cedge":
            for key in ("route_to_peer_vrf", "route_to_peer"):
                t = ev.get(key, "")
                if isinstance(t, str) and t.strip():
                    return "\n".join([ln.rstrip() for ln in self._lines(t) if ln.strip()][:8])
            return ""
        fact = self.route_to_peer_fact(co, ev, plat, peer, vrf)
        if not fact.get("state"):
            return ""
        if fact["state"] == "absent":
            return "(no route to %s in VPN %s)" % (peer, vrf)
        text = ""
        for t in (ev.get("routes", ""), co.get("ip_routes_vpn", ""), co.get("ip_routes", "")):
            if isinstance(t, str) and "PREFIX" in t.upper():
                text = t
                break
        out = [ln.rstrip() for ln in self._lines(text)
               if re.search(r"\bPREFIX\b", ln) or re.match(r"^-{10,}$", ln.strip())
               or re.match(r"^\s*\S+\s+" + re.escape(fact["prefix"]) + r"\s", ln)]
        return "\n".join(out)

    def trim_arp(self, cli_output, evidence, peer: str, vrf: str = "0",
                 platform: str = "") -> str:
        """ARP row(s) of the peer from the peer's own VPN table (v3.12: a
        cEdge service-VPN peer is never shown from the global table)."""
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        v = self._norm_vrf(vrf) if vrf not in (None, "") else "0"
        if v != "0" and str(platform or "").lower() != "vedge":
            sources = (ev.get("arp_peer_vrf", ""),)
        else:
            sources = (ev.get("arp_peer", ""), co.get("arp", ""))
        for t in sources:
            if not isinstance(t, str):
                continue
            rows = [ln.rstrip() for ln in self._lines(t)
                    if peer and re.search(r"(^|\s)" + re.escape(peer) + r"(\s|$)", ln)]
            if rows:
                return "\n".join(rows[:4])
        return "(no ARP entry for %s)" % peer \
            if self.arp_peer_state(co, ev, peer, vrf, platform) == "absent" else ""

    @staticmethod
    def _etms_title(title) -> str:
        """v3.12: ETMS removes '|', ';' and the word 'update' from ticket text
        (prod: 'show logging   include BGP'), which turned our command titles
        into wrong commands. Titles are written without those characters;
        device output itself is never altered."""
        t = str(title or "")
        t = re.sub(r"\s*\|\s*(include|section|exclude|begin)\s+(\S+)", r" (filtered: \1 \2)", t)
        t = t.replace("|", "/").replace(";", ",")
        return re.sub(r"(?i)update", "upd", t)

    def trim_control(self, text) -> str:
        """'show [sdwan] control connections' as a compact table: peer type,
        peer system-IP, local color, state, uptime (columns read from the
        right, so a multi-word ORGANIZATION column cannot shift them).
        Falls back to the raw peer rows if a row does not parse."""
        if not self._usable(text):
            return ""
        rows = [ln for ln in self._lines(text)
                if re.match(r"^(vsmart|vbond|vmanage|vedge)\s", ln.strip(), re.I)]
        if not rows:
            return ""
        out = ["%-8s %-16s %-16s %-8s %s" % ("PEER", "SYSTEM IP", "LOCAL COLOR", "STATE", "UPTIME")]
        for ln in rows:
            f = ln.split()
            if len(f) < 9 or not re.match(r"^\d", f[2]):
                return "\n".join(r.rstrip() for r in rows)
            # v3.12 (prod 2026101200457 / 0744): when the uptime fills its
            # column it runs into CONTROLLER GROUP ID ('11:22:40:390'), so
            # columns cannot be counted from the right. Find the STATE token
            # (last one), then read the uptime as d:hh:mm:ss from the next
            # token; the colour is the token before the BEHIND-PROXY column.
            idx = None
            for i in range(len(f) - 1, 2, -1):
                if f[i].lower() in self._CTRL_STATES:
                    idx = i
                    break
            if idx is None:
                return "\n".join(r.rstrip() for r in rows)
            state, uptime = f[idx], ""
            if idx + 1 < len(f):
                m = re.match(r"^(\d+:\d{2}:\d{2}:\d{2})", f[idx + 1])
                uptime = m.group(1) if m else ""
            j = idx - 1
            if f[j] in ("No", "Yes", "-") and j > 3:
                j -= 1
            color = f[j]
            out.append(("%-8s %-16s %-16s %-8s %s" % (f[0], f[2], color, state, uptime)).rstrip())
        return "\n".join(out)

    def cli_vmanage_control(self, text) -> str:
        """v3.12: the device's own control connection to vManage, from
        'show [sdwan] control connections' - e.g. 'up for 0:00:40:13'.
        '' when the table was not read or has no vManage row."""
        table = self.trim_control(text)
        lines = self._lines(table)
        if not lines or not lines[0].startswith("PEER "):
            return ""
        found = []
        for ln in lines[1:]:
            f = ln.split()
            if len(f) >= 4 and f[0].lower() == "vmanage":
                st = f[3].lower()
                found.append(("up for " + f[4]) if (st == "up" and len(f) > 4)
                             else ("up" if st == "up" else "in state " + st))
        return ", ".join(found[:2])

    # control-connection states printed by 'show [sdwan] control connections'
    _CTRL_STATES = frozenset(("up", "down", "connect", "challenge", "challenge_resp",
                              "challenge_ack", "handshake", "trying", "tear_down",
                              "disconnecting"))

    def trim_cpu_mem(self, cli_output, evidence) -> str:
        """One-line CPU / memory figures (MOP: rule out high CPU)."""
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        out = []
        for t in (ev.get("cpu", ""), ev.get("memory", "")):
            for ln in self._lines(t):
                if re.search(r"CPU utilization for|Processor Pool Total|^\s*Processor\s+\S+\s+\d", ln):
                    out.append(ln.strip())
                    break
        if not out:
            # v3.15: one-line reads taken on every ticket (primary bundle)
            for t in (co.get("cpu_util", ""), co.get("mem_pool", "")):
                if not self._usable(t):
                    continue
                for ln in self._lines(t):
                    if re.search(r"CPU utilization for|Pool Total", ln):
                        out.append(ln.strip())
        if not out:
            for t in (ev.get("sys_status", ""), co.get("system_status", "")):
                rows = [ln.strip() for ln in self._lines(t)
                        if re.match(r"^\s*(CPU states|Load average|Memory usage)", ln, re.I)]
                if rows:
                    out = rows
                    break
        return "\n".join(out)

    def _nbr_section(self, text, peer: str, vrf: str = ""):
        """v3.15: cEdge neighbor key lines; the title names the VRF the
        DEVICE printed for that neighbor ('BGP neighbor is X,  vrf 500,'),
        so a VRF peer is never titled with the global command."""
        body = self.trim_bgp_neighbor(text, peer, "cedge")
        m = re.search(r"BGP neighbor is " + re.escape(peer) + r",\s+vrf\s+([^,\s]+)", body or "")
        v = m.group(1) if m else (str(vrf or "") if not body else "")
        v = "" if v in ("0", "?", "default", "global") else v
        cmd = ("show ip bgp vpnv4 vrf %s neighbors %s" % (v, peer)) if v else ("show ip bgp neighbors %s" % peer)
        return (cmd + " (key lines)", body)

    def trim_platform_res(self, text, max_lines: int = 16) -> str:
        """v3.15: IOS-XE 'show platform resources' (MOP 'show platform
        health'): resource rows with usage and state; legend dropped."""
        if not self._usable(text):
            return ""
        out = [ln.rstrip() for ln in self._lines(text)
               if ln.strip() and not ln.strip().startswith("*") and not re.match(r"^\s*-{10,}\s*$", ln)]
        return "\n".join(out[:max_lines])

    def device_ping_section(self, outputs, platform: str, peer: str, vpn: str = "0"):
        """v3.15 (MOP: ping the BGP neighbor): (title, body) of the device-
        sourced ping. The VPN/VRF ping is preferred for a service-VPN peer
        (same commands as bgp_ssh.py run_device_ping). ('', '') when the
        ping was not run."""
        o = outputs if isinstance(outputs, dict) else {}
        if not o or not peer:
            return ("", "")
        plat = str(platform or "").lower()
        v = str(vpn or "0").strip() or "0"
        if plat == "vedge":
            order = (("ping_vpn", "ping %s vpn %s count 5" % (peer, v)), ("ping", "ping %s count 5" % peer))
        else:
            order = (("ping_vrf", "ping vrf %s %s repeat 5" % (v, peer)), ("ping", "ping %s repeat 5" % peer))
        for key, cmd in order:
            t = o.get(key)
            if not isinstance(t, str) or not t.strip():
                continue
            if self.cmd_rejected(t):
                return (cmd, "(command rejected by the device for the automation login)")
            rows = [ln.rstrip() for ln in self._lines(t)
                    if re.search(r"(?i)success rate|^\s*[!.U]{3,}|packets transmitted|packet loss|bytes from|sending \d+", ln)]
            if rows:
                return (cmd, "\n".join(rows[:6]))
        return ("", "")

    def noc_command_evidence(self, cli_output, evidence=None, platform: str = "",
                             peer: str = "", vpn: str = "0", path: str = "down",
                             iface: str = "", budget: int = 6000,
                             api_rows=None, tier2: bool = False, per_cmd: int = 2500,
                             api_data=None) -> str:
        """COMMANDS OUTPUT for the NOC ticket, chosen per scenario from the
        MOP and trimmed to the lines NOC needs. Full raw output of every
        command stays in the Jenkins build log / internal_diagnostics.

        UP paths   : BGP neighbor table only (closure needs nothing else).
        DOWN paths : neighbor table, neighbor detail (state, timers, last
                     reset), BGP config for the peer, BGP log lines, the
                     interface towards the peer, route, ARP, control
                     connections, CPU/memory.
        SSH failed : vManage BGP neighbor rows (API) when available.
        """
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        plat = str(platform or "").lower()
        ced = plat == "cedge"
        try:
            budget = int(budget)
        except (TypeError, ValueError):
            budget = 6000
        if plat not in ("cedge", "vedge"):
            # v3.15 (NOC / MOP): the BGP log block is the first block of EVERY
            # ticket - without a device login it states that it could not be
            # collected, so NOC knows to take it manually.
            _nolog = "Command: %s\nOutput:\n%s\n" % (
                self._etms_title("show logging | include BGP (cEdge) / show log | include BGP (vEdge)"),
                "(device output not available - BGP log not collected, NOC to collect it manually)")
            rows = [r for r in (api_rows or []) if isinstance(r, dict)]
            if not rows:
                if tier2:
                    extra = _nolog
                    for title, body in self.noc_tier2_evidence({}, {}, "", peer, path, per_cmd, api_data):
                        block = "Command: %s\nOutput:\n%s\n" % (self._etms_title(title), body.strip("\n"))
                        if len(extra) + len(block) <= budget:
                            extra += ("\n" if extra else "") + block
                    return extra
                return _nolog
            # v3.11: VPN 'default' shown as 0; UP/DOWN column only when vManage gave it
            _ud = any(str(r.get("up_down", "") or "").strip() for r in rows[:20])
            lines = [("%-16s %-8s %-6s %-12s %s" % ("NEIGHBOR", "AS", "VPN", "STATE", "UP/DOWN" if _ud else "")).rstrip()]
            for r in rows[:20]:
                lines.append(("%-16s %-8s %-6s %-12s %s" % (
                    r.get("neighbor", ""), r.get("remote_as", ""), self._norm_vrf(r.get("vrf", "")),
                    str(r.get("state", "")).upper(), r.get("up_down", "") if _ud else "")).rstrip())
            out = _nolog + "\nCommand: vManage controller data - BGP neighbors of this device (device CLI output not available)\nOutput:\n" + "\n".join(lines) + "\n"
            if tier2:
                for title, body in self.noc_tier2_evidence({}, {}, "", peer, path, per_cmd, api_data):
                    block = "Command: %s\nOutput:\n%s\n" % (self._etms_title(title), body.strip("\n"))
                    if len(out) + len(block) <= budget:
                        out += "\n" + block
            return out
        vrf = self.neighbor_vrf(self.parse_bgp_cedge_all(co, vpn) if ced else
                                self.parse_bgp_summary_vedge(co.get("bgp_summary", ""), ""), peer) or vpn
        sections = []
        sum_cmd = "show ip bgp all summary" if ced else "show bgp summary"
        # v3.13 (NOC 2150/2152): MOP 'show log | i BGP' is always shown.
        # v3.14 (NOC, prod 20821): it is the FIRST command block on every
        # path, and a command the device rejected is reported as rejected
        # (it was shown as 'no BGP lines', which was not true).
        _log_cmd1 = "show logging | include BGP" if ced else "show log | include BGP"
        _ev_log = ev.get("logging_bgp", "")
        _log_raw = _ev_log if (isinstance(_ev_log, str) and _ev_log.strip()
                               and not self.cmd_rejected(_ev_log)) else co.get("logging_bgp")
        if _log_raw is None and not (isinstance(_ev_log, str) and _ev_log.strip()):
            _log_body = "(not collected from the device)"
        elif self.cmd_rejected(_log_raw if _log_raw is not None else _ev_log):
            _log_body = ("(command rejected by the device for the automation login - BGP log not collected, "
                         "NOC to collect it manually)")
        else:
            _log_body = (self.trim_bgp_log(_log_raw or "", "" if path in ("up", "up_alarm", "flap") else peer, 10)
                         or "(no BGP lines returned by the device log)")
        sections.append((_log_cmd1 + " (latest)", _log_body))
        # down paths: the first block holds the down peer's lines; the latest
        # lines of the OTHER neighbors follow directly (was in tier 2)
        if path not in ("up", "up_alarm", "flap") and peer and self._usable(_log_raw or "") \
                and any(peer in ln for ln in self._lines(_log_raw)):
            _oth = [ln.rstrip() for ln in self._lines(_log_raw) if "bgp" in ln.lower() and peer not in ln]
            if _oth:
                sections.append((_log_cmd1 + " (latest, other neighbors)", "\n".join(_oth[-10:])))
        sections.append((sum_cmd + " (neighbor table)", self.trim_bgp_summary(co.get("bgp_summary", ""), plat)))
        _upl = path in ("up", "up_alarm", "flap")
        if _upl:
            # v3.15 (MOP review): BGP established - state and timers (hold /
            # keepalive, last reset) of the ESTABLISHED neighbors in the alarm
            # VPN (max 3; all VPNs when the alarm VPN has none listed).
            _rows = self.parse_bgp_cedge_all(co, vpn) if ced else \
                self.parse_bgp_summary_vedge(co.get("bgp_summary", ""), "")
            _scope = self.neighbors_in_vpn(_rows, vpn) or _rows
            _est = [r.get("neighbor", "") for r in _scope
                    if str(r.get("state", "")).lower() == "established" and r.get("neighbor")]
            for ip in _est[:3]:
                if ced:
                    sections.append(self._nbr_section(self._peer_nbr_text(co, ev, ip), ip,
                                                      self.neighbor_vrf(_rows, ip) or vrf))
                elif ip == _est[0]:
                    sections.append(("show bgp neighbor (established neighbor rows)",
                                     "\n".join(b for b in (self.trim_bgp_neighbor(ev.get("bgp_neighbor") or co.get("bgp_neighbor", ""), x, plat)
                                                            for x in _est[:3]) if b)))
        if _upl and peer:
            # device ping to the neighbor, the interface towards it, and on
            # escalations its BGP config lines
            sections.append(self.device_ping_section(ev.get("device_ping"), plat, peer, vpn))
            itf = self.peer_update_source(co.get("bgp_config", ""), peer) or iface
            if itf:
                sections.append(("show ip interface brief / show interfaces description (%s)" % itf if ced
                                 else "show interface description (%s)" % itf,
                                 self.trim_interface_lines(co, itf)))
            if path != "up":
                cfg_cmd = "show running-config | section bgp" if ced else "show running-config vpn %s router bgp" % (vrf or "0")
                sections.append((cfg_cmd + " (lines for %s)" % peer, self.trim_bgp_config(co.get("bgp_config", ""), peer)))
        if path == "flap":
            # v3.14: BGP up but the overlay flapped - transport health first
            sections.append(("show sdwan control connections" if ced else "show control connections",
                             self.trim_control(co.get("control_connections", ""))))
            sections.append((("show sdwan bfd sessions" if ced else "show bfd sessions") + " (summary + not-up sessions)",
                             self.trim_bfd_summary(co.get("bfd_sessions", ""))))
        if _upl:
            sections.append(("CPU / memory (show processes cpu, show processes memory / show system status)",
                             self.trim_cpu_mem(co, ev)))
            if ced:
                sections.append(("show platform resources (platform health)",
                                 self.trim_platform_res(co.get("platform_res", "") or ev.get("platform_res", ""))))
        if path not in ("up", "up_alarm", "flap") and peer:
            nbr_src = (self._peer_nbr_text(co, ev, peer) or ev.get("bgp_neighbor") or co.get("bgp_neighbor_peer")
                       or co.get("bgp_neighbors", "")) if ced \
                else (ev.get("bgp_neighbor") or co.get("bgp_neighbor", ""))
            if ced:
                sections.append(self._nbr_section(nbr_src, peer, vrf))
            else:
                sections.append(("show bgp neighbor (peer row)", self.trim_bgp_neighbor(nbr_src, peer, plat)))
            cfg_cmd = "show running-config | section bgp" if ced else "show running-config vpn %s router bgp" % (vrf or "0")
            sections.append((cfg_cmd + " (lines for %s)" % peer, self.trim_bgp_config(co.get("bgp_config", ""), peer)))
            upd = self.peer_update_source(co.get("bgp_config", ""), peer)
            itf = upd or iface
            if itf:
                sections.append(("show ip interface brief / show interfaces description (%s)" % itf if ced
                                 else "show interface description (%s)" % itf,
                                 self.trim_interface_lines(co, itf)))
            route_cmd = ("show ip route %s%s" % (("vrf %s " % vrf) if (vrf and vrf not in ("0", "?")) else "", peer)) if ced \
                else "show ip routes vpn %s (route to %s)" % (vrf, peer)
            sections.append((route_cmd, self.trim_route(co, ev, plat, peer, vrf)))
            # v3.12: title names the command that was really read
            arp_cmd = (("show ip arp vrf %s | include %s" % (vrf, peer)) if (vrf and vrf not in ("0", "?"))
                       else ("show arp | include %s" % peer)) if ced \
                else "show arp vpn %s | include %s" % (vrf, peer)
            sections.append((arp_cmd, self.trim_arp(co, ev, peer, vrf, plat)))
            # v3.15 (MOP: ping the neighbor) - the device ping output itself
            sections.append(self.device_ping_section(ev.get("device_ping"), plat, peer, vpn))
            sections.append(("show sdwan control connections" if ced else "show control connections",
                             self.trim_control(co.get("control_connections", ""))))
            sections.append(("CPU / memory (show processes cpu, show processes memory / show system status)",
                             self.trim_cpu_mem(co, ev)))
            if ced:
                sections.append(("show platform resources (platform health)",
                                 self.trim_platform_res(ev.get("platform_res", "") or co.get("platform_res", ""))))
        parts, used = [], 0
        for title, body in sections:
            if not (isinstance(body, str) and body.strip()):
                continue
            block = "Command: %s\nOutput:\n%s\n" % (self._etms_title(title), self.mask_secrets(body).strip("\n"))
            if used + len(block) > budget:
                continue
            parts.append(block)
            used += len(block)
        # v3.10: tier 2 - use the rest of the ticket budget for more useful,
        # still-trimmed context (priority order; a section that does not fit
        # is skipped and the next one is tried).
        if tier2:
            for title, body in self.noc_tier2_evidence(co, ev, plat, peer, path, per_cmd, api_data):
                block = "Command: %s\nOutput:\n%s\n" % (self._etms_title(title), self.mask_secrets(body).strip("\n"))
                if used + len(block) > budget:
                    continue
                parts.append(block)
                used += len(block)
        return "\n".join(parts)

    # ------------------------------------------------------------------ #
    # v3.10 - tier-2 NOC evidence: fills the remaining ticket budget with
    # useful, still-trimmed context (never raw dumps)
    # ------------------------------------------------------------------ #

    @staticmethod
    def _cap(body: str, limit: int) -> str:
        if len(body) <= limit:
            return body
        cut = body[:limit]
        cut = cut[:cut.rfind("\n")] if "\n" in cut else cut
        return cut.rstrip() + "\n... (output trimmed)"

    def trim_bfd_summary(self, text, max_down: int = 15) -> str:
        """'show [sdwan] bfd sessions' -> totals per local color + the DOWN
        sessions only (a fabric can have hundreds of sessions)."""
        if not self._usable(text):
            return ""
        per, down, total = {}, [], 0
        for ln in self._lines(text):
            f = ln.split()
            if len(f) < 6 or not re.match(r"^" + self._IP_RE + r"$", f[0]):
                continue
            total += 1
            state, lcol, rcol = f[2].lower(), f[3], f[4]
            up = per.setdefault(lcol, [0, 0])
            if state == "up":
                up[0] += 1
            else:
                up[1] += 1
                down.append("%-16s site %-10s %-6s %s -> %s" % (f[0], f[1], state, lcol, rcol))
        if not total:
            return ""
        out = ["Total %d session(s): %d up, %d not up" % (
            total, sum(v[0] for v in per.values()), sum(v[1] for v in per.values()))]
        for col, (u, d) in sorted(per.items()):
            out.append("  local color %-14s %d up / %d not up" % (col, u, d))
        if down:
            out.append("Not-up sessions (system-IP, site, state, local -> remote color):")
            out.extend("  " + d for d in down[:max_down])
            if len(down) > max_down:
                out.append("  ... %d more" % (len(down) - max_down))
        return "\n".join(out)

    def trim_table_rows(self, text, row_re: str, header_re: str = r"^\s*(PEER|TYPE|INTERFACE|NEIGHBOR|ID|TENANT)\b",
                        max_rows: int = 30, last: bool = False) -> str:
        """Generic: header lines + rows matching row_re (legend/blank lines
        dropped)."""
        if not self._usable(text):
            return ""
        hdr = [ln.rstrip() for ln in self._lines(text) if re.match(header_re, ln)]
        rows = [ln.rstrip() for ln in self._lines(text) if re.match(row_re, ln.strip(), re.I)]
        if not rows:
            return ""
        rows = rows[-max_rows:] if last else rows[:max_rows]
        return "\n".join(hdr[:3] + rows)

    def trim_ip_brief(self, text, desc_text=None) -> str:
        """'show ip interface brief': interfaces with an IP, plus any
        interface that is not up/up (unused unassigned up/up rows dropped).
        v3.14 (prod 20821): when 'show interfaces description' is given,
        loopbacks and unused ports (not up, no address, no description) are
        dropped too."""
        if not self._usable(text):
            return ""
        described = None
        if isinstance(desc_text, str) and self._usable(desc_text):
            described = set()
            for ln in self.trim_if_desc(desc_text, keep_loopback=True).splitlines()[1:]:
                nm = (ln.split() or [""])[0].lower()
                described.update({nm, self._short_if(nm)})
        out = []
        for ln in self._lines(text):
            f = ln.split()
            if not f:
                continue
            if f[0].lower() == "interface":
                out.append(ln.rstrip())
                continue
            if len(f) < 5 or not re.match(r"^[A-Za-z][\w./:-]*\d", f[0]):
                continue
            assigned = re.match(r"^" + self._IP_RE + r"$", f[1]) is not None
            notup = not (f[-2].lower() == "up" and f[-1].lower() == "up")
            if described is not None:
                nm = f[0].lower()
                if re.match(r"^(loopback|lo)\d", nm):
                    continue
                if notup and not assigned and nm not in described and self._short_if(nm) not in described:
                    continue
            if assigned or notup:
                out.append(ln.rstrip())
        return "\n".join(out) if len(out) > 1 else ""

    def trim_if_desc(self, text, keep_loopback: bool = False) -> str:
        """v3.14 (prod 20821): 'show interface(s) description' -> header +
        interfaces in use (a description is configured); loopbacks and
        unused / internal interfaces without a description are dropped.
        Falls back to the plain row filter when the header is not found."""
        if not self._usable(text):
            return ""
        lines = self._lines(text)
        hdr = next((ln for ln in lines if re.match(r"^\s*Interface\s+Status\s+Protocol\s+Description", ln)), "")
        col = hdr.find("Description") if hdr else -1
        if col < 0:
            vhdr = next((ln for ln in lines if re.match(r"^\s*VPN\s+INTERFACE\b.*\bDESC", ln)), "")
            if not vhdr:
                return ""
            # vEdge 'show interface description': VPN IF AF IP ADMIN OPER TRACKER DESC
            out = [vhdr.rstrip()]
            for ln in lines:
                f = ln.split()
                if len(f) < 7 or not f[0].isdigit():
                    continue
                name = f[1].lower()
                if name == "system" or re.match(r"^(loopback|lo)\d", name):
                    continue
                desc = " ".join(f[7:]).strip()
                if f[3] != "-" or desc not in ("", "-"):
                    out.append(ln.rstrip())
            return "\n".join(out) if len(out) > 1 else ""
        out = [hdr.rstrip()]
        for ln in lines:
            if ln is hdr or not ln.strip() or not re.match(r"^[A-Za-z]", ln):
                continue
            name = ln.split()[0]
            if re.match(r"^Interface$", name):
                continue
            if not keep_loopback and re.match(r"(?i)^(loopback|lo)\d", name):
                continue
            if len(ln) > col and ln[col:].strip():
                out.append(ln.rstrip())
        return "\n".join(out) if len(out) > 1 else ""

    def neighbor_block(self, text, peer: str) -> str:
        """Raw 'BGP neighbor is <peer>' block from the all-neighbors output."""
        if not self._usable(text) or not peer:
            return ""
        out, inside = [], False
        for ln in self._lines(text):
            if ln.strip().startswith("BGP neighbor is"):
                inside = re.match(r"^BGP neighbor is " + re.escape(peer) + r"\b", ln.strip()) is not None
            if inside:
                out.append(ln.rstrip())
        return "\n".join(out)

    def trim_cpu_top(self, evidence, n: int = 6) -> str:
        """cEdge 'show processes cpu sorted': utilization line + top N."""
        ev = evidence if isinstance(evidence, dict) else {}
        t = ev.get("cpu", "")
        if not self._usable(t):
            return ""
        lines = self._lines(t)
        out = [ln.strip() for ln in lines if ln.strip().startswith("CPU utilization")][:1]
        hdr = [ln.rstrip() for ln in lines if re.match(r"^\s*PID\s+Runtime", ln)][:1]
        rows = [ln.rstrip() for ln in lines if re.match(r"^\s*\d+\s+\d+\s+\d+", ln)][:n]
        return "\n".join(out + hdr + rows)

    def noc_tier2_evidence(self, cli_output, evidence=None, platform: str = "",
                           peer: str = "", path: str = "down", per_cmd: int = 2500,
                           api_data=None):
        """List of (title, body) for tier-2 context, in priority order.
        UP paths: none (v3.14). 'flap': transport context. DOWN paths:
        everything Tier-2 asks for per the MOP, each trimmed. SSH failed:
        vManage controller data. ('evidence' kept for the call signature.)"""
        co = cli_output if isinstance(cli_output, dict) else {}
        plat = str(platform or "").lower()
        ced = plat == "cedge"
        secs = []
        if plat not in ("cedge", "vedge"):
            ad = api_data if isinstance(api_data, dict) else {}
            cc = [r for r in (ad.get("control") or []) if isinstance(r, dict)]
            if cc:
                rows = ["%-8s %-16s %-16s %s" % ("PEER", "SYSTEM IP", "LOCAL COLOR", "STATE")]
                for r in cc[:20]:
                    rows.append(("%-8s %-16s %-16s %s" % (r.get("peer-type", ""), r.get("system-ip", ""),
                                                          r.get("local-color", ""), r.get("state", ""))).rstrip())
                secs.append(("vManage controller data - control connections", "\n".join(rows)))
            bfd = [r for r in (ad.get("bfd") or []) if isinstance(r, dict)]
            if bfd:
                st = {}
                for r in bfd:
                    k = str(r.get("state", "?")).lower()
                    st[k] = st.get(k, 0) + 1
                secs.append(("vManage controller data - BFD sessions",
                             "Total %d: %s" % (len(bfd), ", ".join("%d %s" % (v, k) for k, v in sorted(st.items())))))
            omp = [r for r in (ad.get("omp") or []) if isinstance(r, dict)]
            if omp:
                rows = ["%-16s %-8s %s" % ("PEER", "TYPE", "STATE")]
                for r in omp[:10]:
                    rows.append(("%-16s %-8s %s" % (r.get("peer", ""), r.get("type", ""), r.get("state", ""))).rstrip())
                secs.append(("vManage controller data - OMP peers", "\n".join(rows)))
            return [(t, self._cap(b, per_cmd)) for t, b in secs if b and b.strip()]
        bfd_cmd = "show sdwan bfd sessions" if ced else "show bfd sessions"
        omp_cmd = "show sdwan omp peers" if ced else "show omp peers"
        wan_cmd = "show sdwan control local-properties wan-interface-list" if ced else \
            "show control local-properties wan-interface-list"
        hist_cmd = "show sdwan control connection-history" if ced else "show control connections history"
        desc_cmd = "show interfaces description" if ced else "show interface description"
        bfd = (bfd_cmd + " (summary + not-up sessions)", self.trim_bfd_summary(co.get("bfd_sessions", "")))
        omp = (omp_cmd, self.trim_table_rows(co.get("omp_peers", ""), r"^\d+\s+" + self._IP_RE + r"\s+vsmart|^" + self._IP_RE + r"\s+vsmart"))
        wan = (wan_cmd + " (TLOCs)", self.trim_table_rows(
            co.get("wan_interface_list", ""), r"^(ge|gi|te|tu|ten|eth|cellular|dialer|lo|loopback|tunnel|gigabitethernet|tengigabitethernet)\S*\s",
            header_re=r"^\s*(INTERFACE|PUBLIC|PRIVATE|IPv4|COLOR)\b|^\s*PUBLIC\s"))
        # v3.14 (prod 20821): only interfaces in use (with a description),
        # loopbacks and unused ports dropped
        desc = (desc_cmd + " (interfaces in use)", self.trim_if_desc(co.get("interfaces_desc", "")))
        if path in ("up", "up_alarm"):
            # v3.14 (NOC, prod 20821): overlay tables are not relevant to the
            # closure and are left out. v3.15 (MOP Tier-2 list 'show interface
            # description/status'): the interfaces in use are shown.
            secs = [desc]
        elif path == "flap":
            # v3.14: BGP up, overlay flapping - transport context only
            secs = [
                (hist_cmd + " (latest)", self.trim_table_rows(co.get("control_history", ""), r"^(vsmart|vbond|vmanage|vedge)\s", max_rows=8, last=True)),
                wan, desc,
            ]
        else:
            # v3.14: the BGP log (peer + other neighbors) is in tier 1, first
            others = ""
            if ced:
                rows = self.parse_bgp_cedge_all(co, "")
                for r in self.get_stuck_neighbors(rows):
                    ip = r.get("neighbor", "")
                    if ip and ip != peer:
                        blk = (self.trim_bgp_neighbor(co.get("bgp_neighbors_vrf", ""), ip, "cedge")
                               or self.trim_bgp_neighbor(co.get("bgp_neighbors", ""), ip, "cedge"))
                        if blk:
                            others += (blk + "\n\n")
            secs = [
                ("show ip bgp neighbors (other down neighbors, key lines)", others.strip()),
                bfd, wan, desc,
                ("show ip interface brief (interfaces with an address / in use and not up)" if ced else "",
                 self.trim_ip_brief(co.get("ip_int_brief", ""), co.get("interfaces_desc", "")) if ced else ""),
                omp,
                (hist_cmd + " (latest)", self.trim_table_rows(co.get("control_history", ""), r"^(vsmart|vbond|vmanage|vedge)\s", max_rows=8, last=True)),
                # v3.14 (NOC, prod 20821): the FULL BGP configuration, the
                # FULL neighbor detail and the top-process list are no longer
                # added - tier 1 already carries the lines for the down peer
                # (config + key lines) and the CPU / memory summary.
            ]
        return [(t, self._cap(b.strip("\n"), per_cmd)) for t, b in secs if t and isinstance(b, str) and b.strip()]

    def bgp_class_alarms(self, alarms) -> list:
        """vManage alarm rows that are BGP alarms ('bgp' in type / rule_name /
        rule_name_display / eventname, case-insensitive). The role clears ONLY
        these - never unrelated alarms on the device (same principle as
        BFD-TLOC-VIPTELA-TRIAGE, which clears BFD-class alarms only)."""
        out = []
        for a in (alarms or []):
            if not isinstance(a, dict):
                continue
            keys = ("type", "rule_name", "rule_name_display", "eventname")
            text = " ".join(str(a.get(k, "") or "") for k in keys).lower()
            if "bgp" in text:
                out.append(a)
        return out

    @classmethod
    def _alarm_pairs(cls, obj, key="", out=None):
        """(key, value) leaves of an alarm row, nested dicts/lists walked."""
        out = [] if out is None else out
        if isinstance(obj, dict):
            for k, v in obj.items():
                cls._alarm_pairs(v, str(k), out)
        elif isinstance(obj, (list, tuple)):
            for v in obj:
                cls._alarm_pairs(v, key, out)
        elif obj is not None:
            out.append((key.lower(), str(obj)))
        return out

    def classify_bgp_alarms(self, alarms, alarm_vpn, in_vpn_neighbors, other_down) -> dict:
        """v3.13 option 4 (agreed 13-Oct-2026): when a BGP session in ANOTHER
        VPN is still down, every vManage BGP alarm must be attributed before
        anything is cleared:
          ours    - names a neighbor of the alarm VPN, or carries a VPN field
                    equal to the alarm VPN (and names no other-VPN neighbor)
          other   - names a still-down neighbor of another VPN, or carries a
                    VPN field of another VPN  -> never cleared
          unknown - neither -> caller clears nothing and does not close
        Returns {'ours','other','unknown'} as lists of uuids."""
        res = {"ours": [], "other": [], "unknown": []}
        vpn = self._norm_vrf(alarm_vpn) if str(alarm_vpn or "").strip() else ""
        ours_ips = [str(n.get("neighbor", "")) for n in (in_vpn_neighbors or []) if isinstance(n, dict)]
        other_ips = [str(n.get("neighbor", "")) for n in (other_down or []) if isinstance(n, dict)]
        other_vpns = {self._norm_vrf(n.get("vrf")) for n in (other_down or [])
                      if isinstance(n, dict) and self._norm_vrf(n.get("vrf")) not in ("", "?")}

        def _names(blob, ips):
            return any(ip and re.search(r"(?<![\d.])" + re.escape(ip) + r"(?![\d.])", blob) for ip in ips)
        for a in (alarms or []):
            if not isinstance(a, dict) or not a.get("uuid"):
                continue
            pairs = self._alarm_pairs(a)
            blob = " ".join(v for _, v in pairs)
            vpn_vals = {self._norm_vrf(v) for k, v in pairs
                        if re.search(r"vpn", k) and str(v).strip() != ""}
            if _names(blob, other_ips) or (vpn_vals & other_vpns) \
                    or (vpn and vpn_vals and vpn not in vpn_vals):
                res["other"].append(a["uuid"])
            elif _names(blob, ours_ips) or (vpn and vpn in vpn_vals):
                res["ours"].append(a["uuid"])
            else:
                res["unknown"].append(a["uuid"])
        return res

    def alarm_field_summary(self, alarms) -> list:
        """Jenkins-log only: for each alarm row, its field names and the
        values of VPN / peer / IP-like fields, so the vManage BGP alarm schema
        can be confirmed from a real run (no other values printed)."""
        out = []
        for a in (alarms or [])[:10]:
            if not isinstance(a, dict):
                continue
            pairs = self._alarm_pairs(a)
            keep = sorted({"%s=%s" % (k, v) for k, v in pairs
                           if re.search(r"vpn|peer|neighbor|ip|vrf", k) and len(v) < 60})
            out.append({"type": a.get("type", a.get("rule_name_display", "?")),
                        "fields": sorted({k for k, _ in pairs})[:40], "vpn_peer_values": keep[:20]})
        return out

    def admin_down_neighbors(self, neighbors: list) -> list:
        """Neighbors in admin shutdown ('Idle (Admin)')."""
        return [n for n in (neighbors or []) if isinstance(n, dict)
                and "admin" in str(n.get("state", "")).lower()]

    def bgp_session_up_from_output(self, output_text: str) -> bool:
        """True when a recheck CLI dump shows at least one Established session
        and no stuck session, using both summary and detail layouts."""
        if not isinstance(output_text, str) or not output_text.strip():
            return False
        low = output_text.lower()
        has_est = ("established" in low) or bool(
            re.search(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b.*\b\d+\s*$", output_text, re.M)
        )
        has_stuck = any(re.search(r"\b" + s + r"\b", low) for s in self._STUCK_STATES)
        return has_est and not has_stuck

    def get_bgp_state_diagnosis(self, state: str) -> str:
        """NOC-facing likely-cause text for a stuck BGP state (per MOP)."""
        st = str(state).strip().lower()
        diag = {
            "idle": ("IDLE: neighbor IP mismatch, wrong AS, neighbor not "
                     "configured on ISP/peer side, or the session was cleared. "
                     "Verify neighbor IP and remote-AS on both sides."),
            "active": ("ACTIVE: TCP/179 blocked by ACL/firewall/ISP, route to "
                       "peer exists but TCP is refused, MD5 mismatch, or wrong "
                       "BGP source interface. Verify TCP/179 path and MD5."),
            "connect": ("CONNECT: TCP three-way handshake not completing, "
                        "asymmetric routing, or MTU mismatch. traceroute to peer "
                        "and verify forward/return paths and MTU."),
            "opensent": ("OPENSENT: AS number mismatch or MD5 authentication "
                         "mismatch; OPEN rejected by peer. Verify remote-AS and "
                         "auth; check BGP logs for NOTIFICATION."),
            "openconfirm": ("OPENCONFIRM: AS mismatch, MD5 key mismatch, or "
                            "address-family capability mismatch. Verify AS/auth "
                            "and the NOTIFICATION error code."),
            "unknown": ("State could not be determined from CLI. SSH to device "
                        "and run 'show bgp summary'."),
        }
        return diag.get(st, "State %s: run 'show bgp summary' and 'show bgp "
                             "neighbor' for detail." % str(state).upper())

    def build_clear_commands_cedge(self, stuck_neighbors: list, vpn_id: str = "0") -> list:
        """cEdge BGP clear commands (single neighbor, VRF-scoped only).

        Default VRF (vpn 0): 'clear ip bgp <ip>'
        Non-default VRF     : 'clear ip bgp vpnv4 vrf <vpn> <ip>'
        Never emits a global 'clear ip bgp *'.
        """
        cmds = []
        if not isinstance(stuck_neighbors, list):
            return cmds
        for n in stuck_neighbors:
            ip = n.get("neighbor", "") if isinstance(n, dict) else ""
            if not ip:
                continue
            if str(vpn_id) in ("0", ""):
                cmds.append("clear ip bgp %s" % ip)
            else:
                cmds.append("clear ip bgp vpnv4 vrf %s %s" % (vpn_id, ip))
        return cmds

    def build_clear_commands_vedge(self, stuck_neighbors: list, vpn_id: str = "0") -> list:
        """vEdge BGP clear commands.

        Confirmed vEdge OS syntax requires the VPN qualifier (the device
        prompts interactively if it is omitted, which blocks automation):
          'clear bgp neighbor <ip> vpn <vpn_id>'
        """
        cmds = []
        if not isinstance(stuck_neighbors, list):
            return cmds
        v = str(vpn_id) if str(vpn_id).strip() else "0"
        for n in stuck_neighbors:
            ip = n.get("neighbor", "") if isinstance(n, dict) else ""
            if not ip:
                continue
            cmds.append("clear bgp neighbor %s vpn %s" % (ip, v))
        return cmds

    # ------------------------------------------------------------------ #
    # Interface parsing and LAN selection
    # ------------------------------------------------------------------ #

    def parse_interface_list_cedge(self, output_text: str) -> list:
        """Parse cEdge 'show interfaces description'.

        Columns: Interface  Status  Protocol  Description
        """
        interfaces = []
        if not isinstance(output_text, str) or not output_text.strip():
            return interfaces
        for raw in output_text.splitlines():
            line = raw.rstrip()
            if not line.strip() or re.match(r"^\s*Interface\b", line, re.IGNORECASE):
                continue
            parts = line.split()
            if len(parts) >= 3:
                desc = " ".join(parts[3:]) if len(parts) > 3 else ""
                interfaces.append({
                    "name": parts[0],
                    "status": parts[1].lower(),
                    "protocol": parts[2].lower(),
                    "description": desc,
                })
        return interfaces

    def parse_interface_list_vedge(self, output_text: str) -> list:
        """Parse vEdge 'show interface description'.

        Ground-truth columns (Vedge.docx image 11):
          VPN | INTERFACE | AF | IP ADDRESS | IF-ADMIN | IF-OPER | IF-TRACKER |
          DESC ... | IPV6-ADMIN
        i.e. admin status is column index 4, oper status is column index 5,
        the description spans from index 7 up to the final IPV6-ADMIN token.
        """
        interfaces = []
        if not isinstance(output_text, str) or not output_text.strip():
            return interfaces
        for raw in output_text.splitlines():
            line = raw.rstrip()
            s = line.strip()
            if not s:
                continue
            if re.match(r"^(VPN|IF|INTERFACE)\b", s, re.IGNORECASE):
                continue
            if s.startswith("-"):
                continue
            parts = s.split()
            # Need at least VPN, IF, AF, IP, ADMIN, OPER, TRACKER
            if len(parts) < 7:
                continue
            if not re.match(r"^\d+$", parts[0]):   # VPN column must be numeric
                continue
            admin = parts[4].lower()
            oper = parts[5].lower()
            # Description is everything between TRACKER (idx 6) and the final
            # IPV6-ADMIN token; when only one trailing token exists, no desc.
            if len(parts) >= 9:
                desc = " ".join(parts[7:-1])
            elif len(parts) == 8:
                desc = ""
            else:
                desc = ""
            interfaces.append({
                "vpn": parts[0],
                "name": parts[1],
                "ip": parts[3],
                "status": admin,
                "protocol": oper,
                "description": desc,
            })
        return interfaces

    def select_lan_down_interfaces(self, interfaces, exclude_ips=None,
                                   exclude_names=None) -> list:
        """Select LAN-side interfaces that are operationally down/down.

        Guards (per MOP + safety):
          - description must contain 'LAN'
          - both admin and oper status must be 'down'
          - never tunnel / loopback / management / virtual interfaces
          - never the SSH management IP or a known WAN interface
        Returns a list of interface NAME strings safe to bounce.
        """
        safe = []
        if not isinstance(interfaces, list):
            return safe
        excluded_pfx = ("tu", "loop", "lo", "null", "vl", "bdi", "mg", "bvi", "system")
        ex_ips = set(exclude_ips or [])
        ex_names = set(str(n).lower() for n in (exclude_names or []) if n)
        for iface in interfaces:
            if not isinstance(iface, dict):
                continue
            name = str(iface.get("name", "")).lower()
            desc = str(iface.get("description", "")).lower()
            status = str(iface.get("status", "")).lower()
            protocol = str(iface.get("protocol", "")).lower()
            ip = str(iface.get("ip", ""))
            if ip and ip.split("/")[0] in ex_ips:
                continue
            if name in ex_names:
                continue
            if "lan" not in desc:
                continue
            if any(name.startswith(p) for p in excluded_pfx):
                continue
            if not (status == "down" and protocol == "down"):
                continue
            safe.append(iface.get("name", ""))
        return [n for n in safe if n]

    def get_wan_interface_from_wan_list(self, wan_list_output: str) -> str:
        """Return the first UP WAN transport interface from
        'show [sdwan] control local-properties wan-interface-list'.

        Ground truth (Vedge.docx image3 / Cedge.docx image5): the INTERFACE is
        the first column and STATE ('up'/'down') appears later on the row. We
        return the first interface whose row contains a standalone 'up'.
        """
        if not isinstance(wan_list_output, str) or not wan_list_output.strip():
            return ""
        for raw in wan_list_output.splitlines():
            s = raw.strip()
            if not s or s.startswith("-"):
                continue
            low = s.lower()
            if low.startswith("interface") or "nat type" in low or "public" in low:
                continue
            parts = s.split()
            if not parts:
                continue
            name = parts[0]
            # interface token looks like ge0/1, GigabitEthernet0/0/1, cellular0
            if not re.match(r"^[A-Za-z]", name):
                continue
            if re.search(r"\bup\b", low) and not re.search(r"\bdown\b", low):
                return name
        return ""

    def device_ping_ok_from_output(self, ping_output: str) -> bool:
        """True when a device-sourced ping output indicates success.

        Matches IOS-XE '!!!!!' / 'Success rate is <n>' and Viptela
        '0% packet loss' / 'bytes from' forms.
        """
        if not isinstance(ping_output, str) or not ping_output.strip():
            return False
        low = ping_output.lower()
        if re.search(r"success rate is\s*[1-9]", low):
            return True
        if "!!!!!" in ping_output:
            return True
        if re.search(r"\b0%\s*packet loss", low):
            return True
        if re.search(r"\bbytes from\b", low):
            return True
        return False

    def device_ping_ran_from_output(self, ping_output: str) -> bool:
        """v3.12: True when the device printed a ping RESULT (success or
        failure), i.e. the device-sourced ping really ran. A rejected command
        or empty read returns False so the caller can fall back to the
        automation-host ping instead of treating it as 'no reply'."""
        if not isinstance(ping_output, str) or not ping_output.strip():
            return False
        low = ping_output.lower()
        if self.device_ping_ok_from_output(ping_output):
            return True
        return bool(re.search(r"success rate is\s*\d+\s*percent", low)
                    or re.search(r"\d+\s*packets transmitted", low)
                    or re.search(r"\b100(?:\.0+)?%\s*packet loss", low))

    # ------------------------------------------------------------------ #
    # Flap counters (vManage history)
    # ------------------------------------------------------------------ #

    @staticmethod
    def _event_epoch_ms(entry: dict):
        # v3.8.4: event-time keys first. SIT (cpe4) showed vManage BFD history
        # rows carry the event time in 'time-date' and the poll time in
        # 'lastupdated'; reading 'lastupdated' put OLD down events inside the
        # flap window -> false "flapping" -> closure blocked.
        for key in ("downtime-date", "time-date", "create_time_stamp", "entry_time",
                    "event_time", "create_time", "statechange_time", "lastupdated"):
            val = entry.get(key)
            if val in (None, ""):
                continue
            try:
                num = int(float(val))
                if num > 10 ** 14:
                    continue
                return num if num > 10_000_000_000 else num * 1000
            except (ValueError, TypeError):
                # v3.14 (prod 20821): a text event time ('2026-10-13 11:00:00'
                # / ISO) is the EVENT time - read it instead of falling through
                # to 'lastupdated' (poll time), which put old events in the window
                ep = FilterModule._utc_epoch(val)
                if ep is not None:
                    return ep * 1000
                continue
        return None

    def count_control_flaps(self, history: list, window_minutes: int = 0) -> int:
        """Count vsmart/vmanage control-connection down events (optionally
        within a trailing window). 'connect' is excluded as a normal transient."""
        if not isinstance(history, list):
            return 0
        cutoff_ms = 0
        if window_minutes and window_minutes > 0:
            cutoff_ms = int(time.time() * 1000) - (window_minutes * 60 * 1000)
        count = 0
        for h in history:
            if not isinstance(h, dict):
                continue
            state = str(h.get("state") or "").strip().lower()
            peer = str(h.get("peer-type") or "").strip().lower()
            if peer not in ("vsmart", "vmanage"):
                continue
            if state not in ("down", "tear_down", "tear-down", "connect_fail",
                             "connect-fail", "challenge_fail"):
                continue
            if cutoff_ms:
                ts = self._event_epoch_ms(h)
                if ts is not None and ts < cutoff_ms:
                    continue
            count += 1
        return count

    def count_bfd_flaps(self, history: list, window_minutes: int = 0) -> int:
        """Count BFD session down events, optionally within a trailing window."""
        if not isinstance(history, list):
            return 0
        cutoff_ms = 0
        if window_minutes and window_minutes > 0:
            cutoff_ms = int(time.time() * 1000) - (window_minutes * 60 * 1000)
        count = 0
        for h in history:
            if not isinstance(h, dict):
                continue
            if str(h.get("state") or "").strip().lower() != "down":
                continue
            if cutoff_ms:
                ts = self._event_epoch_ms(h)
                if ts is not None and ts < cutoff_ms:
                    continue
            count += 1
        return count

    # ------------------------------------------------------------------ #
    # Output helpers
    # ------------------------------------------------------------------ #

    def cap_text(self, text, max_chars: int = 24000) -> str:
        """Hard-cap a rendered report. iAutomate rejects payloads beyond ~25k
        characters and an oversized argument trips Linux MAX_ARG_STRLEN before
        that; this is the final backstop after per-section budgeting."""
        s = "" if text is None else str(text)
        try:
            limit = int(max_chars)
        except (TypeError, ValueError):
            limit = 24000
        if len(s) <= limit:
            return s
        marker = "\n... (output trimmed)\n"
        return s[: max(0, limit - len(marker))] + marker

    def trim_cli_noise(self, text):
        """Strip certificate PEM/modulus blocks and control-history error
        legends that add bulk without triage value."""
        if not isinstance(text, str) or not text.strip():
            return text
        out = []
        skip_legend = False
        skip_cert = False
        for line in text.split("\n"):
            low = line.strip().lower()
            if "legend for errors" in low:
                skip_legend = True
                continue
            if skip_legend:
                if line.strip().startswith("-" * 10):
                    skip_legend = False
                    out.append(line)
                continue
            if "modulus:" in low or "public-key:" in low:
                skip_cert = True
                out.append(line.rstrip())
                out.append("                    (data omitted)")
                continue
            if skip_cert:
                s = line.strip()
                if not s:
                    continue
                if s.startswith("Exponent:") or s.startswith("-----"):
                    continue
                if "(data omitted)" in s:
                    continue
                is_hex = (":" in s and len(s) > 5 and
                          sum(1 for ch in s if ch in "0123456789abcdefABCDEF:") > len(s) * 0.5)
                if is_hex:
                    continue
                skip_cert = False
            out.append(line)
        return "\n".join(out)

    def strip_invalid_commands(self, cli_output):
        """Drop CLI sections whose entire content is an invalid-command marker."""
        if not isinstance(cli_output, dict):
            return cli_output
        cleaned = {}
        for key, val in cli_output.items():
            if not isinstance(val, str):
                cleaned[key] = val
                continue
            stripped = val.strip()
            if not stripped:
                continue
            low = stripped.lower()
            if any(m in low for m in ("% invalid input", "syntax error",
                                      "unknown command", "% unrecognized")):
                continue
            cleaned[key] = val
        return cleaned

    def trim_proc_output(self, output_text, top_n: int = 10) -> str:
        """Trim 'show processes cpu/memory sorted' to header + top N rows.

        Untrimmed process tables (~1600 lines) can push the payload past the
        iAutomate/Jenkins argument-length limit; the device output is already
        sorted descending, so the first N rows are the busiest processes.
        """
        if not isinstance(output_text, str) or not output_text.strip():
            return output_text if isinstance(output_text, str) else ""
        lines = output_text.splitlines()
        header_idx = None
        for i, line in enumerate(lines):
            if "PID" in line and "Process" in line:
                header_idx = i
                break
        if header_idx is None:
            return output_text
        preamble = lines[: header_idx + 1]
        data_rows = [ln for ln in lines[header_idx + 1:] if ln.strip()]
        total_line = None
        for ln in reversed(data_rows):
            if "Total" in ln:
                total_line = ln
                break
        trimmed = data_rows[:max(0, int(top_n))]
        result = preamble + trimmed
        if total_line and total_line not in trimmed:
            result.append(total_line)
        result.append("... (trimmed to top %d of %d process rows)"
                      % (int(top_n), len(data_rows)))
        return "\n".join(result)

    def format_vmanage_bgp_summary(self, store: dict) -> str:
        """Render the vManage-collected dataset (BGP + control/omp/bfd/alarms)
        into a compact NOC-readable block. `store` is a dict of the collected
        vmanage_* lists keyed by a short label."""
        if not isinstance(store, dict):
            return ""
        lines = ["[vMANAGE DATA]"]
        bgp = store.get("bgp_summary", []) or []
        lines.append("  BGP neighbors (API) : %d" % len(bgp))
        for row in bgp[:20]:
            if isinstance(row, dict):
                lines.append("    - %s AS%s vpn%s state=%s" % (
                    row.get("neighbor", "?"), row.get("remote_as", "?"),
                    row.get("vrf", "?"), str(row.get("state", "?")).upper()))
        cc = store.get("control_connections", []) or []
        up = sum(1 for c in cc if isinstance(c, dict)
                 and str(c.get("state", "")).lower() == "up")
        lines.append("  Control connections : %d up / %d total" % (up, len(cc)))
        lines.append("  OMP peers           : %d" % len(store.get("omp_peers", []) or []))
        lines.append("  BFD sessions        : %d" % len(store.get("bfd_sessions", []) or []))
        lines.append("  Control flaps (win) : %s" % store.get("control_flap_count", "0"))
        lines.append("  BFD flaps (win)     : %s" % store.get("bfd_flap_count", "0"))
        lines.append("  Recent reboot (2h)  : %s" % store.get("recent_reboot", False))
        lines.append("  Active alarms       : %d" % len(store.get("active_alarms", []) or []))
        return "\n".join(lines)

    def format_cli_summary(self, cli_output: dict, budget: int = 15000) -> str:
        """Render collected CLI command outputs into a bounded diagnostic
        block. Each command is trimmed of certificate/legend noise; the whole
        block is capped to `budget` characters."""
        if not isinstance(cli_output, dict) or not cli_output:
            return "[CLI DIAGNOSTICS]\n  (no CLI output collected)"
        try:
            limit = int(budget)
        except (TypeError, ValueError):
            limit = 15000
        parts = ["[CLI DIAGNOSTICS]"]
        for name, text in cli_output.items():
            if not isinstance(text, str) or not text.strip():
                continue
            body = self.trim_cli_noise(text)
            parts.append("\n--- %s ---\n%s" % (name, body.rstrip()))
        joined = "\n".join(parts)
        if len(joined) > limit:
            joined = joined[: max(0, limit - 60)] + \
                "\n... (CLI diagnostics trimmed to fit payload budget)"
        return joined

    # ------------------------------------------------------------------ #
    # Sep 2026 NOC ticket-review fixes (additive; existing filters unchanged)
    # ------------------------------------------------------------------ #

    # Vendored copy of ntc-templates cisco_ios_show_ip_bgp_summary.textfsm
    # (github.com/networktocode/ntc-templates, Apache-2.0). Embedded so the
    # role does not depend on the ntc_templates package or a file path; only
    # the 'textfsm' library is needed, and a regex fallback covers its absence.
    _NTC_BGP_SUMMARY_TEMPLATE = (
        "Value Filldown,Required ROUTER_ID ([0-9a-f:\\.]+)\n"
        "Value Filldown LOCAL_AS (\\d+(\\.\\d+)?)\n"
        "Value Filldown ADDRESS_FAMILY (.+?)\n"
        "Value BGP_NEIGHBOR (\\d+?\\.\\d+?\\.\\d+?\\.\\d+?)\n"
        "Value BGP_VERSION (\\d+)\n"
        "Value NEIGHBOR_AS (\\d+(\\.\\d+)?)\n"
        "Value MESSAGES_RECEIVED (\\d+)\n"
        "Value MESSAGES_SENT (\\d+)\n"
        "Value TABLE_VERSION (\\d+)\n"
        "Value INPUT_QUEUE (\\d+)\n"
        "Value OUTPUT_QUEUE (\\d+)\n"
        "Value UP_DOWN (\\S+?)\n"
        "Value STATE_OR_PREFIXES_RECEIVED (\\S+?\\s+\\S+?|\\S+?)\n"
        "\n"
        "Start\n"
        "  ^For\\s+address\\s+family:\\s+${ADDRESS_FAMILY}$$\n"
        "  ^BGP\\s+router\\s+identifier\\s+${ROUTER_ID},\\s+local\\s+AS\\s+number\\s+${LOCAL_AS}\\s*$$\n"
        "  ^${BGP_NEIGHBOR}\\s+${BGP_VERSION}\\s+${NEIGHBOR_AS}\\s+${MESSAGES_RECEIVED}\\s+"
        "${MESSAGES_SENT}\\s+${TABLE_VERSION}\\s+${INPUT_QUEUE}\\s+${OUTPUT_QUEUE}\\s+"
        "${UP_DOWN}\\s+${STATE_OR_PREFIXES_RECEIVED}\\s*$$ -> Record\n"
        "  ^Load\\s+for\\s+\n"
        "  ^Time\\s+source\\s+is\n"
        "\n"
    )

    _IPV4 = r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"

    def extract_vpn_scope_from_text(self, alarm_text: str) -> str:
        """VPN the alarm is about, used ONLY to scope which BGP rows count.

        'Default'/'global' (prod alarm token) -> '0' (global/transport table).
        Trailing integer -> that VPN. Anything else -> '' meaning 'unscoped'
        (all rows are considered), so an unexpected alarm shape never hides a
        neighbor. The peer IP itself always comes from the device.
        """
        if not isinstance(alarm_text, str) or not alarm_text.strip():
            return ""
        last = alarm_text.strip().split()[-1]
        if re.match(r"^\d+$", last):
            return last
        if last.lower() in ("default", "global"):
            return "0"
        return ""

    def extract_hostname_from_description(self, desc: str) -> str:
        """HOSTNAME field of the ticket Description (device hostname, which
        can differ from the NEID). Returns '' when absent."""
        if not isinstance(desc, str):
            return ""
        m = re.search(r"(?im)^\s*HOSTNAME\s*:\s*(\S+)", desc)
        return m.group(1).strip() if m else ""

    def _bgp_rows_textfsm(self, text: str) -> list:
        if not _HAS_TEXTFSM:
            return []
        try:
            fsm = textfsm.TextFSM(io.StringIO(self._NTC_BGP_SUMMARY_TEMPLATE))
            rows = fsm.ParseText(text)
            hdr = fsm.header
        except Exception:  # noqa: BLE001 - any template/parse failure -> regex fallback
            return []
        out = []
        for r in rows:
            d = dict(zip(hdr, r))
            if not d.get("BGP_NEIGHBOR"):
                continue  # Filldown leaves an empty trailing record
            out.append({"neighbor": d["BGP_NEIGHBOR"],
                        "remote_as": d.get("NEIGHBOR_AS", ""),
                        "af": d.get("ADDRESS_FAMILY", "") or "IPv4 Unicast",
                        "up_down": d.get("UP_DOWN", ""),
                        "state_raw": d.get("STATE_OR_PREFIXES_RECEIVED", "")})
        return out

    def _bgp_rows_regex(self, text: str) -> list:
        out = []
        af = "IPv4 Unicast"
        row_re = re.compile(r"^(" + self._IPV4 + r")\s+\d+\s+(\d+(?:\.\d+)?)\s+\d+\s+\d+\s+\d+"
                            r"\s+\d+\s+\d+\s+(\S+)\s+(\S+(?:\s+\S+)?)\s*$")
        for line in text.splitlines():
            m = re.match(r"^\s*For\s+address\s+family:\s+(.+?)\s*$", line)
            if m:
                af = m.group(1)
                continue
            m = row_re.match(line.strip())
            if m:
                out.append({"neighbor": m.group(1), "remote_as": m.group(2), "af": af,
                            "up_down": m.group(3), "state_raw": m.group(4)})
        return out

    def _bgp_state_of(self, raw: str) -> str:
        raw = (raw or "").strip()
        if re.match(r"^\d+$", raw):
            return "established"
        if "(admin)" in raw.lower():
            return "admin_down"
        return raw.split()[0].lower() if raw else "unknown"

    def parse_bgp_cedge_scoped(self, cli_output, vpn_scope: str = "") -> list:
        """cEdge BGP rows from 'show ip bgp all summary' (and, for a service
        VPN alarm, 'show ip bgp vpnv4 vrf <n> summary'), tagged per address
        family and scoped to the alarm VPN.

        Scope '0'  -> IPv4 Unicast (global/transport) rows only.
        Scope 'n'  -> rows of 'show ip bgp vpnv4 vrf n summary'; if that command
                      returned nothing usable, all VPNv4 rows are used and marked
                      vrf_confirmed=False (a superset: 'all up' over a superset
                      still implies the alarm VRF is up, so closure stays safe).
        Scope ''   -> every row (unscoped).
        Parser: TextFSM (ntc template) when available, regex otherwise.
        """
        co = cli_output if isinstance(cli_output, dict) else {}
        scope = str(vpn_scope or "")

        def parse(text):
            if not isinstance(text, str) or not text.strip():
                return []
            rows = self._bgp_rows_textfsm(text)
            return rows if rows else self._bgp_rows_regex(text)

        def finish(rows, vrf, confirmed=True):
            res = []
            for r in rows:
                res.append({"neighbor": r["neighbor"], "remote_as": r["remote_as"],
                            "vrf": vrf, "af": r["af"], "up_down": r["up_down"],
                            "state": self._bgp_state_of(r["state_raw"]),
                            "pfx_or_state": r["state_raw"], "vrf_confirmed": confirmed})
            return res

        all_rows = parse(co.get("bgp_summary", ""))
        if scope == "0":
            return finish([r for r in all_rows if r["af"].lower().startswith("ipv4 unicast")], "0")
        if scope:
            vrf_text = co.get("bgp_summary_vrf", "")
            vrf_rows = parse(vrf_text)
            if vrf_rows:
                return finish(vrf_rows, scope)
            return finish([r for r in all_rows if r["af"].lower().startswith("vpnv4")],
                          scope, confirmed=False)
        out = []
        for r in all_rows:
            out.extend(finish([r], "0" if r["af"].lower().startswith("ipv4 unicast") else "?"))
        return out

    def scope_bgp_neighbors(self, neighbors, vpn_scope: str = "",
                            fallback_unscoped: bool = False) -> list:
        """Keep neighbors whose VPN/VRF equals the alarm scope.

        vrf values: '0'/'default'/'global' all mean the global table. With
        fallback_unscoped=True (vManage API rows, whose VPN field naming is not
        verified), an empty scoped result returns all rows marked
        vrf_confirmed=False instead of silently dropping them.
        """
        if not isinstance(neighbors, list):
            return []
        scope = str(vpn_scope or "")
        if not scope:
            return neighbors

        def norm(v):
            v = str(v or "").strip().lower()
            return "0" if v in ("0", "default", "global") else v

        kept = [n for n in neighbors if isinstance(n, dict) and norm(n.get("vrf")) == scope]
        if kept or not fallback_unscoped:
            return kept
        out = []
        for n in neighbors:
            if isinstance(n, dict):
                m = dict(n)
                m["vrf_confirmed"] = False
                out.append(m)
        return out

    # ------------------------------------------------------------------ #
    # v3.4 - device-wide review for "All BGP peering sessions are down"
    # ------------------------------------------------------------------ #

    def is_all_sessions_alarm(self, alarm_text) -> bool:
        """True for the device-wide alarm 'All BGP peering sessions are down'.

        NOC review (Oct 2026): for this alarm the whole device BGP summary
        ('show ip bgp all summary' / 'show bgp summary') must be reviewed,
        not only the VPN named at the end of the alarm text.
        """
        if not isinstance(alarm_text, str):
            return False
        return re.search(r"all\s+bgp\s+peering\s+sessions", alarm_text,
                         re.IGNORECASE) is not None

    @staticmethod
    def _norm_vrf(v) -> str:
        v = str(v if v is not None else "").strip().lower()
        return "0" if v in ("0", "default", "global") else v

    def parse_bgp_cedge_all(self, cli_output, vpn_scope: str = "") -> list:
        """Every neighbor in cEdge 'show ip bgp all summary' (all address
        families). VRF tag: IPv4 Unicast -> '0'; a VPNv4 neighbor also listed
        in 'show ip bgp vpnv4 vrf <n> summary' -> '<n>'; any other VPNv4
        neighbor -> '?' (the all-summary output does not print the VRF)."""
        co = cli_output if isinstance(cli_output, dict) else {}
        rows = self.parse_bgp_cedge_scoped(co, "")
        scope = str(vpn_scope or "")
        vrf_ips = set()
        if scope and scope != "0":
            vrf_ips = {r.get("neighbor") for r in self.parse_bgp_cedge_scoped(co, scope)
                       if isinstance(r, dict) and r.get("vrf_confirmed")}
        out = []
        for r in rows:
            m = dict(r)
            if str(m.get("af", "")).lower().startswith("ipv4 unicast"):
                m["vrf"], m["vrf_confirmed"] = "0", True
            elif m.get("neighbor") in vrf_ips:
                m["vrf"], m["vrf_confirmed"] = scope, True
            else:
                m["vrf"], m["vrf_confirmed"] = "?", False
            out.append(m)
        return out

    def neighbors_in_vpn(self, neighbors, vpn_id) -> list:
        """Neighbors whose VRF/VPN is confirmed equal to vpn_id."""
        want = self._norm_vrf(vpn_id if str(vpn_id or "").strip() else "0")
        return [n for n in (neighbors or []) if isinstance(n, dict)
                and self._norm_vrf(n.get("vrf")) == want
                and n.get("vrf_confirmed", True) is not False]

    def neighbors_outside_vpn(self, neighbors, vpn_id) -> list:
        """Neighbors NOT confirmed to be in vpn_id (other VPN or unknown)."""
        inside = self.neighbors_in_vpn(neighbors, vpn_id)
        return [n for n in (neighbors or []) if isinstance(n, dict) and n not in inside]

    def neighbor_vrf(self, neighbors, peer) -> str:
        """VRF tag of `peer` in the neighbor list ('' if not listed)."""
        for n in (neighbors or []):
            if isinstance(n, dict) and str(n.get("neighbor", "")) == str(peer or ""):
                return str(n.get("vrf", ""))
        return ""

    # ------------------------------------------------------------------ #
    # v3.6 - standard NOC header + cosmetic helpers
    # ------------------------------------------------------------------ #

    _DESC_LABELS = ("INCIDENT START TIME", "NEID", "HOSTNAME", "IP ADDRESS",
                    "PRODUCT TYPE", "EQUIPMENT TYPE", "TICKET TYPE",
                    "INCIDENT TYPE", "SOURCED FROM", "ASSURE1 ALARM ID",
                    "TEXT", "AID")

    def desc_field(self, desc, label: str) -> str:
        """Value of '<LABEL>: value' in the ticket Description ('' if absent).
        Works on one-line and multi-line Descriptions: the value stops at the
        next known label. Ticket data only - used for the INCIDENT
        INFORMATION block, never for device decisions."""
        if not isinstance(desc, str) or not label:
            return ""
        others = "|".join(re.escape(x) for x in self._DESC_LABELS
                          if x != str(label).upper())
        pat = (r"(?i)" + re.escape(str(label)) + r"\s*:\s*(.*?)"
               r"(?=\s+(?:" + others + r")\s*:|\s+SOURCED\s+FROM\b|\n|$)")
        m = re.search(pat, desc)
        return m.group(1).strip() if m else ""

    def fmt_run_time(self, ts) -> str:
        """'YYYY-MM-DD HH:MM:SS' -> 'MM-DD-YYYY HH:MM:SS' (standard NOC
        header format). Anything else is returned unchanged."""
        s = str(ts or "").strip()
        m = re.match(r"^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}:\d{2}:\d{2})", s)
        if not m:
            return s or "N/A"
        return "%s-%s-%s %s" % (m.group(2), m.group(3), m.group(1), m.group(4))

    def esp_customer_details(self, esp_json, dns_entity: str = "",
                             host_name: str = "", strict: bool = False) -> dict:
        """ESP inventory-search response -> {customer, noc, network_domain}
        for the alarmed device (row whose device.dnsEntityName or
        entityHostName matches; else the first row). Same mapping as
        BFD-TLOC-VIPTELA-TRIAGE: device.mgmtCenter -> NOC, networkDomain ->
        Domain. Display only; '' values when absent. Never raises.
        strict=True: no first-row fallback (only the alarmed device's row)."""
        empty = {"customer": "", "noc": "", "network_domain": ""}
        devices = []
        if isinstance(esp_json, dict):
            devices = esp_json.get("devices") or esp_json.get("data") or []
        elif isinstance(esp_json, list):
            devices = esp_json
        if not isinstance(devices, list):
            return empty
        dns = str(dns_entity or "").strip().lower()
        host = str(host_name or "").strip().lower()
        rows = [r for r in devices if isinstance(r, dict)]
        chosen = None
        for row in rows:
            dev = row.get("device") if isinstance(row.get("device"), dict) else {}
            names = [str(dev.get("dnsEntityName", "")).strip().lower(),
                     str(dev.get("entityHostName", "")).strip().lower()]
            if (dns and dns in names) or (host and host in names):
                chosen = row
                break
        if chosen is None and rows and not strict:
            chosen = rows[0]
        if chosen is None:
            return empty
        dev = chosen.get("device") if isinstance(chosen.get("device"), dict) else {}
        return {
            "customer": str(chosen.get("espCustomerName", "") or chosen.get("shortName", "") or ""),
            "noc": str(dev.get("mgmtCenter", "") or chosen.get("mgmtCenter", "") or ""),
            "network_domain": str(chosen.get("networkDomain", "") or dev.get("networkDomain", "") or ""),
        }

    def domain_number(self, network_domain) -> str:
        """'td30.mso.mci.com' / 'd49.mso.mci.com' -> '30' / '49' (digits of
        the first label); '' when there are none."""
        first = str(network_domain or "").strip().split(".")[0]
        m = re.search(r"(\d+)", first)
        return m.group(1) if m else ""

    def fmt_alarm_time(self, ts) -> str:
        """Ticket 'INCIDENT START TIME' '09/22/2026 13:48:23' -> '09-22-2026
        13:48:23' (same style as Run Time). Non-date values -> 'N/A'."""
        s = str(ts or "").strip()
        # v3.13: ISO form from the 'Router::PNF' description (prod 1956)
        iso = re.match(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}:\d{2}(?::\d{2})?)", s)
        if iso:
            return "%s-%s-%s %s%s" % (iso.group(2), iso.group(3), iso.group(1), iso.group(4),
                                      " UTC" if s.upper().endswith("Z") else "")
        m = re.match(r"^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})(\s+\d{1,2}:\d{2}(?::\d{2})?)?", s)
        if not m:
            return "N/A"
        return "%s-%s-%s%s" % (m.group(1), m.group(2), m.group(3), m.group(4) or "")

    def clean_reason(self, text) -> str:
        """Readable one-line reason: drops Python noise such as
        '[Errno None] ' and trailing periods (the template adds one)."""
        s = " ".join(str(text or "").split())
        s = re.sub(r"\[Errno [^\]]*\]\s*", "", s)
        return s.rstrip(" .") or "reason not recorded"

    def parse_system_uptime(self, system_status: str) -> dict:
        """Uptime and last reboot reason exactly as printed by
        'show sdwan system status' (cEdge) / 'show system status' (vEdge)."""
        res = {"uptime": "", "last_reboot": ""}
        if not isinstance(system_status, str):
            return res
        m = re.search(r"(?im)^\s*System uptime:\s*(.+?)\s*$", system_status)
        if m:
            res["uptime"] = m.group(1)
        m = re.search(r"(?im)^\s*Last reboot:\s*(.+?)\s*$", system_status)
        if m:
            res["last_reboot"] = m.group(1).rstrip(". ")
        return res

    @staticmethod
    def _short_if(name: str) -> str:
        """GigabitEthernet0/0/4 -> gi0/0/4 (matches 'show interfaces description')."""
        n = (name or "").strip().lower()
        for full, short in (("tengigabitethernet", "te"), ("fortygigabitethernet", "fo"),
                            ("hundredgige", "hu"), ("twentyfivegige", "twe"),
                            ("gigabitethernet", "gi"), ("fastethernet", "fa"),
                            ("ethernet", "eth"), ("loopback", "lo"), ("tunnel", "tu"),
                            ("cellular", "ce")):
            if n.startswith(full):
                return short + n[len(full):]
        return n

    def wan_peer_facts(self, peer: str, cli_output=None, evidence=None,
                       vpn: str = "0", platform: str = "") -> dict:
        """Facts about the BGP peer's WAN side, taken ONLY from device output.

        interface   : from 'show ip route <peer>' ('via X' / 'directly connected,
                      via X') or 'Interface associated: X' in 'show ip bgp neighbors'
        description : that interface's row in 'show interfaces description'
        if_status   : status/protocol from 'show ip interface brief'
        arp_entry   : v3.12 - 'present (MAC x)', 'incomplete (...)' or 'absent',
                      read from the peer's own VPN (cEdge service VPN: only
                      'show ip arp vrf <vpn>'); '' when that ARP was not read
        tloc        : matching rows of the wan-interface-list (color + state)
        Any fact that cannot be read stays '' and is printed as not determined.
        """
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        facts = {"interface": "", "description": "", "if_status": "",
                 "arp_entry": "", "tloc": [], "tloc_colors": [], "control": [],
                 "subnet": ""}
        peer = str(peer or "").strip()
        if not peer:
            return facts
        iface = ""
        # v3.13 (prod 2614): the interface whose subnet holds the peer, read
        # from interface addresses - still correct when the link is down and
        # the connected route has gone (route lookup then shows only OMP).
        sub = self.peer_interface_by_subnet(co, peer)
        if sub:
            iface = sub.get("interface", "")
            facts["subnet"] = sub.get("subnet", "")
            facts["if_status"] = sub.get("status", "")
        route = ev.get("route_to_peer", "") or co.get("ip_route_peer", "")
        if isinstance(route, str) and not iface:
            m = re.search(r"directly connected,\s*via\s+(\S+)", route)
            if not m:
                m = re.search(r"via\s+" + self._IPV4 + r"[^\n]*?,\s*(\S+?)\s*$", route, re.M)
            if m:
                iface = m.group(1).rstrip(",")
        if not iface:
            for key in ("bgp_neighbor", "bgp_neighbors", "bgp_neighbor_peer"):
                txt = ev.get(key, "") or co.get(key, "")
                if key == "bgp_neighbor_peer":
                    txt = self._peer_nbr_text(co, ev, peer) or txt
                if not isinstance(txt, str):
                    continue
                blk = re.search(r"BGP neighbor is " + re.escape(peer) + r"\b(.*?)(?=BGP neighbor is |\Z)",
                                txt, re.S)
                if blk:
                    m = re.search(r"Interface associated:\s*(\S+)", blk.group(1))
                    if m:
                        iface = m.group(1)
                        break
        facts["interface"] = iface
        if iface:
            short = self._short_if(iface)
            desc = co.get("interfaces_desc", "")
            if isinstance(desc, str):
                for line in desc.splitlines():
                    parts = line.split(None, 3)
                    if parts and self._short_if(parts[0]) == short:
                        facts["description"] = parts[3].strip() if len(parts) > 3 else ""
                        break
            brief = co.get("ip_int_brief", "")
            if isinstance(brief, str):
                for line in brief.splitlines():
                    parts = line.split()
                    if parts and self._short_if(parts[0]) == short and len(parts) >= 6:
                        facts["if_status"] = "%s/%s" % (" ".join(parts[4:-1]), parts[-1])
                        break
            if not facts["if_status"] and isinstance(desc, str):
                for line in desc.splitlines():
                    parts = line.split(None, 3)
                    if parts and self._short_if(parts[0]) == short and len(parts) >= 3:
                        facts["if_status"] = "%s/%s" % (parts[1], parts[2])
                        break
            wl = co.get("wan_interface_list", "")
            if isinstance(wl, str):
                for line in wl.splitlines():
                    parts = line.split()
                    if len(parts) < 8 or not parts[0][:1].isalpha():
                        continue
                    if self._short_if(parts[0]) == short or self._short_if(parts[-1]) == short:
                        color = ""
                        state = ""
                        for i, tok in enumerate(parts):
                            if tok.lower() in ("up", "down") and i > 0:
                                color, state = parts[i - 1], tok.lower()
                                break
                        entry = "%s %s (%s)" % (color, state, parts[0])
                        if color and entry not in facts["tloc"]:
                            facts["tloc"].append(entry)
                        if color and color not in facts["tloc_colors"]:
                            facts["tloc_colors"].append(color)
        # Control connections per local color, as printed by the device.
        cc = co.get("control_connections", "")
        if isinstance(cc, str) and facts["tloc_colors"]:
            per = {}
            for line in cc.splitlines():
                if not re.match(r"^\s*(vsmart|vbond|vmanage)\s", line):
                    continue
                m = re.findall(r"\s(\S+)\s+(?:No|Yes|-)\s+(\S+)", line)
                if not m:
                    continue
                color, st = m[-1]
                per.setdefault(color, []).append(st.lower())
            for color in facts["tloc_colors"]:
                sts = per.get(color, [])
                if sts:
                    facts["control"].append("%s: %d up of %d (%s)" % (
                        color, sts.count("up"), len(sts), ", ".join(sorted(set(sts)))))
                else:
                    facts["control"].append("%s: no control connection listed" % color)
        facts["arp_entry"] = self.arp_peer_state(co, ev, peer, vpn, platform)
        return facts

    # v3.12 (prod 2026101102521 / 2026101200744 / 2026101201274): an
    # 'Incomplete' ARP row was reported as "present", and a service-VPN peer
    # was looked up in the global ARP table instead of 'show ip arp vrf <vpn>'.
    _MAC_RE = (r"(?i)\b([0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4}"
               r"|[0-9a-f]{2}(?::[0-9a-f]{2}){5})\b")

    def arp_peer_state(self, cli_output, evidence, peer: str, vpn: str = "0",
                       platform: str = "") -> str:
        """ARP state of the BGP peer, from device output only.

        Returns 'present (MAC x)', 'incomplete (no MAC - layer 2 to the peer
        not resolved)', 'present (MAC not read)', 'absent', or '' when the ARP
        table of the peer's VPN was not read (never guessed from another VPN).
        """
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        peer = str(peer or "").strip()
        if not peer:
            return ""
        v = self._norm_vrf(vpn) if vpn not in (None, "") else "0"
        service = v not in ("", "0")
        plat = str(platform or "").lower()
        if v == "?" and plat != "vedge":
            # VPNv4 peer whose VRF the device output did not name: the global
            # table would be the wrong VPN, so only a VRF lookup counts.
            sources = [ev.get("arp_peer_vrf", "")]
            asked = False
        elif service and plat != "vedge":
            # cEdge service VPN: only the VRF table is valid. 'show arp' and
            # 'show arp | include' read the GLOBAL table (wrong VPN).
            sources = [ev.get("arp_peer_vrf", "")]
            # the VRF route lookup always prints something, so its presence
            # proves the VRF evidence commands (incl. the VRF ARP) were sent
            asked = "arp_peer_vrf" in ev or "route_to_peer_vrf" in ev
        else:
            # VPN 0 (cEdge global table) or vEdge ('show arp vpn <vpn>' is
            # already VPN-scoped in both bundles).
            sources = [ev.get("arp_peer", ""), co.get("arp", "")]
            asked = any(isinstance(t, str) and t.strip() for t in sources) or "arp_peer" in ev
        pat = re.compile(r"(?<![\d.])" + re.escape(peer) + r"(?![\d.])")
        for text in sources:
            if not (isinstance(text, str) and text.strip()):
                continue
            rows = [ln for ln in self._lines(text) if pat.search(ln)]
            if not rows:
                continue
            row = rows[0]
            if re.search(r"(?i)\bincomplete\b", row):
                return "incomplete (no MAC - layer 2 to the peer not resolved)"
            mac = re.search(self._MAC_RE, row)
            if mac:
                return "present (MAC %s)" % mac.group(1)
            return "present (MAC not read)"
        # Empty outputs are dropped by strip_invalid_commands, so an asked
        # but empty 'include <peer>' lookup means no ARP row for the peer.
        return "absent" if asked else ""

    # ------------------------------------------------------------------ #
    # v3.13 (NOC feedback 13-Oct-2026: tickets 2150, 2152, 2614, 1956)
    # Device output only; every function returns an empty/neutral value
    # when the output it needs was not collected, never a guess.
    # ------------------------------------------------------------------ #

    def alarm_vpn_split(self, neighbors, vpn_scope) -> dict:
        """Split the device-wide neighbor list by the VPN the alarm names.

        alarm_vpn_up : at least one neighbor in the alarm VPN, all of them
                       established (admin shutdown ignored, as in 4620).
        other_down   : neighbors OUTSIDE the alarm VPN that are not
                       established and not admin shutdown.
        scoped       : False when the alarm VPN was not recognised or no
                       neighbor is in it (caller keeps the device-wide verdict).
        """
        res = {"scoped": False, "alarm_vpn_up": False, "in_vpn": [],
               "in_vpn_down": [], "other_down": [], "in_vpn_est": 0}
        scope = str(vpn_scope if vpn_scope is not None else "").strip()
        rows = [n for n in (neighbors or []) if isinstance(n, dict)]
        if scope == "" or not rows:
            return res
        inside = self.neighbors_in_vpn(rows, scope)
        if not inside:
            return res
        outside = self.neighbors_outside_vpn(rows, scope)
        in_down = self.get_stuck_neighbors(inside)
        in_est = [n for n in inside if str(n.get("state", "")).lower() == "established"]
        res.update(scoped=True, in_vpn=inside, in_vpn_down=in_down,
                   in_vpn_est=len(in_est),
                   other_down=self.get_stuck_neighbors(outside),
                   alarm_vpn_up=(len(in_down) == 0 and len(in_est) > 0))
        return res

    # cEdge syslog: 'Oct  8 06:31:52.173: %BGP-5-ADJCHANGE: neighbor 10.33.17.6
    # vpn vrf 1 Down Interface flap' / '... neighbor 65.250.6.149 Up'
    _ADJ_RE = re.compile(
        r"^\*?\s*(?P<ts>[A-Z][a-z]{2}\s+\d{1,2}\s+(?:\d{4}\s+)?\d{1,2}:\d{2}:\d{2})(?:\.\d+)?"
        r".*?%BGP-5-ADJCHANGE:\s*neighbor\s+(?P<ip>\S+)(?:\s+vpn\s+vrf\s+\S+)?\s+"
        r"(?P<ev>Up|Down)\b\s*(?P<why>.*)$")
    _NOTIF_RE = re.compile(
        r"^\*?\s*(?P<ts>[A-Z][a-z]{2}\s+\d{1,2}\s+(?:\d{4}\s+)?\d{1,2}:\d{2}:\d{2}).*?"
        r"%BGP-3-NOTIFICATION:.*?neighbor\s+(?P<ip>\S+).*?\((?P<why>[^)]+)\)")

    def bgp_peer_log_line(self, log_text, peer: str) -> str:
        """'last down Oct  8 06:31:52 (Interface flap), last up Oct  7 18:24:39'
        from cEdge ADJCHANGE/NOTIFICATION syslog lines for <peer>. Times are
        the device's own log clock. '' when no such line (vEdge log format is
        not parsed - its lines are still shown under COMMANDS OUTPUT)."""
        if not self._usable(log_text) or not peer:
            return ""
        last_down = last_up = None
        notif = ""
        for ln in self._lines(log_text):
            m = self._ADJ_RE.match(ln.strip())
            if m and m.group("ip") == peer:
                ts = " ".join(m.group("ts").split())
                if m.group("ev") == "Down":
                    why = m.group("why").strip() or ""
                    last_down = (ts, why)
                else:
                    last_up = ts
                continue
            n = self._NOTIF_RE.match(ln.strip())
            if n and n.group("ip") == peer:
                notif = n.group("why").strip()
        if not last_down and not last_up:
            return ""
        bits = []
        if last_down:
            why = last_down[1]
            if notif and (not why or why.lower().startswith("bgp notification")):
                why = notif
            bits.append("last down %s%s" % (last_down[0], (" (%s)" % why) if why else ""))
        if last_up:
            bits.append("last up %s" % last_up)
        return ", ".join(bits)

    @staticmethod
    def _updown_seconds(up_down) -> int:
        """'00:29:18' -> 1758; '2d02h' / '6w2d' / 'never' -> -1 (only the
        hh:mm:ss form is exact enough to compute a time from)."""
        m = re.match(r"^\s*(\d{1,2}):(\d{2}):(\d{2})\s*$", str(up_down or ""))
        if not m:
            return -1
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))

    @staticmethod
    def _utc_epoch(ts):
        """'2026-10-08 05:47:25' / '2026-10-12T10:12:09Z' / '10/08/2026 05:19:38'
        (ticket INCIDENT START TIME, UTC as seen on prod tickets) -> epoch."""
        import calendar
        s = str(ts or "").strip().rstrip("Zz").replace("T", " ")
        for fmt in ("%Y-%m-%d %H:%M:%S", "%m/%d/%Y %H:%M:%S", "%m-%d-%Y %H:%M:%S",
                    "%Y-%m-%d %H:%M", "%m/%d/%Y %H:%M"):
            try:
                return calendar.timegm(time.strptime(s[:19], fmt))
            except ValueError:
                continue
        return None

    def recent_recoveries(self, neighbors, vpn_scope, log_text="", run_ts="",
                          alarm_ts="") -> list:
        """Observation lines for neighbors that are established NOW but came
        up less than 24 h ago (Up/Down timer in hh:mm:ss) - i.e. the session
        went down and recovered before this check. Limited to the alarm VPN
        when it is recognised. run_ts ('YYYY-MM-DD HH:MM:SS' UTC, task 0003)
        lets the line give the approximate re-establish time in UTC."""
        scope = str(vpn_scope if vpn_scope is not None else "").strip()
        rows = [n for n in (neighbors or []) if isinstance(n, dict)]
        if scope:
            inside = self.neighbors_in_vpn(rows, scope)
            rows = inside if inside else rows
        run_epoch = self._utc_epoch(run_ts)
        alarm_epoch = self._utc_epoch(alarm_ts)
        out = []
        for n in rows:
            if str(n.get("state", "")).lower() != "established":
                continue
            secs = self._updown_seconds(n.get("up_down", ""))
            if secs < 0:
                continue
            after_alarm = None
            if run_epoch is not None and alarm_epoch is not None:
                # 10 min margin: alarm time is minute-granular, run time is
                # taken at the start of the run
                after_alarm = (run_epoch - secs) >= (alarm_epoch - 600)
                if not after_alarm:
                    continue          # up since before this alarm - not related
            line = "BGP neighbor %s re-established %s before this check" % (
                n.get("neighbor", "?"), str(n.get("up_down")).strip())
            if run_epoch is not None:
                line += " (about %s UTC)" % time.strftime("%H:%M", time.gmtime(run_epoch - secs))
            lg = self.bgp_peer_log_line(log_text, str(n.get("neighbor", "")))
            if lg:
                line += " - device log: %s" % lg
            if after_alarm:
                # v3.14 (prod 20821): recovered inside the 10 min margin but
                # BEFORE the ticket alarm start time -> do not say 'after'
                if (run_epoch - secs) < alarm_epoch:
                    line += " - it went down and recovered around the time the alarm was raised, before automation ran"
                else:
                    line += " - it went down and recovered after the alarm was raised, before automation ran"
            out.append(line)
        return out[:3]

    # ------------------------------------------------------------------ #
    # v3.14 (prod 20821, 13-Oct-2026): commands the device REJECTED for the
    # automation login (e.g. reduced privilege) are reported as rejected,
    # never as 'no output'; BFD flap evidence and other active alarms are
    # named in the ticket.
    # ------------------------------------------------------------------ #

    _REJECT_MARKS = ("% invalid input", "command authorization failed", "% authorization failed",
                     "% permission denied", "syntax error", "unknown command")

    # decision-relevant commands only (probes and optional commands excluded)
    _REJECT_NAMES = (("logging_bgp", "BGP log"), ("control_connections", "SD-WAN control connections"),
                     ("bfd_sessions", "BFD sessions"), ("wan_interface_list", "TLOC / WAN interface list"),
                     ("control_history", "control connection history"), ("omp_peers", "OMP peers"),
                     ("system_status", "system status"), ("bgp_config", "BGP configuration"),
                     ("bgp_summary", "BGP summary"), ("arp", "ARP table"))

    def cmd_rejected(self, text) -> bool:
        """True when the output is the device refusing the command."""
        if not isinstance(text, str) or not text.strip():
            return False
        low = text.lower()
        return any(m in low for m in self._REJECT_MARKS)

    def rejected_commands(self, cli_output) -> list:
        """Friendly names of the decision-relevant commands the device rejected."""
        co = cli_output if isinstance(cli_output, dict) else {}
        return [name for key, name in self._REJECT_NAMES if self.cmd_rejected(co.get(key, ""))]

    @staticmethod
    def privilege_level(text) -> str:
        """'show privilege' -> '15' ('' when not read)."""
        m = re.search(r"(?i)current privilege level is\s+(\d+)", str(text or ""))
        return m.group(1) if m else ""

    @staticmethod
    def parse_version_uptime(version_text) -> dict:
        """cEdge 'show version' fallback when 'show sdwan system status' is
        not available: '<host> uptime is X' + 'Last reload reason: Y'."""
        res = {"uptime": "", "last_reboot": ""}
        t = str(version_text or "")
        m = re.search(r"(?im)^\S+\s+uptime is\s+(.+?)\s*$", t)
        if m:
            res["uptime"] = m.group(1)
        m = re.search(r"(?im)^\s*Last reload reason:\s*(.+?)\s*$", t)
        if m:
            res["last_reboot"] = m.group(1).rstrip(". ")
        return res

    def bfd_flap_detail(self, history, window_minutes: int = 0, max_rows: int = 15) -> dict:
        """Same selection as count_bfd_flaps (state 'down' inside the window),
        plus which colours went down and the raw rows (Jenkins log only)."""
        res = {"count": 0, "colors": "", "rows": []}
        if not isinstance(history, list):
            return res
        cutoff_ms = 0
        try:
            wm = int(window_minutes or 0)
        except (TypeError, ValueError):
            wm = 0
        if wm > 0:
            cutoff_ms = int(time.time() * 1000) - (wm * 60 * 1000)
        per = {}
        for h in history:
            if not isinstance(h, dict):
                continue
            if str(h.get("state") or "").strip().lower() != "down":
                continue
            ts = self._event_epoch_ms(h)
            if cutoff_ms and ts is not None and ts < cutoff_ms:
                continue
            res["count"] += 1
            col = str(h.get("color") or "?")
            per[col] = per.get(col, 0) + 1
            if len(res["rows"]) < max_rows:
                res["rows"].append("color=%s dst=%s time-date=%s lastupdated=%s epoch_ms=%s" % (
                    col, h.get("dst-ip", ""), h.get("time-date", ""), h.get("lastupdated", ""), ts))
        res["colors"] = ", ".join("%s %d" % (c, n) for c, n in sorted(per.items(), key=lambda x: (-x[1], x[0])))
        return res

    def other_alarm_summary(self, alarms) -> str:
        """Active vManage alarms that are NOT BGP-class (same test as
        bgp_class_alarms): '12 (SLA Violation Packet Drop 12)' - top 3 types
        by count; '' when none."""
        bgp_ids = set(id(a) for a in self.bgp_class_alarms(alarms))
        per, total = {}, 0
        for a in (alarms or []):
            if not isinstance(a, dict) or id(a) in bgp_ids:
                continue
            total += 1
            name = str(a.get("rule_name_display") or a.get("type") or "other").replace("_", " ").replace("-", " ").strip()
            per[name] = per.get(name, 0) + 1
        if not total:
            return ""
        top = sorted(per.items(), key=lambda x: (-x[1], x[0]))[:3]
        return "%d (%s)" % (total, ", ".join("%s %d" % (n, c) for n, c in top))

    # 'show ip interface | include line protocol|Internet address'
    _IFLP_RE = re.compile(r"^(\S+)\s+is\s+(.+?),\s+line protocol is\s+(\S+)")
    _IFADDR_RE = re.compile(r"Internet address is\s+(\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})")

    def peer_interface_by_subnet(self, cli_output, peer: str) -> dict:
        """Interface whose configured subnet contains <peer> (cEdge 'show ip
        interface' address lines; vEdge rows carrying a.b.c.d/nn). Works when
        the link is down and the connected route is gone (prod 2614: peer
        10.33.17.6 on Tunnel131 10.33.17.5/30). {} when not determinable."""
        import ipaddress
        co = cli_output if isinstance(cli_output, dict) else {}
        try:
            ip = ipaddress.ip_address(str(peer or "").strip())
        except ValueError:
            return {}
        best = None
        text = co.get("ip_int_addr", "")
        if self._usable(text):
            cur, st = "", ""
            for ln in self._lines(text):
                m = self._IFLP_RE.match(ln.strip())
                if m:
                    cur, st = m.group(1), "%s/%s" % (m.group(2).strip(), m.group(3).strip())
                    continue
                a = self._IFADDR_RE.search(ln)
                if a and cur:
                    try:
                        net = ipaddress.ip_network("%s/%s" % (a.group(1), a.group(2)), strict=False)
                    except ValueError:
                        continue
                    if ip in net and ip != ipaddress.ip_address(a.group(1)) and net.prefixlen < 32 \
                            and (best is None or net.prefixlen > best[1].prefixlen):
                        best = (cur, net, a.group(1), st)
        if best is None:
            for ln in self._lines(co.get("interfaces_desc", "")):
                f = ln.split()
                for tok in f:
                    mm = re.match(r"^(\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})$", tok)
                    if not mm or len(f) < 2:
                        continue
                    try:
                        net = ipaddress.ip_network(tok, strict=False)
                    except ValueError:
                        continue
                    if ip in net and net.prefixlen < 32 and ip != ipaddress.ip_address(mm.group(1)):
                        name = f[1] if re.match(r"^\d+$", f[0]) else f[0]
                        if best is None or net.prefixlen > best[1].prefixlen:
                            best = (name, net, mm.group(1), "")
        if best is None:
            return {}
        return {"interface": best[0], "subnet": str(best[1]), "local_ip": best[2],
                "status": best[3]}

    def wan_rows(self, text) -> list:
        """'show [sdwan] control local-properties wan-interface-list' rows:
        [{interface, public_ip, private_ip, color, state}]."""
        out = []
        for ln in self._lines(text):
            f = ln.split()
            if len(f) < 8 or not f[0][:1].isalpha() or f[0].upper() in ("INTERFACE", "PUBLIC", "PRIVATE"):
                continue
            ips = [t for t in f[1:] if re.match(r"^" + self._IP_RE + r"$", t)]
            color, state = "", ""
            for i, tok in enumerate(f):
                if tok.lower() in ("up", "down") and i > 0:
                    color, state = f[i - 1], tok.lower()
                    break
            if not color or len(ips) < 2:
                continue
            out.append({"interface": f[0], "public_ip": ips[0], "private_ip": ips[1],
                        "color": color, "state": state})
        return out

    def transport_health(self, cli_output, platform: str = "") -> list:
        """Per local TLOC colour, from device output: transport interface,
        public/private IP, TLOC state, interface status/description, whether
        the interface is a TLOC extension (description says so), BFD sessions
        up/total and control connections up/total. [] when the WAN list and
        BFD/control outputs were not collected."""
        co = cli_output if isinstance(cli_output, dict) else {}
        colors = {}
        for r in self.wan_rows(co.get("wan_interface_list", "")):
            c = colors.setdefault(r["color"], {"color": r["color"], "interface": "",
                                               "public_ip": "", "private_ip": "", "tloc_state": "",
                                               "description": "", "if_status": "", "extension": False,
                                               "bfd_up": 0, "bfd_total": 0, "ctrl_up": 0, "ctrl_total": 0})
            if not c["interface"]:
                c.update(interface=r["interface"], public_ip=r["public_ip"],
                         private_ip=r["private_ip"], tloc_state=r["state"])
        for ln in self._lines(co.get("bfd_sessions", "")):
            f = ln.split()
            if len(f) < 5 or not re.match(r"^" + self._IP_RE + r"$", f[0]):
                continue
            c = colors.setdefault(f[3], {"color": f[3], "interface": "", "public_ip": "", "private_ip": "",
                                         "tloc_state": "", "description": "", "if_status": "",
                                         "extension": False, "bfd_up": 0, "bfd_total": 0,
                                         "ctrl_up": 0, "ctrl_total": 0})
            c["bfd_total"] += 1
            if f[2].lower() == "up":
                c["bfd_up"] += 1
        for ln in self._lines(co.get("control_connections", "")):
            if not re.match(r"^\s*(vsmart|vbond|vmanage)\s", ln):
                continue
            m = re.findall(r"\s(\S+)\s+(?:No|Yes|-)\s+(\S+)", ln)
            if not m:
                continue
            color, st = m[-1]
            c = colors.get(color)
            if c is None:
                continue
            c["ctrl_total"] += 1
            if st.lower() == "up":
                c["ctrl_up"] += 1
        desc = co.get("interfaces_desc", "")
        brief = co.get("ip_int_brief", "")
        for c in colors.values():
            if not c["interface"]:
                continue
            short = self._short_if(c["interface"])
            for ln in self._lines(desc):
                parts = ln.split(None, 3)
                if parts and self._short_if(parts[0]) == short:
                    c["description"] = parts[3].strip() if len(parts) > 3 else ""
                    if len(parts) >= 3 and not c["if_status"]:
                        c["if_status"] = "%s/%s" % (parts[1], parts[2])
                    break
            for ln in self._lines(brief):
                parts = ln.split()
                if parts and self._short_if(parts[0]) == short and len(parts) >= 6:
                    c["if_status"] = "%s/%s" % (" ".join(parts[4:-1]), parts[-1])
                    break
            c["extension"] = bool(re.search(r"tloc[\s_-]*ext", c["description"], re.I))
        return sorted(colors.values(), key=lambda x: x["color"])

    @staticmethod
    def _color_down(c) -> bool:
        """A colour is DOWN when the device lists BFD sessions for it and none
        is up, or lists control connections for it and none is up."""
        return ((c.get("bfd_total", 0) > 0 and c.get("bfd_up", 0) == 0)
                or (c.get("ctrl_total", 0) > 0 and c.get("ctrl_up", 0) == 0))

    def transport_lines(self, health) -> list:
        """One observation line per TLOC colour (presentation text)."""
        out = []
        for c in (health or []):
            if not isinstance(c, dict):
                continue
            where = c.get("interface") or "interface not listed"
            extra = []
            if c.get("extension"):
                extra.append("TLOC extension - the circuit is on the partner router")
            if c.get("if_status"):
                extra.append("status %s" % c["if_status"])
            parts = []
            if c.get("bfd_total"):
                parts.append("BFD %d of %d up" % (c["bfd_up"], c["bfd_total"]))
            if c.get("ctrl_total"):
                parts.append("control connections %d of %d up" % (c["ctrl_up"], c["ctrl_total"]))
            if not parts:
                parts.append("no BFD session or control connection listed")
            out.append("Transport %s (%s%s): %s%s" % (
                c.get("color", "?"), where, (", " + ", ".join(extra)) if extra else "",
                ", ".join(parts), " - DOWN" if self._color_down(c) else ""))
        return out

    def peer_transport_color(self, wan_facts, health) -> str:
        """TLOC colour the BGP peer's interface rides on: the colour of that
        interface itself, or a colour named in its description (prod 2614:
        Tunnel131 'IPsec tunnel over public-internet to Prisma POP')."""
        wf = wan_facts if isinstance(wan_facts, dict) else {}
        iface = str(wf.get("interface", "") or "")
        descr = str(wf.get("description", "") or "").lower()
        for c in (health or []):
            if iface and self._short_if(c.get("interface", "")) == self._short_if(iface):
                return c.get("color", "")
        for c in sorted((health or []), key=lambda x: -len(x.get("color", ""))):
            col = str(c.get("color", "")).lower()
            if col and col in descr:
                return c.get("color", "")
        return ""

    _ROUTER_HINTS = ("router", "vedge", "cedge", "routing vm", "viptela")
    _NON_ROUTER_HINTS = ("vmanage", "vsmart", "vbond", "modem", "switch", "firewall")

    def select_sibling_router(self, esp_json, neid: str) -> dict:
        """Partner router at the site from the ESP inventory-search result the
        role already fetched (task 1015), same rule as BFD-TLOC-VIPTELA-TRIAGE
        select_redundant_router: router-type, has a mgmt IP, not this NEID,
        managed and valid, closest NEID (longest common prefix) first."""
        empty = {"ip": "", "name": "", "device_type": "", "candidates": [], "count": 0}
        try:
            devs = (esp_json or {}).get("devices", []) if isinstance(esp_json, dict) else []
            neid_s = str(neid or "")
            cands = []
            for row in devs if isinstance(devs, list) else []:
                d = row.get("device", row) if isinstance(row, dict) else None
                if not isinstance(d, dict):
                    continue
                dtype = str(d.get("deviceType", "")).lower()
                ipaddr = str(d.get("mgmtIPAddress", "") or "")
                name = str(d.get("dnsEntityName", "") or "")
                if any(h in dtype for h in self._NON_ROUTER_HINTS) or not any(h in dtype for h in self._ROUTER_HINTS):
                    continue
                if not ipaddr or ipaddr in ("127.0.0.1", "1.1.1.1", "0.0.0.0") or not name:
                    continue
                if name.lower() == neid_s.lower() or d.get("isManaged") is False or d.get("isValid") is False:
                    continue
                cands.append({"name": name, "ip": ipaddr, "device_type": str(d.get("deviceType", ""))})
            if not cands:
                return empty

            def _lcp(a, b):
                n = 0
                for x, y in zip(a.lower(), b.lower()):
                    if x != y:
                        break
                    n += 1
                return n
            cands.sort(key=lambda c: (-_lcp(c["name"], neid_s), abs(len(c["name"]) - len(neid_s)), c["name"].lower()))
            pick = dict(cands[0])
            pick.update(candidates=[c["name"] for c in cands], count=len(cands))
            return pick
        except (AttributeError, TypeError, ValueError):
            return empty

    def transport_findings(self, health, sibling_health, sibling=None, peer_color="") -> dict:
        """Combine this router's and the partner router's per-colour state.

        Returns {'down_colors', 'lines' (observations), 'npoa' (one bullet or
        ''), 'circuit_device', 'circuit_interface'}. The circuit is placed on
        the partner router only when this router's interface for the colour is
        a TLOC extension AND the partner lists that colour on its own WAN
        interface; otherwise it stays on this router. No decision is taken -
        the text tells NOC where to check."""
        res = {"down_colors": [], "lines": [], "npoa": "", "circuit_device": "",
               "circuit_interface": ""}
        sib = sibling if isinstance(sibling, dict) else {}
        sname = str(sib.get("name", "") or "")
        local = {c.get("color"): c for c in (health or []) if isinstance(c, dict)}
        remote = {c.get("color"): c for c in (sibling_health or []) if isinstance(c, dict)}
        down = [c for c in local.values() if self._color_down(c)]
        res["down_colors"] = [c["color"] for c in down]
        # NPOA only for the colour the down BGP peer rides on - a down colour
        # that is not linked to the peer (e.g. an idle LTE backup) is shown in
        # OBSERVATIONS but never turned into a circuit action.
        target = None
        if peer_color and peer_color in local and self._color_down(local[peer_color]):
            target = local[peer_color]
        for c in down:
            r = remote.get(c["color"])
            if not sname or r is None:
                continue
            bits = []
            if r.get("interface"):
                bits.append("on %s" % r["interface"])
            if r.get("public_ip"):
                bits.append("public IP %s%s" % (r["public_ip"], (" = private IP" if r.get("public_ip") == r.get("private_ip") else ", private IP %s" % r.get("private_ip", "?"))))
            if r.get("if_status"):
                bits.append("interface %s" % r["if_status"])
            if r.get("tloc_state"):
                bits.append("TLOC %s" % r["tloc_state"])
            if r.get("bfd_total"):
                bits.append("BFD %d of %d up" % (r["bfd_up"], r["bfd_total"]))
            if r.get("ctrl_total"):
                bits.append("control connections %d of %d up" % (r["ctrl_up"], r["ctrl_total"]))
            res["lines"].append("Partner router %s, transport %s: %s" % (
                sname, c["color"], ", ".join(bits) if bits else "colour listed, no detail"))
        if target is None:
            return res
        r = remote.get(target["color"])
        if target.get("extension") and sname and r is not None and r.get("interface") and not r.get("extension"):
            res["circuit_device"], res["circuit_interface"] = sname, r["interface"]
        elif not target.get("extension") and target.get("interface"):
            res["circuit_device"], res["circuit_interface"] = "this router", target["interface"]
        if res["circuit_device"] == "this router":
            res["npoa"] = ("Transport %s is down on this router (%s). NOC to check the %s circuit "
                           "with the ISP/LEC/PTT. The circuit-down playbook can be run for this "
                           "device/interface once verified." % (target["color"], target["interface"], target["color"]))
        elif res["circuit_device"]:
            res["npoa"] = ("Transport %s is down. On this router it is a TLOC extension - the circuit "
                           "is on the partner router %s (%s). NOC to check the %s circuit with the "
                           "ISP/LEC/PTT on %s %s. The circuit-down playbook can be run for that "
                           "device/interface once verified." % (
                               target["color"], sname, r["interface"], target["color"], sname, r["interface"]))
        elif target.get("extension"):
            res["npoa"] = ("Transport %s is down and is a TLOC extension on this router - the circuit "
                           "is on the partner router%s. NOC to identify the %s interface on the "
                           "partner router and check the circuit with the ISP/LEC/PTT." % (
                               target["color"], (" " + sname) if sname else "", target["color"]))
        return res

    def partner_command_evidence(self, outputs, platform: str = "", name: str = "",
                                 ip: str = "") -> str:
        """COMMANDS OUTPUT blocks for the partner router (trimmed, ETMS-safe
        titles): TLOC/WAN list, BFD summary per colour, control connections,
        WAN interface description lines. '' when nothing was read."""
        co = outputs if isinstance(outputs, dict) else {}
        ced = str(platform or "").lower() == "cedge"
        who = " - partner router %s (%s)" % (name or "?", ip or "?")
        wan = self.trim_table_rows(
            co.get("wan_interface_list", ""),
            r"^(ge|gi|te|tu|ten|eth|cellular|dialer|lo|loopback|tunnel|gigabitethernet|tengigabitethernet)\S*\s",
            header_re=r"^\s*(INTERFACE)\b")
        wan_ifs = [self._short_if(r["interface"]) for r in self.wan_rows(co.get("wan_interface_list", ""))]
        desc = "\n".join(ln.rstrip() for ln in self._lines(co.get("interfaces_desc", ""))
                         if ln.split() and (self._short_if(ln.split()[0]) in wan_ifs
                                            or re.match(r"^\s*Interface\s+Status", ln)))
        secs = [
            (("show sdwan control local-properties wan-interface-list" if ced
              else "show control local-properties wan-interface-list") + " (TLOCs)", wan),
            (("show sdwan bfd sessions" if ced else "show bfd sessions") + " (summary + not-up sessions)",
             self.trim_bfd_summary(co.get("bfd_sessions", ""), 8)),
            ("show sdwan control connections" if ced else "show control connections",
             self.trim_control(co.get("control_connections", ""))),
            (("show interfaces description" if ced else "show interface description") + " (WAN interfaces)",
             desc if len(desc.splitlines()) > 1 else ""),
        ]
        parts = []
        for title, body in secs:
            if isinstance(body, str) and body.strip():
                parts.append("Command: %s\nOutput:\n%s\n" % (self._etms_title(title + who),
                                                                self.mask_secrets(body).strip("\n")))
        return "\n".join(parts)

    def bgp_state_hint(self, cli_output, evidence, peer: str) -> str:
        """Plain explanation of a stuck state from the neighbor detail (cEdge).
        OpenSent: TCP to the peer is up but the peer never answered the BGP
        OPEN (prod 1956: 0 messages received, remote router ID 0.0.0.0)."""
        nb = self._peer_nbr_text(cli_output, evidence, peer)
        if not nb:
            return ""
        blk = re.search(r"BGP neighbor is " + re.escape(peer) + r"\b(.*?)(?=\nBGP neighbor is |\Z)", nb, re.S)
        b = blk.group(1) if blk else nb
        st = re.search(r"BGP state = (\S+)", b)
        state = st.group(1).rstrip(",").lower() if st else ""
        rid = re.search(r"remote router ID (\S+)", b)
        opens = re.search(r"Opens:\s+(\d+)\s+(\d+)", b)
        if state == "opensent" and ((rid and rid.group(1).rstrip(",") == "0.0.0.0")
                                    or (opens and opens.group(2) == "0")):
            return ("TCP to the peer is up, but the peer has not answered the BGP OPEN "
                    "(remote router ID 0.0.0.0%s) - check the BGP configuration on the "
                    "peer side" % (", 0 OPEN received" if (opens and opens.group(2) == "0") else ""))
        return ""

    def _peer_nbr_text(self, cli_output, evidence, peer: str) -> str:
        """First neighbor-detail output that really contains <peer>: VRF
        lookup, global lookup, vpnv4-all lookup, all-neighbors dump. A
        '% No such neighbor' reply (VRF peer asked in the global table,
        prod 2614) is skipped."""
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        if not peer:
            return ""
        pat = re.compile(r"BGP neighbor is " + re.escape(peer) + r"\b")
        # v3.15: + the alarm-VRF neighbor detail read on every ticket
        for t in (ev.get("bgp_neighbor_vrf", ""), ev.get("bgp_neighbor", ""),
                  co.get("bgp_neighbor_peer", ""), co.get("bgp_vpnv4_peer", ""),
                  co.get("bgp_neighbors_vrf", ""), co.get("bgp_neighbors", "")):
            if isinstance(t, str) and pat.search(t):
                return t
        return ""


    def format_bgp_table(self, neighbors) -> str:
        """One line per BGP neighbor, values exactly as parsed from the source."""
        if not isinstance(neighbors, list) or not neighbors:
            return "  (none)"
        lines = []
        for n in neighbors[:30]:
            if not isinstance(n, dict):
                continue
            vrf = str(n.get("vrf", "?"))
            vrf_txt = ("VPN %s" % vrf) if vrf not in ("?", "") else "VPN ?"
            if n.get("vrf_confirmed") is False:
                vrf_txt += " (VRF not confirmed by device)"
            af = n.get("af", "")
            extra = []
            if n.get("up_down"):
                extra.append("up/down %s" % n.get("up_down"))
            if str(n.get("state", "")) == "established" and re.match(r"^\d+$", str(n.get("pfx_or_state", ""))):
                extra.append("prefixes %s" % n.get("pfx_or_state"))
            lines.append("  - %s AS %s %s%s state %s%s" % (
                n.get("neighbor", "?"), n.get("remote_as", "?") or "?", vrf_txt,
                (" " + af) if af else "", str(n.get("state", "?")).upper(),
                (" (" + ", ".join(extra) + ")") if extra else ""))
        return "\n".join(lines)

    def format_vmanage_data(self, store: dict) -> str:
        """vManage block that prints ONLY data vManage actually returned.

        store keys: reachability, collected{control,omp,ctrl_hist,bfd_hist,alarms},
        control_connections, omp_peers, control_flap_count, bfd_flap_count,
        active_alarms. A dataset whose API call did not return data is printed
        as 'Not collected (...)' - never as 0 / False. BGP is shown once, in
        the BGP STATE section, not here.
        """
        if not isinstance(store, dict):
            return ""
        col = store.get("collected", {}) or {}
        reach = str(store.get("reachability", "") or "unknown")
        why = ("vManage reports device %s" % reach) if reach != "reachable" else "API call failed"
        nc = "Not collected (%s)" % why
        lines = ["[vMANAGE DATA]",
                 "  Device reachability : %s (as reported by vManage)" % reach]
        if col.get("control"):
            cc = store.get("control_connections", []) or []
            up = sum(1 for c in cc if isinstance(c, dict)
                     and str(c.get("state", "")).lower() == "up")
            lines.append("  Control connections : %d up / %d total" % (up, len(cc)))
        else:
            lines.append("  Control connections : %s" % nc)
        if col.get("omp"):
            lines.append("  OMP peers           : %d" % len(store.get("omp_peers", []) or []))
        else:
            lines.append("  OMP peers           : %s" % nc)
        if col.get("ctrl_hist"):
            lines.append("  Control flaps (win) : %s" % store.get("control_flap_count", 0))
        else:
            lines.append("  Control flaps (win) : %s" % nc)
        if col.get("bfd_hist"):
            lines.append("  BFD flaps (win)     : %s" % store.get("bfd_flap_count", 0))
        else:
            lines.append("  BFD flaps (win)     : %s" % nc)
        if col.get("alarms"):
            lines.append("  Active alarms       : %d" % len(store.get("active_alarms", []) or []))
        else:
            lines.append("  Active alarms       : Not collected (alarm query failed)")
        return "\n".join(lines)

    _ASCII_MAP = {
        "\u2014": "-", "\u2013": "-", "\u2011": "-", "\u2010": "-", "\u2012": "-",
        "\u2212": "-", "\u2018": "", "\u2019": "", "\u201c": "", "\u201d": "",
        "\u2026": "...", "\u00a0": " ", "\u2192": "->", "\u00b7": "-",
    }

    def ascii_safe(self, text) -> str:
        """Final-output sanitizer for the iAutomate/ETMS path.

        Observed in prod (build 15333): Jenkins strips single quotes and ETMS
        renders non-ASCII as '?'-like glyphs. Double quotes and backslashes
        may break the JSON payload built by the pipeline (not verified), so
        they are removed too. Tabs -> spaces. Newlines are kept.
        """
        s = "" if text is None else str(text)
        for k, v in self._ASCII_MAP.items():
            s = s.replace(k, v)
        s = s.replace("'", "").replace('"', "").replace("\\", "/").replace("`", "")
        s = s.replace("\t", "    ").replace("\r", "")
        return s.encode("ascii", "replace").decode("ascii")

    def ssh_failure_reason(self, stdout, rc=None) -> str:
        """Short, secret-free reason from one bgp_ssh.py run.

        bgp_ssh.py always prints one JSON object whose 'error' is already
        password-sanitized (e.g. 'AuthenticationFailed: ...', 'ConnectionTimeout:
        ...', 'paramiko not installed', 'PlatformDetectionFailed').
        """
        s = "" if stdout is None else str(stdout).strip()
        if not s:
            return "no output from SSH script (rc=%s)" % rc
        if not s.startswith("{"):
            return "SSH script did not return JSON (rc=%s)" % rc
        try:
            data = json.loads(s)
        except ValueError:
            return "SSH script returned invalid JSON (rc=%s)" % rc
        if data.get("success"):
            return ""
        err = str(data.get("error") or "")
        if not err:
            err = "connected but no command returned output"
        err = " ".join(err.split())
        return err[:160]

    # ------------------------------------------------------------------ #
    # v3.11 - SSH read diagnostics + NOC wording (prod 2150 / 2152)
    # ------------------------------------------------------------------ #

    @staticmethod
    def ssh_read_info(stdout) -> dict:
        """'read_info' block of one bgp_ssh.py JSON result (command names,
        seconds, prompt seen, probe first lines - no outputs, no secrets).
        {} when absent or not JSON."""
        s = "" if stdout is None else str(stdout).strip()
        if not s.startswith("{"):
            return {}
        try:
            data = json.loads(s)
        except ValueError:
            return {}
        info = data.get("read_info") if isinstance(data, dict) else None
        return info if isinstance(info, dict) else {}

    @staticmethod
    def ssh_login_ok_unreadable(reasons) -> bool:
        """True when a login SUCCEEDED but the device type could not be read
        from its output (bgp_ssh.py raises PlatformDetectionFailed only after
        the SSH session is open)."""
        if isinstance(reasons, str):
            reasons = [reasons]
        return any("platformdetectionfailed" in str(r).lower() for r in (reasons or []))

    def noc_ssh_reason(self, text) -> str:
        """Plain-language SSH failure reason for the NOC ticket: drops the
        internal credential label ('TACACS: ', 'cinfo <type>: ') and error
        class names. Unknown reasons fall back to clean_reason()."""
        s = " ".join(str(text or "").split())
        s = re.sub(r"^(TACACS|cinfo\s+\S+|SIT[^:]*)\s*:\s*", "", s, flags=re.IGNORECASE)
        low = s.lower()
        if "platformdetectionfailed" in low:
            return "logged in, but the device type could not be identified from its output"
        if low.startswith("authenticationfailed"):
            return "login rejected (authentication failed)"
        if low.startswith("connectiontimeout"):
            return "connection timed out"
        if "paramiko not installed" in low:
            return "SSH library not available on the automation server"
        m = re.match(r"^(NetworkError|SSHException|UnexpectedError)\s*:\s*(.*)$", s)
        if m:
            label = {"NetworkError": "network error", "SSHException": "SSH error",
                     "UnexpectedError": "unexpected error"}[m.group(1)]
            rest = self.clean_reason(m.group(2))
            return label if rest == "reason not recorded" else "%s - %s" % (label, rest)
        return self.clean_reason(s)

    def norm_vpn(self, v) -> str:
        """VPN label as NOC reads it: vManage 'default'/'global' -> '0'."""
        return self._norm_vrf(v)

    def ssh_failure_reasons_from_loop(self, results) -> list:
        """'cinfo <type>: <reason>' for each non-skipped cinfo SSH attempt.
        Reads only cred_item.type, stdout and rc - never username/password."""
        out = []
        if not isinstance(results, list):
            return out
        for r in results:
            if not isinstance(r, dict) or r.get("skipped"):
                continue
            ctype = "cred"
            ci = r.get("cred_item")
            if isinstance(ci, dict) and ci.get("type"):
                ctype = str(ci.get("type"))
            reason = self.ssh_failure_reason(r.get("stdout", ""), r.get("rc", "n/a"))
            if reason:
                out.append("cinfo %s: %s" % (ctype, reason))
        return out

    # ------------------------------------------------------------------ #
    # v3.2 - standard NOC report helpers (additive)
    # ------------------------------------------------------------------ #

    def dcd_domain_from_fqdn(self, fqdn: str, fallback: str = "") -> str:
        """Jenkins agent FQDN -> DCD domain used in the report header.

        Seen in this environment: agent pdctd30-snmcpe1b.mso.mci.com writes
        'td30.mso.mci.com' (BFD-TLOC-VIPTELA-TRIAGE sample); prod devices on
        agent pdcd46-snmcpe1b resolve as <device>.d46.mso.mci.com. Anything
        that does not match the pattern returns `fallback` (unchanged header).
        """
        s = str(fqdn or "").strip().lower()
        m = re.match(r"^(?:pdc|ndc)([a-z0-9]+?)-snmcpe[a-z0-9]*\.(.+)$", s)
        if m:
            return "%s.%s" % (m.group(1), m.group(2))
        return str(fallback or "")

    def mask_secrets(self, text) -> str:
        """Mask values after password/secret/key keywords (e.g. BGP neighbor
        passwords in 'show running-config | section bgp'). A dict of command
        outputs is masked value by value."""
        if isinstance(text, dict):
            return {k: self.mask_secrets(v) for k, v in text.items()}
        if not isinstance(text, str):
            return "" if text is None else str(text)
        out = []
        for line in text.splitlines():
            m = re.search(r"(?i)\b(password|secret|md5|authentication-key|auth-key|key-string|pre-shared-key)\b",
                          line)
            if m:
                line = line[:m.end()] + " <masked>"
            out.append(line)
        return "\n".join(out)

    _KEY_CMDS = {
        "cedge": [
            ("bgp_summary", "show ip bgp all summary", "cli"),
            ("bgp_summary_vrf", "show ip bgp vpnv4 vrf {vpn} summary", "cli"),
            ("bgp_neighbor", "show ip bgp neighbors {peer}", "ev"),
            ("route_to_peer", "show ip route {peer}", "ev"),
            ("arp_peer", "show arp | include {peer}", "ev"),
            ("control_connections", "show sdwan control connections", "cli"),
            ("logging_bgp", "show logging | include BGP", "cli"),
        ],
        "vedge": [
            ("bgp_summary", "show bgp summary", "cli"),
            ("bgp_neighbor", "show bgp neighbor", "cli"),
            ("routes", "show ip routes vpn {vpn}", "ev"),
            ("arp_peer", "show arp vpn {vpn} | include {peer}", "ev"),
            ("control_connections", "show control connections", "cli"),
            ("logging_bgp", "show log | include BGP", "cli"),
        ],
    }

    def key_evidence(self, cli_output, evidence=None, platform: str = "",
                     peer: str = "", vpn: str = "0", budget: int = 6000,
                     per_cmd: int = 1800, note_style: str = "") -> str:
        """Decision-driving commands only, for the ticket. Each output is
        secret-masked and trimmed; the full output of every command goes to the
        Jenkins build log (task 7001). Budget-capped.
        note_style='noc': plain trim note, no internal/payload notes (NOC ticket)."""
        noc = str(note_style or "").lower() == "noc"
        co = cli_output if isinstance(cli_output, dict) else {}
        ev = evidence if isinstance(evidence, dict) else {}
        plat = str(platform or "").lower()
        if plat not in self._KEY_CMDS or (not co and not ev):
            return "- No device command output collected." if noc else "  (no device CLI output collected)"
        try:
            budget, per_cmd = int(budget), int(per_cmd)
        except (TypeError, ValueError):
            budget, per_cmd = 6000, 1800
        parts, omitted, used = [], [], 0
        for key, cmd, src in self._KEY_CMDS[plat]:
            text = (ev if src == "ev" else co).get(key, "")
            if not (isinstance(text, str) and text.strip()):
                continue
            low = text.lower()
            if any(mk in low for mk in ("% invalid input", "syntax error", "unknown command")):
                continue
            body = self.mask_secrets(self.trim_cli_noise(text)).strip("\n")
            if len(body) > per_cmd:
                body = body[:per_cmd].rstrip() + (
                    "\n... (output trimmed)" if noc
                    else "\n... (trimmed - full output in Jenkins build log)")
            block = "Command: %s\nOutput:\n%s\n" % (
                cmd.format(peer=peer or "<peer>", vpn=vpn or "0"), body)
            if used + len(block) > budget:
                omitted.append(cmd.format(peer=peer or "<peer>", vpn=vpn or "0"))
                continue
            parts.append(block)
            used += len(block)
        if omitted and not noc:
            parts.append("Not shown (payload limit, see Jenkins build log): %s" % "; ".join(omitted))
        if not parts:
            return "- No device command output collected." if noc else "  (no decision-driving command output collected)"
        return "\n".join(parts)

    def bgp_crosscheck(self, cli_rows, api_rows) -> str:
        """One line comparing device-CLI BGP state with vManage API rows."""
        cli = [r for r in (cli_rows or []) if isinstance(r, dict)]
        api = [r for r in (api_rows or []) if isinstance(r, dict)]
        if not api:
            return "Not available - vManage returned no BGP neighbor rows for this device"
        if not cli:
            return "Not applicable - no BGP neighbor in device CLI output"
        amap = {str(r.get("neighbor", "")): str(r.get("state", "")).lower() for r in api}
        diffs = []
        for r in cli:
            ip = str(r.get("neighbor", ""))
            c_up = str(r.get("state", "")).lower() == "established"
            if ip not in amap:
                diffs.append("%s not listed by vManage" % ip)
            elif (amap[ip] == "established") != c_up:
                diffs.append("%s CLI %s / vManage %s" % (ip, str(r.get("state", "")).upper(),
                                                         amap[ip].upper()))
        if diffs:
            return "Differs - " + "; ".join(diffs[:5])
        return "Consistent - the device and vManage agree (%d neighbor(s))" % len(cli)
